// global-setup.ts
import { cleanupDirectories } from './cleanup';
import { saveVariableIntoJsonFile } from '../utilities/uihelpers/jsonHelper'
import { chromium } from '@playwright/test';


async function globalSetup() {

  cleanupDirectories();

}

export default globalSetup;


