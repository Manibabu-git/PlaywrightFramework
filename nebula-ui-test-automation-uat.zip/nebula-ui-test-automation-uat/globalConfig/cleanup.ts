import fs from 'fs';
import path from 'path';

const directoriesToClean = ['allure-results', 'screenshots', 'downloads', 'videos'];
const filesToKeep = ['executor.json', 'categories.json', 'environment.properties'];

export const cleanupDirectories = () => {
    directoriesToClean.forEach((dir) => {
        fs.readdir(dir, (err, files) => {
            if (err) {
                console.error(`Error reading directory ${dir}:`, err);
                return;
            }

            files.forEach((file) => {
                if (!filesToKeep.includes(file)) {
                    fs.unlink(path.join(dir, file), (err) => {
                        if (err) {
                            console.error(`Error deleting file ${file}:`, err);
                        } else {
                            console.log(`Deleted file ${file}`);
                        }
                    });
                }
            });
        });
    });
};
