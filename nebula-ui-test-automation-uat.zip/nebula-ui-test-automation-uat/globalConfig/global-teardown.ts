import { chromium, firefox, webkit } from 'playwright';

async function globalTeardown() {
  console.log('Running global teardown...');
  const browsers = [chromium, firefox, webkit];
  for (const browserType of browsers) {
    const browser = await browserType.launch();
    const contexts = browser.contexts();
    for (const context of contexts) {
      await context.close();
    }
    await browser.close();
  }
}

export default globalTeardown;
