export class Constant {
    public static readonly qmetryBaseUri: string = 'https://jira.charter.com';
  }
  