import fs from 'fs';
import path from 'path';
import { GenericHelper } from '../utilities/uihelpers/genericHelper'
import { uploadTestAttachment } from '../utilities/apihelpers/apiRequestCreationHelper';

class VideoReporter {
    async onTestEnd(test, result) {
        const upload_video: string = process.env.UPLOAD_VIDEO_TO_QMETRY!;
        if (upload_video === 'Yes') {
            const videoAttachment = result.attachments.find((a: { name: string; }) => a.name === 'video');
            if (videoAttachment) {
                const genericHelper = new GenericHelper()
                const testCaseId = await genericHelper.extractTestCaseId(test.title);
                const newFileName = `videos/${testCaseId}.webm`;
                try {
                    fs.copyFileSync(videoAttachment.path, newFileName);
                    console.log(`Video saved as: ${newFileName}`);
                } catch (error) {
                    console.error('Error copying video file:', error);
                }
                const videoPath = path.join(__dirname, '../videos', `${testCaseId}.webm`);
                console.log('Video Path: ' + videoPath)
                console.log(`Uploading video for test case: ${testCaseId}`);
                try {
                    await uploadTestAttachment(testCaseId);
                    console.log(`Successfully uploaded video for test case: ${testCaseId}`);
                } catch (error) {
                    console.error(`Failed to upload video for test case: ${testCaseId}`, error);
                }
            }
        }
    }
}

module.exports = VideoReporter;
