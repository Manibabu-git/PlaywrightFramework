import { defineConfig, devices } from '@playwright/test';
import * as dotenv from 'dotenv';


dotenv.config();

const testURL = process.env.TEST_URL || 'https://nebula.stage.charter.com/';
const pid = process.env.PID || 'P3256834';
const environment = process.env.ENVIRONMENT || 'UAT';

export default defineConfig({
  timeout: 1200000,
  globalTimeout: 2400000,
  expect: { timeout: 10000 },
  testDir: './tests',
  testMatch: '**/*.spec.ts',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  //retries: process.env.CI ? 1 : 0,
  workers: 1,
  reporter: [
    ['line'],
    [
      'allure-playwright',
      {
        outputFolder: 'allure-results',
        clean: true,
      },
    ],
    ['junit', { outputFile: 'results.xml' }],
    [
      './globalConfig/video-reporter.ts',
    ]
  ],
  use: {
    browserName: 'chromium',
    ignoreHTTPSErrors: true,
    launchOptions: {
      args: ['--incognito', '--start-maximized']
    },
    headless: false,
    viewport: null, // Important: disables Playwright's default viewport
    screenshot: 'on',
    trace: 'on',
    video: {
      mode: 'on',
      size: { width: 1920, height: 1080 },
    },

    actionTimeout: 10000, // Global timeout for actions

  },
  globalSetup: './globalConfig/global-setup.ts',


  projects: [
    {
      name: 'IaaS_Linux_Suite',
      testDir: './tests/IaaS/Linux',
      fullyParallel: false,

    },
    {
      name: 'IaaS_Ubuntu_Suite',
      testDir: './tests/IaaS/Ubuntu',
      fullyParallel: false,

    },
    {
      name: 'IaaS_Windows_Suite',
      testDir: './tests/IaaS/Windows',
      fullyParallel: false,

    },
    {
      name: 'NaaS_Suite',
      testDir: './tests/NaaS',
      fullyParallel: false,

    },
  ],

  //globalTeardown: './config/global-teardown.ts',
  // projects: [
  //   {
  //     name: 'UAT_Regression',
  //     use: {
  //       browserName: 'chromium'

  //     },
  //   },
  // ],

});
