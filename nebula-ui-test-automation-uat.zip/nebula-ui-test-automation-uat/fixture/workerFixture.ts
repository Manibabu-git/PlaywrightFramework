import { test as baseWorker, Page } from '@playwright/test';
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper'

type WorkerFixtures = {
    appVersion: string;
};


const testURL: string = process.env.TEST_URL!;

export const workerFixture = baseWorker.extend<{}, WorkerFixtures>({
    appVersion: [
        async ({ browser }, use) => {
            const context = await browser.newContext();
            const page = await context.newPage();
            await page.goto(testURL);
            const version = await page.textContent("//h6[contains(text(),'Nebula UI Version:')]");
            saveVariableIntoJsonFile('allure-results\\executor.json', "buildName", version)
            await context.close();
            await use(version || 'unknown');
        },
        { scope: 'worker' }
    ]
});
