import { test as baseTest, BrowserContext, Page } from '@playwright/test';
import { workerFixture } from './workerFixture';
import { PageManager } from '../pages/pageManager';
import { ScreenshotHelper } from '../utilities/uihelpers/screenshotHelper';
import { GenericHelper } from '../utilities/uihelpers/genericHelper';

type TestFixtures = {
  pageManager: PageManager;
  screenshotHelper: ScreenshotHelper;
  genericHelper: GenericHelper;
  context: BrowserContext;
  page: Page;
};

const test = workerFixture.extend<TestFixtures>({
  pageManager: async ({ page }, use) => {
    await use(new PageManager(page));
  },
  screenshotHelper: async ({ page }, use) => {
    await use(new ScreenshotHelper());
  },
  genericHelper: async ({ page }, use) => {
    await use(new GenericHelper());
  }
});

export { test };
export const expect = test.expect;
