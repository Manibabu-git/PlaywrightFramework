import { Locator, Page } from "@playwright/test";
import { MenuItems } from "utilities/enums";
import { HelperBase } from "./helperBase";

export class NavigationPages extends HelperBase {

    readonly userIcon: Locator
    readonly iaasMenu: Locator
    readonly paasMenu: Locator
    readonly myRequests: Locator
    readonly myApprovals: Locator
    readonly myResources: Locator

    constructor(page: Page) {
        super(page)
        this.userIcon = this.page.locator("//div[contains(@class,'MuiAvatar-root')]")
        this.iaasMenu = this.page.locator("//button[@name='iaas']")
        this.paasMenu = this.page.locator("//button[@name='paas']")
        this.myRequests = this.page.locator("//button[@name='/requests']")
        this.myApprovals = this.page.locator("//button[@name='/approvals']")
        this.myResources = this.page.locator("//button[@name='/resources']")
    }

    async navigateToMenuList(menuItem: MenuItems) {
        await this.waitForNumberOfSeconds(5)
        switch (menuItem) {
            case MenuItems.IaaS:
                await this.iaasMenu.click()
                break
            case MenuItems.PaaS:
                await this.paasMenu.click()
                break
            case MenuItems.My_Requests:
                await this.myRequests.click()
                break
            case MenuItems.My_Approvals:
                await this.myApprovals.click()
                break
            case MenuItems.My_Resources:
                await this.myResources.click()
                break
            default:
                console.log("Unknown or Incorrect selection..")
                break
        }
        await this.userIcon.click()
    }

} 
