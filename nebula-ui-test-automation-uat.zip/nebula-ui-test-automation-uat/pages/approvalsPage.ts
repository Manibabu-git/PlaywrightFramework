import { Locator, LocatorScreenshotOptions, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeType, FirewallOrganizations } from "utilities/enums/"
import { GenericHelper } from "utilities/uihelpers/genericHelper";
import { TIMEOUT } from "node:dns/promises";


export class ApprovalsPage extends HelperBase {

    readonly approve: Locator
    readonly reject: Locator
    readonly cancel: Locator
    readonly proceed: Locator
    readonly comment: Locator
    readonly confirmApproval: Locator

    //NaaS Specific Objects
    readonly subRequestSection: Locator

    constructor(page: Page) {
        super(page)
        this.approve = this.page.locator("//button[contains(text(),'Approve')]")
        this.confirmApproval = this.page.locator("(//button[contains(text(),'Approve')])[last()]")
        this.reject = this.page.locator("//button[contains(text(),'Reject')]")
        this.cancel = this.page.getByRole('button', { name: 'Cancel' });
        this.proceed = this.page.getByRole('button', { name: 'Proceed' });
        this.comment = this.page.locator('#comment')
        this.subRequestSection = this.page.getByRole('button', { name: 'Sub Requests' })
    }

    /* 
       Provide request Id as a param that needs to be approved
     */
    async openRequestForApproval(requestId: string) {
        const genericHelper = new GenericHelper()
        const element = await genericHelper.getLinkElementByDynamicText(this.page, requestId);
        await element.waitFor({ timeout: 10000 })
        await element.click();
    }

    /* 
       Click on approve button to approve the request
     */
    async approveRequest() {
        await this.approve.click()
        await this.confirmApproval.click()
    }

    /* 
      Click on reject button to reject the request
   */
    async rejectRequest() {
        await this.reject.click()
    }

    /*
      Provide organization name to Approve Firewall v2 sub-request
    */
    async approveSubRequest(firewwallOrganization: FirewallOrganizations) {
        await this.subRequestSection.click()
        const subRequestLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')]`;
        const subRequestSection = this.page.locator(subRequestLocator);
        await subRequestSection.click()
        const locator = `//h6[contains(text(),'${firewwallOrganization}')]/../../..//button[contains(text(),'Approve')]`;
        const element = this.page.locator(locator);
        await element.click();
        await this.proceed.click()
    }
}