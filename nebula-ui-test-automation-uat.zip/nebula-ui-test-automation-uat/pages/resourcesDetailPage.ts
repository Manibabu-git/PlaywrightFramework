import { expect, Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { IpRuleType, VmSize } from "utilities/enums";

export class ResourcesDetailPage extends HelperBase {

    readonly resourceStatus: Locator
    readonly domain: Locator
    readonly projectName: Locator
    readonly cloudName: Locator
    readonly catalogItem: Locator
    readonly resourceName: Locator
    readonly ipv4Address: Locator
    readonly ipv6Address: Locator
    readonly tags: Locator
    readonly postValidationStatus: Locator
    readonly postProvisionSteps: Locator
    readonly postValidationMessage: Locator
    readonly rubrikSla: Locator
    readonly application: Locator
    readonly environment: Locator
    readonly dataCenter: Locator
    readonly additionalDiskCount: Locator
    readonly additionalDiskSize: Locator
    readonly additionalDiskName: Locator
    readonly additionalDiskFileSystem: Locator
    readonly networkDetailsSection: Locator
    readonly configurationDetails: Locator
    readonly toolDetails: Locator
    readonly tagDetails: Locator
    readonly status: Locator
    readonly layoutName: Locator
    readonly customCores: Locator
    readonly customMemory: Locator
    readonly tanium: Locator
    readonly crowdstrike: Locator
    readonly splunk: Locator
    readonly qualys: Locator
    readonly granite: Locator
    readonly centrify: Locator
    readonly scienceLogic: Locator
    readonly toolsPaginationDropdown: Locator
    readonly pagination40: Locator

    constructor(page: Page) {
        super(page)
        this.resourceStatus = this.page.locator("//h6[contains(text(),'Resource Status')]/../div/h6")
        this.domain = this.page.locator("(//h6[contains(text(),'Domain')]/../div/h6)[last()-1]")
        this.projectName = this.page.locator("//h6[contains(text(),'Project Name')]/../div/h6")
        this.resourceName = this.page.locator("//h6[contains(text(),'Resource Name')]/../div/h6")
        this.cloudName = this.page.locator("//h6[contains(text(),'Cloud Name')]/../div/h6")
        this.catalogItem = this.page.locator("//h6[contains(text(),'Catalog Item')]/../div/h6")
        this.ipv4Address = this.page.locator("//h6[contains(text(),'IPv4 Address')]/../div/h6")
        this.ipv6Address = this.page.locator("//h6[contains(text(),'IPv6 Address')]/../div/h6")
        this.tags = this.page.locator("//h6[contains(text(),'Tags')]/../div/h6")
        this.postProvisionSteps = this.page.locator("//h6[contains(text(),'Steps')]/../div/h6")
        this.postValidationMessage = this.page.locator("//h6[contains(text(),'Validation Message')]/../div/h6")
        this.postValidationStatus = this.page.locator("//h6[contains(text(),'Validation Status')]/../div/h6")
        this.rubrikSla = this.page.locator("//h6[contains(text(),'Rubrik')]/../div/h6")
        this.application = this.page.locator("//h6[contains(text(),'Application')]/../div/h6")
        this.environment = this.page.locator("//h6[contains(text(),'Environment')]/../div/h6")
        this.dataCenter = this.page.locator("//h6[contains(text(),'Data Center')]/../div/h6")
        this.additionalDiskName = this.page.locator("//div[@data-field='diskName']/div[@class='MuiDataGrid-cellContent']")
        this.additionalDiskCount = this.page.locator("//div[@data-field='disk']/div[@class='MuiDataGrid-cellContent']")
        this.additionalDiskSize = this.page.locator("//div[@data-field='diskSize']/div[@class='MuiDataGrid-cellContent']")
        this.additionalDiskFileSystem = this.page.locator("//div[@data-field='diskFileSystem']/div[@class='MuiDataGrid-cellContent']")
        this.networkDetailsSection = this.page.getByRole('button', { name: 'Network Details' })
        this.status = this.page.locator("//h6[contains(text(),'Network Details')]/../../../../..//h6[contains(text(),'Status')]/../div/h6")
        this.layoutName = this.page.locator("//h6[contains(text(),'Layout Name')]/../div/h6")
        this.configurationDetails = this.page.getByRole('button', { name: 'Configuration Details' })
        this.customCores = this.page.locator("//h6[contains(text(),'Custom Cores')]/../div/h6")
        this.customMemory = this.page.locator("//h6[contains(text(),'Custom Memory')]/../div/h6")
        this.toolDetails = this.page.getByRole('button', { name: 'Tool Details' })
        this.qualys = this.page.locator('g#Qualys_2017')
        this.tanium = this.page.locator('g#Layer_1')
        this.splunk = this.page.locator('#Splunk_logo_1_')
        this.crowdstrike = this.page.locator('g#Group_171646')
        this.granite = this.page.locator('g#Group_172616')
        this.centrify = this.page.locator('g#g3075')
        this.scienceLogic = this.page.locator('g#sciencelogic-seeklogo')
        this.tagDetails = this.page.getByRole('button', { name: 'Tag Details' })
        this.pagination40 = this.page.locator("//li[@data-value='40']")
        this.toolsPaginationDropdown = this.page.locator("//h6[contains(text(),'Tool Details')]/../../../../..//div[@aria-label='Select Option']")
    }

    async retrieveResourceStatus() {
        return await this.resourceStatus.textContent()
    }

    async retrieveIpAddress(ipType: IpRuleType) {
        let address;
        if (IpRuleType.ipv4) {
            address = await this.ipv4Address.textContent()
        }
        else {
            address = await this.ipv6Address.textContent()
        }
        return address
    }

    async retrieveDomain() {
        return await this.domain.textContent()
    }

    async retrieveProject() {
        return await this.projectName.textContent()
    }

    async retrieveEnvironment() {
        return await this.environment.textContent()
    }

    async retrieveApplication() {
        return await this.application.textContent()
    }

    async retrieveCloudName() {
        return await this.cloudName.textContent()
    }

    async retrieveResourceName() {
        return await this.resourceName.textContent()
    }

    async retrieveCatalogItem() {
        return await this.catalogItem.textContent()
    }

    async retrieveTags() {
        return await this.tags.textContent()
    }

    async retrievePostProvisionSteps() {
        return await this.postProvisionSteps.textContent()
    }

    async retrievePostValidationStatus() {
        return await this.postValidationStatus.textContent()
    }

    async retrievePostValidationMessage() {
        return await this.postValidationMessage.textContent()
    }

    async retrieveCustomCore() {
        return await this.customCores.textContent()
    }

    async retrieveCustomMemory() {
        return await this.customMemory.textContent()
    }

    async retrieveAdditionalDiskCount() {
        return await this.additionalDiskCount.textContent()
    }

    async retrieveAdditionalDiskSize() {
        return await this.additionalDiskSize.textContent()
    }

    async retrieveAdditionalDiskName() {
        return await this.additionalDiskName.textContent()
    }

    async retrieveAdditionalDiskFileSystem() {
        return await this.additionalDiskFileSystem.textContent()
    }

    async retrieveLayoutName() {
        return await this.layoutName.textContent()
    }

    async retrieveDataCenter() {
        return await this.dataCenter.textContent()
    }

    async openNetworkDetails() {
        await this.networkDetailsSection.click()
    }
    async openToolsDetails() {
        await this.toolDetails.click()
    }

    async retrieveRubrikDetails() {
        await this.rubrikSla.textContent()
    }

    async verifyNetworkDetails(domain: string, rubrik: string, layout: string) {
        const layoutText = await this.layoutName.textContent()
        expect(layoutText).toBe(layout)
        if (domain.includes("STAMP")) {
            const rubrikSla = await this.rubrikSla.textContent()
            expect(rubrikSla).toBe(rubrik)
        }
    }

    async verifyToolsSection(toolsRecord: Record<string, boolean>) {
        const toolLocators: Record<string, Locator> = {
            Tanium: this.tanium,
            Qualys: this.qualys,
            CrowdStrike: this.crowdstrike,
            Granite: this.granite,
            Centrify: this.centrify,
            Splunk: this.splunk
        };

        for (const [toolName, isEnabled] of Object.entries(toolsRecord)) {
            if (isEnabled && toolLocators[toolName]) {
                const toolLocator = toolLocators[toolName];

                // Check if the tool is present or not
                const isToolVisible = await toolLocator.isVisible().catch(() => false);
                if (!isToolVisible) {
                    continue;
                }

                const rowWithTool = this.page.locator('[role="row"]', {
                    has: toolLocator,
                });

                const successChip = rowWithTool.locator('[id^="chip-"][title="SUCCESS"]').first();
                if (successChip) {
                    await expect(successChip).toHaveAttribute('title', 'SUCCESS');
                }
            }
        }
    }

    async retrieveToolsRecord(toolsRecord: Record<string, boolean>) {
        await this.toolsPaginationDropdown.click()
        await this.pagination40.click()
        await this.waitForNumberOfSeconds(3)
        const toolLocators: Record<string, Locator> = {
            Tanium: this.tanium,
            Qualys: this.qualys,
            CrowdStrike: this.crowdstrike,
            Granite: this.granite,
            Centrify: this.centrify,
            Splunk: this.splunk,
            ScienceLogic: this.scienceLogic
        };

        const toolCategories: Record<string, string> = {
            Tanium: "Compliance",
            Qualys: "Security",
            CrowdStrike: "Security",
            Granite: "Inventory",
            Centrify: "Security",
            Splunk: "Observability",
            ScienceLogic: "Observability"
        };

        const categorizedTools: Record<string, string[]> = {};

        for (const [toolName, isEnabled] of Object.entries(toolsRecord)) {
            if (isEnabled && toolLocators[toolName]) {
                const toolLocator = toolLocators[toolName];

                const isToolVisible = await toolLocator.isVisible().catch(() => false);
                if (!isToolVisible) continue;

                const rowWithTool = this.page.locator('[role="row"]', {
                    has: toolLocator,
                });

                const successChip = rowWithTool.locator('[id^="chip-"][title="SUCCESS"]').first();
                const isSuccess = await successChip.isVisible().catch(() => false);

                if (isSuccess) {
                    await expect(successChip).toHaveAttribute('title', 'SUCCESS');

                    const category = toolCategories[toolName];
                    if (category) {
                        if (!categorizedTools[category]) {
                            categorizedTools[category] = [];
                        }
                        categorizedTools[category].push(toolName);
                    }
                }
            }
        }

        console.log("Successful Tools:", JSON.stringify(categorizedTools, null, 2));
        return categorizedTools;
    }


    async verifyConfigurationDetails(vmSize: string, customCores?: string, customMemory?: string, diskCount?: string, additionalDiskDetail?: string) {
        await this.configurationDetails.click()
        switch (vmSize) {
            case VmSize.Custom:
                const cpu = await this.customCores.textContent()
                const memory = await this.customMemory.textContent()
                expect(cpu).toBe(customCores)
                expect(memory).toContain(customMemory)
                break
        }

        const diskC = await this.additionalDiskCount.textContent()
        expect(diskC).toBe(diskCount)
        const diskDetails = await this.additionalDiskSize.textContent()
        expect(diskDetails).toContain(additionalDiskDetail)

    }

}