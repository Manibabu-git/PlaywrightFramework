import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeType } from "utilities/enums/"
import { GenericHelper } from "utilities/uihelpers/genericHelper";

export class MyRequestsPage extends HelperBase {

    readonly trackRequest: Locator


    constructor(page: Page) {
        super(page)
        this.trackRequest = this.page.locator("//button[contains(text(),'Track Request')]")

    }

    async trackMyRequest() {
        await this.waitForNumberOfSeconds(3)
        await this.trackRequest.click()
    }

    /* 
        Provide request Id as a param that needs to be viewed
    */
    async openRequestToViewDetails(requestId: string) {
        const genericHelper = new GenericHelper()
        const element = await genericHelper.getLinkElementByDynamicText(this.page, requestId);
        await element.click();
    }
}