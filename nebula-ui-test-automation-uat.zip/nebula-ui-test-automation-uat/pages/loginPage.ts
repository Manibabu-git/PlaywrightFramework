import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeType, UserTypes } from "utilities/enums/"

export class LoginPage extends HelperBase {

    readonly username: Locator
    readonly password: Locator
    readonly login: Locator

    constructor(page: Page) {
        super(page)
        this.username = this.page.locator("//input[@placeholder='Username']")
        this.password = this.page.locator("//input[@placeholder='Password']")
        this.login = this.page.locator("//input[@value='Login']")
    }

    async loginToNebula(userType: UserTypes) {
        await this.waitForNumberOfSeconds(2)
        let uname: string
        var pass: string;
        const local: string = process.env.LOCAL!;
        if (await this.username.isVisible()) {
            if (local === 'No') {
                uname = process.env.REQUESTOR_USER_NAME!;

                if (userType === UserTypes.Requestor) {
                    pass = process.env.REQUESTOR_USER_PASSWORD!;
                }
                else {
                    pass = process.env.APPROVER_USER_PASSWORD!;

                }
            }
            else {
                uname = process.env.REQUESTOR_USER_NAME!
                pass = process.env.REQUESTOR_USER_PASSWORD!;
            }
            await this.username.fill(uname)
            await this.password.fill(pass)
            await this.login.click()
        }
    }
}