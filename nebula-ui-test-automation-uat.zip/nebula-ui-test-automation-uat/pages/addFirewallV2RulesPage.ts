import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { GenericHelper } from "utilities/uihelpers/genericHelper";
import { readJsonFile } from "utilities/uihelpers/jsonHelper";
import { IpRuleType, Protocol } from "utilities/enums";


export class AddFirewallV2RulesPage extends HelperBase {

    readonly buildRequest: Locator
    readonly projectDropdown: Locator
    readonly project: Locator
    readonly summaryName: Locator
    readonly chooseDate: Locator
    readonly calendarView: Locator
    readonly year: Locator
    readonly date: Locator
    readonly supportOrganization: Locator
    readonly orgName: Locator
    readonly regionHeader: Locator
    readonly regionDropdown: Locator
    readonly regionName: Locator
    readonly tops: Locator
    readonly addFirewallRules: Locator
    readonly newRule: Locator
    readonly sourceIp: Locator
    readonly destinationIp: Locator
    readonly sourcePort: Locator
    readonly destinationPort: Locator
    readonly protocol: Locator
    readonly add: Locator
    readonly bulkImport: Locator
    readonly chooseFile: Locator
    readonly ipv4Tab: Locator
    readonly rulesValidationMessage: Locator
    readonly ipv6RuleMessage: Locator
    readonly submit: Locator
    readonly ipv6Tab: Locator

    intakeFormData = readJsonFile('./TestData/firewallV2IntakeFormData.json');

    constructor(page: Page) {
        super(page)
        this.buildRequest = this.page.getByRole('button', { name: 'Build Request Please enter' })
        this.projectDropdown = this.page.getByRole('gridcell', { name: 'Project* Open Project is' }).getByLabel('Open')
        this.project = this.page.getByText('uat-test-project')
        this.summaryName = this.page.getByLabel('Summary Name*')
        this.chooseDate = this.page.getByLabel('Choose date')
        this.calendarView = this.page.getByLabel('calendar view is open, switch')
        this.year = this.page.getByRole('radio', { name: '2027' })
        this.date = this.page.getByRole('gridcell', { name: '30', exact: true })
        this.supportOrganization = this.page.getByRole('gridcell', { name: 'Support Organization* Open' }).locator('div').nth(3)
        this.orgName = this.page.getByText('Accessibility', { exact: true })
        this.regionHeader = this.page.locator("//label[contains(text(),'Region')]")
        this.regionDropdown = this.page.getByLabel('Please select')
        this.regionName = this.page.getByRole('option', { name: 'Central' })
        this.tops = this.page.getByPlaceholder('Please enter ticket number')
        this.addFirewallRules = this.page.getByRole('button', { name: 'Add Firewall Rules Please add' })
        this.newRule = this.page.getByRole('button', { name: 'New Rule' })
        this.sourceIp = this.page.getByLabel('Source IP Address*')
        this.destinationIp = this.page.getByLabel('Destination IP Address*')
        this.protocol = this.page.getByText('Select')
        this.sourcePort = this.page.locator("//input[@id='source.port']")
        this.destinationPort = this.page.locator("//input[@id='destination.port']")
        this.add = this.page.getByRole('button', { name: 'Add', exact: true })
        this.bulkImport = this.page.getByRole('button', { name: 'Bulk Import' })
        this.chooseFile = this.page.locator("//label[contains(text(),'Choose File')]")
        this.ipv4Tab = this.page.getByRole('tab', { name: 'IPv4' })
        this.ipv6Tab = this.page.getByRole('tab', { name: 'IPv6' })
        this.ipv6RuleMessage = this.page.getByText('IPv6 addresses will be')
        this.rulesValidationMessage = this.page.getByText('Success:All rules have been')
        this.submit = this.page.getByRole('button', { name: 'Submit' })

    }

    async openBuildRequestIntakeForm() {
        await this.buildRequest.click()
    }

    async fillV2IntakeForm() {
        const genericHelper = new GenericHelper()
        let random = await genericHelper.generateRandomString(2)
        await this.projectDropdown.click()
        await this.project.click()
        await this.summaryName.fill('Firewall V2 Test Summary_' + random)
        await this.chooseDate.click()
        this.waitForNumberOfSeconds(1)
        await this.calendarView.click()
        await this.year.click()
        await this.date.click()

        this.waitForNumberOfSeconds(2)
        await this.supportOrganization.click()
        await this.orgName.click()
        await this.regionDropdown.click()
        await this.regionName.click()
        this.waitForNumberOfSeconds(2)
        await this.page.keyboard.press('Escape');
    }

    async enterTopTicket() {
        await this.tops.click()
        await this.tops.fill(this.intakeFormData.topsTicket)
    }

    async selectAddFirewallRules() {
        this.waitForNumberOfSeconds(2)
        await this.addFirewallRules.click()
    }

    async addRulesManually(ipRuleType: IpRuleType, protocol: Protocol) {
        await this.newRule.click()
        await this.waitForNumberOfSeconds(2)
        if (ipRuleType === "ipv6") {
            await this.sourceIp.click()
            await this.sourceIp.fill(this.intakeFormData.sourceIpv6)
            await this.destinationIp.click()
            await this.destinationIp.fill(this.intakeFormData.destinationIpv6)
        }
        else {
            await this.sourceIp.click()
            await this.sourceIp.fill(this.intakeFormData.sourceIpv4)
            await this.destinationIp.click()
            await this.destinationIp.fill(this.intakeFormData.destinationIpv4)
        }
        await this.protocol.click()
        if (protocol === "TCP") {
            await this.page.getByRole('option', { name: 'TCP' }).click()
        }

        await this.sourcePort.fill("3000")
        await this.destinationPort.fill("3100")
        await this.add.click()
    }


    async addRulesViaBulkImport(filename: string) {
        await this.bulkImport.click();
        const [fileChooser] = await Promise.all([
            this.page.waitForEvent('filechooser'),
            await this.waitForNumberOfSeconds(3),
            this.chooseFile.click(),
            await this.waitForNumberOfSeconds(5),
        ]);
        await fileChooser.setFiles("TestData\\" + filename);
        this.waitForNumberOfSeconds(5)
        // await this.page.keyboard.press("Enter");
    }


    async getAllRulesSuccessMessage(): Promise<string> {
        await this.waitForNumberOfSeconds(3)
        const message = await this.rulesValidationMessage.textContent();
        if (typeof message !== 'string') {
            throw new Error('Incorrect Success message');
        }
        return message;
    }


    async getIpv6RuleMessage(): Promise<string> {
        const message = await this.ipv6RuleMessage.textContent();
        if (typeof message !== 'string') {
            throw new Error('Incorrect Success message');
        }
        return message;
    }

    async changeTab(ipRuleType: IpRuleType) {
        if (ipRuleType === "ipv6") {
            await this.ipv6Tab.click()
        }
        else {
            await this.ipv4Tab.click()
        }
    }

    async submitFirewallRequest() {
        await this.waitForNumberOfSeconds(3)
        await this.submit.click()
    }

}
