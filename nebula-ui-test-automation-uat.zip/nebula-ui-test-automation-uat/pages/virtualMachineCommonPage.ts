import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import {
    Cluster, ComplianceTools, ComputeCatalog, DiskFileSystem, InventoryTools,
    IpModes, IpRuleType, ObservabilityTools, RubrikSla, SecurityTools, VmSize
} from "utilities/enums/"


export class VirtualMachineCommonPage extends HelperBase {

    //Vm Details
    readonly domain: Locator
    readonly application: Locator
    readonly environment: Locator
    readonly projectDropdown: Locator
    readonly projectDatacenter: Locator
    readonly osVersionDropdown: Locator
    readonly sshKey: Locator
    readonly rubrikSlaDropdown: Locator
    readonly applicationInstanceDropDown: Locator
    readonly description: Locator
    readonly initialPassword: Locator
    readonly vmCount: Locator
    readonly hostname: Locator
    readonly vmSizeDropdown: Locator
    readonly noOfCoresDropdown: Locator
    readonly memoryDropdown: Locator
    readonly submitCustomSize: Locator
    readonly addDisk: Locator
    readonly additionalDiskDropdown: Locator
    readonly fileSystem: Locator
    readonly disk2Size: Locator
    readonly disk2MountPoint: Locator
    readonly addDiskFormButton: Locator
    readonly addTag: Locator
    readonly addTagDropdown: Locator
    readonly devOwnerTag: Locator
    readonly tagValue: Locator
    readonly submitTag: Locator
    readonly next: Locator
    readonly startingSequence: Locator
    readonly vmSizeDetails: Locator

    //Network Details
    readonly selectDatacenterDropdown: Locator
    readonly datacenter: Locator
    readonly selectNetwork: Locator
    readonly network: Locator
    readonly ipModes: Locator
    readonly selectCluster: Locator
    readonly selectGroup: Locator
    readonly ipv4: Locator
    readonly ipv6: Locator
    readonly addManual: Locator
    readonly selectFromIpList: Locator
    readonly selectHost: Locator
    readonly hostName: Locator
    readonly ipv4Tab: Locator
    readonly ipv6Tab: Locator
    readonly addIpButton: Locator
    readonly addIpv4: Locator
    readonly addIpv6: Locator
    //Tools Details
    readonly crowdstrike: Locator
    readonly centrify: Locator
    readonly qualys: Locator
    readonly tanium: Locator
    readonly splunk: Locator
    readonly vmTools: Locator
    readonly granite: Locator
    readonly scienceLogic: Locator
    readonly submit: Locator


    constructor(page: Page) {
        super(page)
        //Vm Details
        this.domain = this.page.locator("#domain")
        this.application = this.page.getByLabel('Application*')
        this.environment = this.page.getByLabel('Environment*')
        this.projectDropdown = this.page.locator("//input[@name='projectName']")
        this.projectDatacenter = this.page.locator("//div[@id='datacenter']")
        this.osVersionDropdown = this.page.locator("//input[@name='targetLayout']")
        this.sshKey = this.page.getByRole('textbox', { name: 'SSH Key' })
        this.rubrikSlaDropdown = this.page.locator("//div[@id='rubrikSLA']")
        this.applicationInstanceDropDown = this.page.getByText('Select', { exact: true })
        this.description = this.page.getByRole('textbox', { name: 'Description' })
        this.vmCount = this.page.locator("#vmCount")
        this.initialPassword = this.page.getByRole('textbox', { name: 'Initial Password' })
        this.hostname = this.page.getByRole('textbox', { name: 'Hostname*' })
        this.startingSequence = this.page.locator("#sequenceNumber")
        this.vmSizeDropdown = this.page.getByRole('combobox', { name: 'VM Size*' })
        this.noOfCoresDropdown = this.page.locator('#noOfCores').getByText('Select')
        this.memoryDropdown = this.page.getByText('Select', { exact: true })
        this.submitCustomSize = this.page.getByRole('button', { name: 'Submit' })
        this.vmSizeDetails = this.page.locator("//h3[contains(text(),'VM Size Details')]/../div//h6")
        this.addDisk = this.page.getByRole('button', { name: 'Add Disk' })
        this.additionalDiskDropdown = this.page.locator("//div[@id='diskCount']")
        this.fileSystem = this.page.locator('#diskFileSystem')
        this.disk2Size = this.page.locator("//input[@name='addDisks.0.diskValue']")
        this.disk2MountPoint = this.page.locator("//input[@name='addDisks.0.diskName']")
        this.addDiskFormButton = this.page.locator('#add-disk-form-btn')
        this.addTag = this.page.getByRole('button', { name: 'Add Tag' })
        this.addTagDropdown = this.page.getByText('Select', { exact: true })
        this.devOwnerTag = this.page.locator('#select-DevOwner-option')
        this.tagValue = this.page.getByRole('textbox', { name: 'Tag Value *' })
        this.submitTag = this.page.getByRole('button', { name: 'Submit' })
        this.next = this.page.getByRole('button', { name: 'Next' })
        //Network Details
        this.selectDatacenterDropdown = this.page.locator('#datacenter')
        this.datacenter = this.page.locator('#select-STAMP-option')
        this.selectNetwork = this.page.locator("//input[@id='network']")
        this.network = this.page.locator("//li[@id=':rkc:-option-0']")
        this.ipModes = this.page.getByText('Static-Auto')
        this.selectCluster = this.page.locator("//div[@id='resourceId']")
        this.selectGroup = this.page.locator('#groupId')
        this.ipv4 = this.page.getByRole('checkbox', { name: 'IPv4' })
        this.ipv6 = this.page.getByRole('checkbox', { name: 'IPv6' })
        this.addManual = this.page.getByTestId("vm-add-manual-btn")
        this.addIpv4 = this.page.locator("//input[@id='ipv4Addresses.0']")
        this.addIpv6 = this.page.locator("//input[@id='ipv6Addresses.0']")
        this.selectFromIpList = this.page.getByRole('button', { name: 'Select from IP List' })
        this.selectHost = this.page.locator("(//p[contains(text(),'Select a host')])[1]")
        this.hostName = this.page.locator("//li[@role='option']")
        this.ipv4Tab = this.page.getByRole('tab', { name: 'IPv4' })
        this.ipv6Tab = this.page.getByRole('tab', { name: 'IPv6' })
        this.addIpButton = this.page.getByRole('button', { name: 'Add', exact: true })
        //Tools Details
        this.crowdstrike = this.page.locator('#crowdstrike')
        this.centrify = this.page.locator('#centrify')
        this.qualys = this.page.locator('#qualys')
        this.tanium = this.page.locator('#tanium')
        this.splunk = this.page.locator('#splunk')
        this.vmTools = this.page.locator('#vmTools')
        this.granite = this.page.locator('#granite')
        this.scienceLogic = this.page.locator('#scienceLogic')
        this.submit = this.page.getByRole('button', { name: 'Submit' })
    }

    async selectDomain(domainName: string) {
        this.waitForNumberOfSeconds(3)
        await this.domain.click()
        await this.page.getByRole('option', { name: `${domainName}` }).click()
    }

    async selectApplication(appName: string) {
        await this.application.click()
        await this.page.getByRole('option', { name: `${appName}` }).click();
    }

    async selectEnvironment(environmentValue: string) {
        await this.environment.click()
        await this.page.getByText(`${environmentValue}`).click();

    }

    async selectDatacenter(datacenter: string) {
        await this.projectDatacenter.click()
        await this.page.getByText(`${datacenter}`).click()
    }

    async selectProjectId(projectId: string) {
        await this.projectDropdown.click()
        const projectIdLocator = `(//p[contains(text(),'${projectId}')])[1]`;
        const project = this.page.locator(projectIdLocator);
        await project.click()
    }

    async selectOsVersion(OsVersion: string) {
        await this.osVersionDropdown.click();
        const os = this.page.getByRole('option', { name: `${OsVersion}` });
        await os.click();
    }

    async enterSshKey(sshKey: string) {
        await this.sshKey.fill(sshKey)
    }

    async selectRubrikSla(domain: string, rubrikSla: string) {
        if (!domain.includes("CharterLab")) {
            this.waitForNumberOfSeconds(1)
            await this.rubrikSlaDropdown.click()
            const rubrik = this.page.getByRole('option', { name: `${rubrikSla}` })
            await rubrik.click()
        }
    }

    async selectApplicationInstance(appInstance: string) {
        this.waitForNumberOfSeconds(1)
        await this.applicationInstanceDropDown.click()
        const appIns = this.page.getByRole('option', { name: `${appInstance}` })
        appIns.click()
    }

    async addDescription(description: string) {
        await this.description.fill(description)
    }

    async addInitialPassword() {
        await this.initialPassword.clear()
        await this.initialPassword.fill('Capgemini@1234')
    }

    async updateVmCount(isMulti: boolean, vmCount: string, startingSequence: string) {
        if (isMulti) {
            await this.vmCount.clear()
            await this.vmCount.fill(vmCount)
            this.addStartingSequence(startingSequence)
        }
    }

    async addStartingSequence(sequence: string) {
        await this.startingSequence.clear()
        await this.startingSequence.fill(sequence)
    }

    async enterHostname(host: string) {
        await this.hostname.fill(host)
    }

    async selectVmSize(vmSize: string, customCores?: string, customMemory?: string) {
        await this.vmSizeDropdown.click()
        //  const size = this.page.locator(`role=option >> text=/${vmSize}/`);
        const size = this.page.getByText(`${vmSize}`);
        await this.waitForNumberOfSeconds(1)
        await size.click()
        switch (vmSize) {
            case VmSize.Custom:
                await this.noOfCoresDropdown.click()
                await this.page.getByRole('option', { name: `${customCores}`, exact: true }).click();
                await this.memoryDropdown.click()
                await this.page.getByRole('option', { name: `${customMemory}` }).click();
                await this.submitCustomSize.click()
                break
            case VmSize.Small:
                break
            case VmSize.Large:
                break
            case VmSize.Medium: {
                break
            }
        }
    }

    async addAdditionalDisk(toAdd: any, vmType: string, noOfDisk: string, fileSystem?: string) {
        if (typeof (toAdd === Boolean) && toAdd) {
            await this.addDisk.click()
            await this.additionalDiskDropdown.click()
            await this.page.getByRole('option', { name: `${noOfDisk}` }).click();
            this.waitForNumberOfSeconds(1)

            if (vmType === ComputeCatalog.Linux || vmType === ComputeCatalog.Ubuntu ||
                vmType === ComputeCatalog.Linux_Admin || vmType === ComputeCatalog.Ubuntu_Admin
            ) {
                await this.fileSystem.click()
                await this.page.getByRole('option', { name: `${fileSystem}` }).click()
            }
            this.waitForNumberOfSeconds(1)
            await this.disk2Size.fill('15')
            await this.disk2MountPoint.fill('nebula/mount')
            await this.addDiskFormButton.click()
        }
    }

    async addTags() {
        await this.addTag.click()
        this.waitForNumberOfSeconds(1)
        await this.addTagDropdown.click()
        this.waitForNumberOfSeconds(1)
        await this.devOwnerTag.click()
        await this.tagValue.fill('devowner')
        await this.submitTag.click()
    }

    async goNext() {
        this.waitForNumberOfSeconds(2)
        await this.next.click()
    }

    async selectDataCenter() {
        await this.selectDatacenterDropdown.click()
        this.waitForNumberOfSeconds(3)
        await this.datacenter.click()
    }

    async selectNetworkDetails(datacenter: string) {
        await this.selectNetwork.click()
        this.waitForNumberOfSeconds(1)
        //await this.network.click()
        if (datacenter === "CDP") {
            await this.page.locator('ul[role="listbox"] >> li').last().click();
        }
        else if (datacenter === "CTEC") {
            await this.page.locator('ul[role="listbox"] >> li').last().click();
        }
        else {
            await this.page.locator('ul[role="listbox"] >> li').first().click();
        }
    }

    async selectIpModes(domain: string, ipModes: string) {
        await this.waitForNumberOfSeconds(10)
        if (!domain.includes("CharterLab")) {
            await this.waitForNumberOfSeconds(10)
            await this.ipModes.click()
            await this.page.getByRole('option', { name: `${ipModes}` }).click();
        }
    }

    async selectGroups(groupName: string) {
        await this.selectGroup.click()
        await this.page.getByRole('option', { name: `${groupName}` }).click()
    }

    async selectClusterDetails(catalog: string, dataCenter: string) {
        if (catalog.includes("Admin") && dataCenter === "CTEC") {
            await this.waitForNumberOfSeconds(2)
            await this.selectCluster.click()
            await this.page.locator("//li[contains(@id,'select')][1]").click();
        }
    }

    async selectIpType(ipRuleType: string) {

        switch (ipRuleType) {
            case IpRuleType.ipv4:
                await this.ipv6.uncheck()
                await this.ipv4.check()
                break
            case IpRuleType.ipv6:
                await this.ipv6.check()
                await this.ipv4.uncheck()
                break
            case IpRuleType.ipv4v6:
                await this.ipv6.check()
                await this.ipv4.check()
                break
        }

    }

    async selectIpFromList(domain: string, ipRuleType: string, ipModes: string, v4: string, v6: string) {
        if (domain.includes("CharterLab")) {
            await this.addManual.click()
            switch (ipRuleType) {
                case IpRuleType.ipv4:
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv4.click()
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv4.fill(v4)
                    break
                case IpRuleType.ipv6:
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv6.click()
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv6.fill(v6)
                    break
                case IpRuleType.ipv4v6:
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv4.click()
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv4.fill(v4)
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv6.click()
                    await this.waitForNumberOfSeconds(2)
                    await this.addIpv6.fill(v6)
                    break
                default:
                    break
            }
            await this.waitForNumberOfSeconds(3)
            await this.addIpButton.click()
        }
        else {
            if (ipModes === IpModes.Static_Manual) {
                await this.selectFromIpList.click()
                await this.waitForNumberOfSeconds(5)
                await this.selectHost.click()
                let size = await this.hostName.count()
                let counter = 0
                for (let i = 0; i < size; i++) {
                    counter = i + 1;
                    await this.page.locator(`//li[@role='option'][${i}+1]`).click()
                    if (counter < size) {
                        await this.selectHost.click()
                    }
                }
                if (ipRuleType === IpRuleType.ipv4v6) {
                    this.waitForNumberOfSeconds(1)
                    await this.ipv6Tab.click()
                    for (let i = 0; i < size; i++) {
                        counter = i + 1;
                        await this.page.locator(`//li[@role='option'][${i}+1]`).click()
                        if (counter < size) {
                            await this.selectHost.click()
                        }
                    }
                }
                await this.waitForNumberOfSeconds(3)
                await this.addIpButton.click()
            }
        }

    }

    async selectSecurityTools(securityTools?: SecurityTools) {
        switch (securityTools) {
            case SecurityTools.Centrify:
                if (await this.centrify.isEnabled())
                    await this.centrify.check()
                break
            case SecurityTools.CrowdStrike:
                if (await this.crowdstrike.isEnabled())
                    await this.crowdstrike.check()
                break
            case SecurityTools.Qualys:
                if (await this.qualys.isEnabled())
                    await this.qualys.check()
                break
            default:
                break

        }
    }

    async selectObservabilityTools(observabilityTools?: ObservabilityTools) {
        switch (observabilityTools) {
            case ObservabilityTools.ScienceLogic:
                //ToDO:
                break
            case ObservabilityTools.Splunk:
                if (await this.splunk.isEnabled()) {
                    await this.splunk.check()
                }
                break
            case ObservabilityTools.VmTools:
                if (await this.vmTools.isVisible()) {
                    await this.vmTools.check()
                }
                break
            default:
                await this.vmTools.check()
                break
        }

    }

    async selectComplianceTools(complainceTools?: ComplianceTools) {
        switch (complainceTools) {
            case ComplianceTools.Tanium:
                if (await this.tanium.isEnabled())
                    await this.tanium.check()
                break
            default:
                break
        }
    }

    async selectInventoryTools(inventoryTools?: InventoryTools) {
        switch (inventoryTools) {
            case InventoryTools.Granite:
                if (await this.granite.isEnabled())
                    await this.granite.check()
            default:
                break
        }
    }

    async selectTools(securityTools?: SecurityTools[], observabilityTools?: ObservabilityTools[],
        complianceTools?: ComplianceTools[], inventoryTools?: InventoryTools[]) {
        if (securityTools) {
            for (const tool of securityTools) {
                await this.selectSecurityTools(tool);
            }
        }

        if (observabilityTools) {
            for (const tool of observabilityTools) {
                await this.selectObservabilityTools(tool);
            }
        }

        if (complianceTools) {
            for (const tool of complianceTools) {
                await this.selectComplianceTools(tool);
            }
        }

        if (inventoryTools) {
            for (const tool of inventoryTools) {
                await this.selectInventoryTools(tool);
            }
        }
    }

    async getSelectedToolsRecord() {
        const toolsRecord: Record<string, boolean> = {};

        const toolLocators = {
            Centrify: this.centrify,
            CrowdStrike: this.crowdstrike,
            Qualys: this.qualys,
            ScienceLogic: this.scienceLogic,
            Splunk: this.splunk,
            Granite: this.granite,
            Tanium: this.tanium
        };

        for (const [toolName, locator] of Object.entries(toolLocators)) {
            const count = await locator.count();
            if (count > 0) {
                const isChecked = await locator.evaluate((el: HTMLInputElement) => el.checked);
                toolsRecord[toolName] = isChecked;
            } else {
                toolsRecord[toolName] = false;
            }
        }

        return toolsRecord;
    }

    async submitVmRequest() {
        await this.submit.click()
    }

    async retrieveVmSizing() {

        const elements = await this.page.$$eval("//h3[contains(text(),'VM Size Details')]/../div//h6", nodes => nodes.map(n => n.textContent?.trim() ?? ''));

        // Step 2: Create vmSizeDetails record
        const vmSizeDetails: Record<string, string> = {};
        for (let i = 0; i < elements.length; i += 2) {
            const key = elements[i];
            const value = elements[i + 1];
            if (key && value) {
                vmSizeDetails[key] = value;
            }
        }
        return vmSizeDetails;

    }
}

