import { Page } from '@playwright/test'
import { NavigationPages } from './navigationPages'
import { IaasPage } from './iaasPage'
import { ComputePage } from './computePage'
import { MyRequestsPage } from './myRequestsPage'
import { ApprovalsPage } from './approvalsPage'
import { LoginPage } from './loginPage'
import { SecurityPage } from './securityPage'
import { AddFirewallV2RulesPage } from './addFirewallV2RulesPage'
import { MyRequestsViewDetailsPage } from './myRequestViewDetailsPage'
import { VirtualMachineCommonPage } from './virtualMachineCommonPage'
import { VirtualMachineCorpnetPage } from './virtualMachineCorpnetPage'
import { RequestConfirmationPage } from './requestConfirmationPage'
import { ResourcesDetailPage } from './resourcesDetailPage'
import { ResourcesPage } from './resourcesPage'
import { HelperBase } from './helperBase'

export class PageManager {

    private readonly page: Page
    private readonly navigationPage: NavigationPages
    private readonly iaasPage: IaasPage
    private readonly computepage: ComputePage
    private readonly myRequestsPage: MyRequestsPage
    private readonly loginPage: LoginPage
    private readonly securityPage: SecurityPage
    private readonly addFirewallV2RulesPage: AddFirewallV2RulesPage
    private readonly approvalsPage: ApprovalsPage
    private readonly myRequestViewDetailsPage: MyRequestsViewDetailsPage
    private readonly virtualMachineCommonPage: VirtualMachineCommonPage
    private readonly virtualMachineCorpnetPage: VirtualMachineCorpnetPage
    private readonly requestConfirmationPage: RequestConfirmationPage
    private readonly resourcesDetailPage: ResourcesDetailPage
    private readonly resourcesPage: ResourcesPage
    private readonly helperBase: HelperBase

    constructor(page: Page) {
        this.page = page
        this.navigationPage = new NavigationPages(this.page)
        this.iaasPage = new IaasPage(this.page)
        this.computepage = new ComputePage(this.page)
        this.myRequestsPage = new MyRequestsPage(this.page)
        this.loginPage = new LoginPage(this.page)
        this.securityPage = new SecurityPage(this.page)
        this.addFirewallV2RulesPage = new AddFirewallV2RulesPage(this.page)
        this.approvalsPage = new ApprovalsPage(this.page)
        this.myRequestViewDetailsPage = new MyRequestsViewDetailsPage(this.page)
        this.virtualMachineCommonPage = new VirtualMachineCommonPage(this.page)
        this.virtualMachineCorpnetPage = new VirtualMachineCorpnetPage(this.page)
        this.requestConfirmationPage = new RequestConfirmationPage(this.page)
        this.resourcesDetailPage = new ResourcesDetailPage(this.page)
        this.resourcesPage = new ResourcesPage(this.page)
        this.helperBase = new HelperBase(this.page)
    }

    onHelperBasePage() {
        return this.helperBase
    }

    navigateTo() {
        return this.navigationPage
    }

    onIaasHomePage() {
        return this.iaasPage
    }

    onSecurityHomePage() {
        return this.securityPage
    }

    onComputeHomePage() {
        return this.computepage
    }

    onMyRequestsHomePage() {
        return this.myRequestsPage
    }

    onLoginPage() {
        return this.loginPage
    }

    onAddFirewallV2RulesPage() {
        return this.addFirewallV2RulesPage
    }

    onApprovalsPage() {
        return this.approvalsPage
    }

    onMyRequestViewDetailsPage() {
        return this.myRequestViewDetailsPage
    }

    onVirtualMachineCommonPage() {
        return this.virtualMachineCommonPage
    }

    onVirtualMachineCorpnetPage() {
        return this.virtualMachineCorpnetPage
    }

    onRequestConfirmationPage() {
        return this.requestConfirmationPage
    }

    onMyResourcesDetailPage() {
        return this.resourcesDetailPage
    }

    onMyResourcesPage() {
        return this.resourcesPage
    }
}