import { Locator, LocatorScreenshotOptions, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeType, FirewallOrganizations } from "utilities/enums/"
import { GenericHelper } from "utilities/uihelpers/genericHelper";


export class RequestConfirmationPage extends HelperBase {


    readonly requestId: Locator
    readonly successMessage: Locator

    constructor(page: Page) {
        super(page)
        this.requestId = this.page.locator("//h4[contains(text(),'Req ID')]")
        this.successMessage = this.page.locator('(//h1[contains(@class,"MuiTypography-root")])[last()]')
    }


    async getSuccessMessage(): Promise<string> {
        await this.waitForNumberOfSeconds(3)
        const message = await this.successMessage.textContent();
        if (typeof message !== 'string') {
            throw new Error('Incorrect Success message');
        }
        return message;
    }


    async retrieveRequestId(): Promise<string> {
        await this.waitForNumberOfSeconds(3)
        const id = await this.requestId.textContent();
        if (typeof id !== 'string') {
            throw new Error('Request Id not seen');
        } else {
            return id.substring(id.indexOf(':') + 2).trim();
        }
    }
}