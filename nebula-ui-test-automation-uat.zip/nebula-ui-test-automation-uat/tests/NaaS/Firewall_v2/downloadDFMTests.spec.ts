import { test, expect } from '../../../fixture/pomFixture'
import { ComputeType, MenuItems, IaasTabs, UserTypes, RequestStatus, FirewallOrganizations, FirewallV2ActivityLogs } from 'utilities/enums'
import * as allure from 'allure-js-commons';
import { chromium } from 'playwright';
import { SecurityCatalog } from 'utilities/enums/naas_enums/securityCatalogEnum';
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper';
import { readJsonFile } from "utilities/uihelpers/jsonHelper";

const testURL: string = process.env.TEST_URL!;


test.beforeEach(async ({ page }) => {
    await page.goto(testURL);
});

test.describe("Download Firewall V2 DFM", () => {
    test("Verify user can download DFM from My Request page - APSRE-TC-10151", { tag: ['@Regression', '@P2', '@NaaS', '@DFM'] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {

        const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
        await allure.description("Verify user can download DFM from My Request page");
        await allure.epic("NaaS");
        await allure.feature("Firewall V2");
        await allure.story("Download Firewall V2 DFM");
        await allure.tags("NaaS", "firewall_v2");
        await allure.issue("https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/N0av7ULbXNSD/1?projectId=105706", testCaseId);
        await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
        await test.step('Navigate To IaaS > Security > Firewall v2', async () => {
            await pageManager.navigateTo().navigateToMenuList(MenuItems.IaaS)
            await pageManager.onIaasHomePage().selectCompute(IaasTabs.Security)
            await pageManager.onSecurityHomePage().selectSecurityCatalog(SecurityCatalog.Add_Firewall_Rules_V2)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToFirewallV2');
        })

        await test.step('Fill Intake form', async () => {
            await pageManager.onAddFirewallV2RulesPage().fillV2IntakeForm()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step2_Fill_Intake_Form');
        })

        await test.step('Bulk Upload Firewall Rules', async () => {
            await pageManager.onAddFirewallV2RulesPage().selectAddFirewallRules()
            await pageManager.onAddFirewallV2RulesPage().addRulesViaBulkImport('corporate_Redaps.xlsx')
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step3_Bulk_Upload_Rules');
        })

        await test.step('Submit and verify v2 Rules', async () => {
            const rulesValidationMessage = await pageManager.onAddFirewallV2RulesPage().getAllRulesSuccessMessage()
            expect(rulesValidationMessage).toBe("Success:All rules have been validated")
            await pageManager.onAddFirewallV2RulesPage().submitFirewallRequest()
            const successMessage = await pageManager.onRequestConfirmationPage().getSuccessMessage()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step4_submit_rules');
            expect(successMessage).toBe('Request Submitted Successfully')

        })
        const requestId = await pageManager.onRequestConfirmationPage().retrieveRequestId()
        saveVariableIntoJsonFile('TestResponse\\requestIds.json', testCaseId, requestId)

        await test.step("Navigate To My Request Page (Track Request)", async () => {
            await pageManager.onMyRequestsHomePage().trackMyRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step5_trackRequest')
        })
        await test.step("Verify Initial Request Status", async () => {
            const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
            expect(status).toBe(RequestStatus.CREATED)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step6_Initial_Request_Status')
        })


        await test.step("Wait for status to be Processing", async () => {
            await pageManager.onMyRequestViewDetailsPage().waitForRequiredRequestStatus(RequestStatus.PENDING_APPROVAL)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step7_Processing_Status')
        })

        await test.step("Download & Verify DFM", async () => {
            await pageManager.onMyRequestViewDetailsPage().openConsolidatedRulesSection()
            await pageManager.onMyRequestViewDetailsPage().downloadDfmFromMyRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step7_DownloadDFM')
        })
    })

    test("Verify user can download DFM from My Approval page - APSRE-TC-10152", { tag: ['@Regression', '@P2', '@NaaS'] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {

        const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
        await allure.description("Verify user can download DFM from My Approval page");
        await allure.epic("NaaS");
        await allure.feature("Firewall V2");
        await allure.story("Download Firewall V2 DFM");
        await allure.tags("NaaS", "firewall_v2");
        await allure.issue("https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/oxZkdCeVQnCm/1?projectId=105706", testCaseId);
        await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
        await test.step('Navigate To My Approval', async () => {
            await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Approvals)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToMyApproval');
        })
        let requestId = readJsonFile('./TestResponse/requestIds.json');
        await test.step("Select Request for Approval", async () => {
            await pageManager.onApprovalsPage().openRequestForApproval(requestId["APSRE-TC-10151"])
            await screenshotHelper.captureScreenshot(page, testCaseId + "_Step2_openRequestForApproval")
        })

        await test.step("Download & Verify DFM", async () => {
            await pageManager.onMyRequestViewDetailsPage().openConsolidatedRulesSection()
            await pageManager.onMyRequestViewDetailsPage().downloadDfmFromMyRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step3_DownloadDFM')
        })
    })
})