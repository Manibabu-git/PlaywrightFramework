import { test, expect } from '../../../fixture/pomFixture'
import { ComputeType, MenuItems, IaasTabs, UserTypes, RequestStatus, FirewallOrganizations, FirewallV2ActivityLogs } from 'utilities/enums'
import * as allure from 'allure-js-commons';
import { chromium } from 'playwright';
import { SecurityCatalog } from 'utilities/enums/naas_enums/securityCatalogEnum';
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper';
import exp from 'constants';

const testURL: string = process.env.TEST_URL!;

test.beforeEach(async ({ page }) => {
  await page.goto(testURL);
});



test.describe.serial("Verify creation of v2 request against all the orgs together.", () => {
  test("Verify creation of v2 request against all the orgs together. - APSRE-TC-10108", { tag: ['@Regression', '@NaaS', '@P1'] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {

    const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
    await allure.description("This test verify creation of Firewall v2 request with both ipv6 and ipv4 rule sets are uploaded together");
    await allure.epic("NaaS");
    await allure.feature("Firewall V2");
    await allure.story("Create Firewall V2 Request");
    await allure.tags("NaaS", "firewall_v2");
    await allure.issue("https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/oxZkdCeVnncm/1?projectId=105706", testCaseId);
    await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
    await test.step('Navigate To IaaS > Security > Firewall v2', async () => {
      await pageManager.navigateTo().navigateToMenuList(MenuItems.IaaS)
      await pageManager.onIaasHomePage().selectCompute(IaasTabs.Security)
      await pageManager.onSecurityHomePage().selectSecurityCatalog(SecurityCatalog.Add_Firewall_Rules_V2)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToFirewallV2');
    })

    await test.step('Fill Intake form', async () => {
      //  await pageManager.onAddFirewallV2RulesPage().openBuildRequestIntakeForm()
      await pageManager.onAddFirewallV2RulesPage().fillV2IntakeForm()
      // await pageManager.onAddFirewallV2RulesPage().enterTopTicket()
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step2_Fill_Intake_Form');
    })

    await test.step('Bulk Upload Firewall Rules', async () => {
      await pageManager.onAddFirewallV2RulesPage().selectAddFirewallRules()
      await pageManager.onAddFirewallV2RulesPage().addRulesViaBulkImport('all_org.xlsx')
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step3_Bulk_Upload_Rules');
    })

    await test.step('Submit and verify v2 Rules', async () => {
      const rulesValidationMessage = await pageManager.onAddFirewallV2RulesPage().getAllRulesSuccessMessage()
      expect(rulesValidationMessage).toBe("Success:All rules have been validated")
      await pageManager.onAddFirewallV2RulesPage().submitFirewallRequest()
      const successMessage = await pageManager.onRequestConfirmationPage().getSuccessMessage()
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step4_submit_rules');
      expect(successMessage).toBe('Request Submitted Successfully')

    })
    const requestId = await pageManager.onRequestConfirmationPage().retrieveRequestId()
    saveVariableIntoJsonFile('TestResponse\\requestIds.json', testCaseId, requestId)

    await test.step("Navigate To My Request Page (Track Request)", async () => {
      await pageManager.onMyRequestsHomePage().trackMyRequest()
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step5_trackRequest')
    })
    await test.step("Verify Initial Request Status", async () => {
      const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
      expect(status).toBe(RequestStatus.CREATED)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step6_Initial_Request_Status')
    })

    await test.step("Wait for status to be Processing", async () => {
      await pageManager.onMyRequestViewDetailsPage().waitForRequiredRequestStatus(RequestStatus.PENDING_APPROVAL)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step7_Processing_Status')
    })

    await test.step("Verify Impacted Organization", async () => {
      await pageManager.onMyRequestViewDetailsPage().verifyImpactedOrganization(["na", "red_aps", "red_cbo", "corporate", "na_failed"])
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step8_ImpactedOrganization')
    })

    await test.step("Verify Sub Request Approval Status", async () => {
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestApprovalStatus(FirewallOrganizations.Unkwown_v6, RequestStatus.AUTO_APPROVED)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestApprovalStatus(FirewallOrganizations.Unkwown_v4, RequestStatus.PENDING)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestApprovalStatus(FirewallOrganizations.Neo, RequestStatus.AUTO_APPROVED)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestApprovalStatus(FirewallOrganizations.CorpNet_Blue, RequestStatus.PENDING)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestApprovalStatus(FirewallOrganizations.CustomerNet_Red, RequestStatus.PENDING)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step9_sub-req_approval_Status')
    })

    await test.step("Verify Sub Request Status", async () => {
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestStatus(FirewallOrganizations.Unkwown_v6, RequestStatus.PROCESSING)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestStatus(FirewallOrganizations.Unkwown_v4, RequestStatus.PENDING_APPROVAL)
      //  await pageManager.onMyRequestViewDetailsPage().verifySubRequestStatus(FirewallOrganizations.Neo, RequestStatus.PROCESSING)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestStatus(FirewallOrganizations.CustomerNet_Red, RequestStatus.PENDING_APPROVAL)
      await pageManager.onMyRequestViewDetailsPage().verifySubRequestStatus(FirewallOrganizations.CorpNet_Blue, RequestStatus.PENDING_APPROVAL)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step10_sub-req_Status')
    })

    await test.step("Verify Ticket Status", async () => {
      await pageManager.onMyRequestViewDetailsPage().verifyOrganizationTicketDetails(FirewallOrganizations.CustomerNet_Red)
      // await pageManager.onMyRequestViewDetailsPage().verifyOrganizationTicketDetails(FirewallOrganizations.Neo)
      await pageManager.onMyRequestViewDetailsPage().verifyOrganizationTicketDetails(FirewallOrganizations.CorpNet_Blue)
      await pageManager.onMyRequestViewDetailsPage().verifyOrganizationTicketDetails(FirewallOrganizations.Unkwown_v4)
      await pageManager.onMyRequestViewDetailsPage().verifyOrganizationTicketDetails(FirewallOrganizations.Unkwown_v6)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step11_Ticket_Status')
    })

    await test.step("Verify Common Firewall Ticket", async () => {
      let redId = await pageManager.onMyRequestViewDetailsPage().retrieveTicketId(FirewallOrganizations.CustomerNet_Red)
      let unknownId = await pageManager.onMyRequestViewDetailsPage().retrieveTicketId(FirewallOrganizations.Unkwown_v4)
      expect(redId).toBe(unknownId)
    })

    await test.step("Verify Activity Logs", async () => {
      await pageManager.onMyRequestViewDetailsPage().validateActivityLogStepStatus([FirewallV2ActivityLogs.Receive_Firewall_v2_Request_Nebula,
      FirewallV2ActivityLogs.Create_Jira_Ticket_IPV6_Jira, FirewallV2ActivityLogs.Create_Cherwell_Ticket_IPV6_Cherwell,
      FirewallV2ActivityLogs.Create_Subrequest_IPV6_Nebula, FirewallV2ActivityLogs.Poll_Process_For_IPV6_Jira_Ticket_Nebula
      ], "completed")
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step12_Activity_Logs')
    })

    await test.step('Navigate To My Approval', async () => {
      await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Approvals)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step13_NavigateToMyApproval');
    })

    await test.step("Select Request for Approval", async () => {
      await pageManager.onApprovalsPage().openRequestForApproval(requestId)
      await screenshotHelper.captureScreenshot(page, testCaseId + "_Step14_openRequestForApproval")
    })

    await test.step("Approve sub-request", async () => {
      await pageManager.onApprovalsPage().approveSubRequest(FirewallOrganizations.CorpNet_Blue)
      await screenshotHelper.captureScreenshot(page, testCaseId + "_Step15_ApproveSubRequest")
    })

    await test.step('Navigate To My Request', async () => {
      await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Requests)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step16_NavigateToMyRequest');
    })

    await test.step('Open My Request', async () => {
      await pageManager.onMyRequestsHomePage().openRequestToViewDetails(requestId)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step17_ViewRequest');
    })

    await test.step("Verify Request Status Post Approval", async () => {
      const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
      expect(status).toBe(RequestStatus.PENDING_APPROVAL)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step18_Processing_Request_Status')
    })

    await test.step("Verify Red Aps Request Status Post Approval", async () => {
      await pageManager.onMyRequestViewDetailsPage().verifyTicketsPostApproval(FirewallOrganizations.CustomerNet_Red, RequestStatus.COMPLETED)
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step19_Completed_Request_Status')
    })
    await test.step("Verify Activity Logs", async () => {
      await pageManager.onMyRequestViewDetailsPage().validateActivityLogStepStatus([FirewallV2ActivityLogs.Receive_Firewall_v2_Request_Nebula,
      FirewallV2ActivityLogs.Create_CRQ_Ticket_IPV4_Remedy, FirewallV2ActivityLogs.Create_Secure_Change_Ticket_IPV4_Tufin,
      FirewallV2ActivityLogs.Create_Subrequest_IPV4_Nebula, FirewallV2ActivityLogs.Create_Jira_Ticket_IPV4_Jira,
      FirewallV2ActivityLogs.Apply_Process_Change_IPV4_Tufin, FirewallV2ActivityLogs.Close_CRQ_Ticket_IPV4_Remedy,
      FirewallV2ActivityLogs.Close_Jira_Ticket_IPV4_Jira
      ], "completed")
      await screenshotHelper.captureScreenshot(page, testCaseId + '_Step19_Activity_Logs')
    })
  })
})

