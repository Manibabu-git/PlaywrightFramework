import { test, expect } from '../../../fixture/pomFixture'
import { ComputeType, MenuItems, IaasTabs, UserTypes, RequestStatus, FirewallOrganizations, FirewallV2ActivityLogs, FirewallTickets, FirewallTicketStatus } from 'utilities/enums'
import * as allure from 'allure-js-commons';
import { SecurityCatalog } from 'utilities/enums/naas_enums/securityCatalogEnum';
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper';

const testURL: string = process.env.TEST_URL!;

test.beforeEach(async ({ page }) => {
    await page.goto(testURL);
});


test.describe("Re-Submission of Firewall V2 Request", () => {
    test("Verify user can re-submit newly created V2 request from View Details page including ipv4/v6 - APSRE-TC-10148", { tag: ['@Regression', '@NaaS', '@P1'] }, async ({ page, pageManager, genericHelper, screenshotHelper, appVersion }) => {

        const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
        await allure.description("Verify user can re-submit newly created V2 request from View Details page including ipv4/v6");
        await allure.epic("NaaS");
        await allure.feature("Firewall V2");
        await allure.story("Re-Submit Firewall V2 Request");
        await allure.tags("NaaS", "firewall_v2");
        await allure.issue("https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/dVGZPIzlWmTN/1?projectId=105706", testCaseId);
        await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
        await test.step('Navigate To IaaS > Security > Firewall v2', async () => {
            await pageManager.navigateTo().navigateToMenuList(MenuItems.IaaS)
            await pageManager.onIaasHomePage().selectCompute(IaasTabs.Security)
            await pageManager.onSecurityHomePage().selectSecurityCatalog(SecurityCatalog.Add_Firewall_Rules_V2)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToFirewallV2');
        })

        await test.step('Fill Intake form', async () => {
            await pageManager.onAddFirewallV2RulesPage().fillV2IntakeForm()
            await pageManager.onAddFirewallV2RulesPage().enterTopTicket()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step2_Fill_Intake_Form');
        })

        await test.step('Bulk Upload Firewall Rules', async () => {
            await pageManager.onAddFirewallV2RulesPage().selectAddFirewallRules()
            await pageManager.onAddFirewallV2RulesPage().addRulesViaBulkImport('RedCbo_Aps_Corporate_ipv6.xlsx')
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step3_Bulk_Upload_Rules');
        })

        await test.step('Submit and verify v2 Rules', async () => {
            const rulesValidationMessage = await pageManager.onAddFirewallV2RulesPage().getAllRulesSuccessMessage()
            expect(rulesValidationMessage).toBe("Success:All rules have been validated")
            await pageManager.onAddFirewallV2RulesPage().submitFirewallRequest()
            const successMessage = await pageManager.onRequestConfirmationPage().getSuccessMessage()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step4_submit_rules');
            expect(successMessage).toBe('Request Submitted Successfully')

        })
        const requestId = await pageManager.onRequestConfirmationPage().retrieveRequestId()
        saveVariableIntoJsonFile('TestResponse\\requestIds.json', testCaseId, requestId)

        await test.step("Navigate To My Request Page (Track Request)", async () => {
            await pageManager.onMyRequestsHomePage().trackMyRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step5_trackRequest')
        })
        await test.step("Verify Initial Request Status", async () => {
            const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
            expect(status).toBe(RequestStatus.CREATED)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step6_Initial_Request_Status')
        })

        await test.step("Wait for status to be in Pending Approval", async () => {
            await pageManager.onMyRequestViewDetailsPage().waitForRequiredRequestStatus(RequestStatus.PENDING_APPROVAL)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step7_PendingApproval_Status')
        })

        await test.step("Re-Submit Firewall Request", async () => {
            await pageManager.onMyRequestViewDetailsPage().openConsolidatedRulesSection()
            await pageManager.onMyRequestViewDetailsPage().resubmitFirewallRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step8_ReSubmit')
        })

        await test.step("Verify Request Status Post Cancellation", async () => {
            await page.waitForTimeout(20000)
            const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step9_Cancelled_Request_Status')
            expect(status === RequestStatus.CANCELLED || status === RequestStatus.CANCELLING).toBe(true);
        })

        await test.step("Verify Sub Request Status Post Cancellation", async () => {
            await pageManager.onMyRequestViewDetailsPage().verifySubRequestTicketStatus(FirewallOrganizations.Unkwown_v6, FirewallTicketStatus.Cancelled)
            await pageManager.onMyRequestViewDetailsPage().verifySubRequestTicketStatus(FirewallOrganizations.Unkwown_v4, FirewallTicketStatus.Cancelled)
            await pageManager.onMyRequestViewDetailsPage().verifySubRequestTicketStatus(FirewallOrganizations.CustomerNet_Red, FirewallTicketStatus.Ticket_Cancelled)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step10_Cancelled_SubRequest_Status')
        })

        await test.step("Verify New Request Creation", async () => {
            await pageManager.onMyRequestViewDetailsPage().openSubRequestSection()
            const id = await pageManager.onMyRequestViewDetailsPage().retrieveNewFirewallRequestId()
            expect(id).toContain("NEB-IAAS-FW-V2-")
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step11_VerifyNewRequestCreation')
        })

        // await test.step("Verify Activity Logs", async () => {
        //     await pageManager.onMyRequestViewDetailsPage().validateActivityLogStepStatus([FirewallV2ActivityLogs.Receive_Firewall_v2_Request_Nebula,
        //     FirewallV2ActivityLogs.Create_Jira_Ticket_IPV6_Jira, FirewallV2ActivityLogs.Create_Cherwell_Ticket_IPV6_Cherwell,
        //     FirewallV2ActivityLogs.Create_Subrequest_IPV6_Nebula, FirewallV2ActivityLogs.Poll_Process_For_IPV6_Jira_Ticket_Nebula,
        //     FirewallV2ActivityLogs.Path_Impact_Identification_IPV4_Tufin, FirewallV2ActivityLogs.Owner_Identification_IPV4_Tufin,
        //     FirewallV2ActivityLogs.Create_Secure_Change_Ticket_IPV4_Tufin, FirewallV2ActivityLogs.Create_Subrequest_IPV4_Nebula,
        //     FirewallV2ActivityLogs.Risk_Analysis_Update_IPV4_Tufin, FirewallV2ActivityLogs.Designer_Result_Update_IPV4_Tufin,
        //     FirewallV2ActivityLogs.Cancel_Tufin_Ticket_IPV4_Tufin
        //     ], "completed")
        //     await screenshotHelper.captureScreenshot(page, testCaseId + '_Step11_Activity_Logs')
        // })
    })

    test("Verify user can re-submit newly created V2 request from My Approval page including ipv4/v6 - APSRE-TC-10149", { tag: ['@Regression', '@P1', '@NaaS'] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {

        const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
        await allure.description("Verify user can re-submit newly created V2 request from My Approval page including ipv4/v6");
        await allure.epic("NaaS");
        await allure.feature("Firewall V2");
        await allure.story("Re-Submit Firewall V2 Request");
        await allure.tags("NaaS", "firewall_v2");
        await allure.issue("https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/2JGPRcnWdyHK/1?projectId=105706", testCaseId);
        await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
        await test.step('Navigate To IaaS > Security > Firewall v2', async () => {
            await pageManager.navigateTo().navigateToMenuList(MenuItems.IaaS)
            await pageManager.onIaasHomePage().selectCompute(IaasTabs.Security)
            await pageManager.onSecurityHomePage().selectSecurityCatalog(SecurityCatalog.Add_Firewall_Rules_V2)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToFirewallV2');
        })

        await test.step('Fill Intake form', async () => {
            await pageManager.onAddFirewallV2RulesPage().fillV2IntakeForm()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step2_Fill_Intake_Form');
        })

        await test.step('Bulk Upload Firewall Rules', async () => {
            await pageManager.onAddFirewallV2RulesPage().selectAddFirewallRules()
            await pageManager.onAddFirewallV2RulesPage().addRulesViaBulkImport('RedCbo_Aps_Corporate_ipv6.xlsx')
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step3_Bulk_Upload_Rules');
        })

        await test.step('Submit and verify v2 Rules', async () => {
            const rulesValidationMessage = await pageManager.onAddFirewallV2RulesPage().getAllRulesSuccessMessage()
            expect(rulesValidationMessage).toBe("Success:All rules have been validated")
            await pageManager.onAddFirewallV2RulesPage().submitFirewallRequest()
            const successMessage = await pageManager.onRequestConfirmationPage().getSuccessMessage()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step4_submit_rules');
            expect(successMessage).toBe('Request Submitted Successfully')

        })
        const requestId = await pageManager.onRequestConfirmationPage().retrieveRequestId()
        saveVariableIntoJsonFile('TestResponse\\requestIds.json', testCaseId, requestId)

        await test.step("Navigate To My Request Page (Track Request)", async () => {
            await pageManager.onMyRequestsHomePage().trackMyRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step5_trackRequest')
        })
        await test.step("Verify Initial Request Status", async () => {
            const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
            expect(status).toBe(RequestStatus.CREATED)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step6_Initial_Request_Status')
        })

        await test.step("Wait for status to be in Pending Approval", async () => {
            await pageManager.onMyRequestViewDetailsPage().waitForRequiredRequestStatus(RequestStatus.PENDING_APPROVAL)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step7_PendingApproval_Status')
        })

        await test.step('Navigate To My Approval', async () => {
            await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Approvals)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step8_NavigateToMyApproval');
        })

        await test.step("Select Request for Approval", async () => {
            await pageManager.onApprovalsPage().openRequestForApproval(requestId)
            await screenshotHelper.captureScreenshot(page, testCaseId + "_Step9_openRequestForApproval")
        })

        await test.step("Re-Submit Firewall Request", async () => {
            await pageManager.onMyRequestViewDetailsPage().openConsolidatedRulesSection()
            await pageManager.onMyRequestViewDetailsPage().resubmitFirewallRequest()
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step10_ReSubmit')
        })

        await test.step("Verify Request Status Post Cancellation", async () => {
            await page.waitForTimeout(20000)
            const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
            expect(status === RequestStatus.CANCELLED || status === RequestStatus.CANCELLING).toBe(true);
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step11_Cancelled_Request_Status')
        })

        await test.step("Verify Sub Request Status Post Cancellation", async () => {
            await pageManager.onMyRequestViewDetailsPage().verifySubRequestTicketStatus(FirewallOrganizations.Unkwown_v6, FirewallTicketStatus.Cancelled)
            await pageManager.onMyRequestViewDetailsPage().verifySubRequestTicketStatus(FirewallOrganizations.Unkwown_v4, FirewallTicketStatus.Cancelled)
            await pageManager.onMyRequestViewDetailsPage().verifySubRequestTicketStatus(FirewallOrganizations.CustomerNet_Red, FirewallTicketStatus.Ticket_Cancelled)
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step12_Cancelled_SubRequest_Status')
        })

        await test.step("Verify New Request Creation", async () => {
            await pageManager.onMyRequestViewDetailsPage().openSubRequestSection()
            const id = await pageManager.onMyRequestViewDetailsPage().retrieveNewFirewallRequestId()
            expect(id).toContain("NEB-IAAS-FW-V2-")
            await screenshotHelper.captureScreenshot(page, testCaseId + '_Step13_VerifyNewRequestCreation')
        })

        // await test.step("Verify Activity Logs", async () => {
        //     await pageManager.onMyRequestViewDetailsPage().validateActivityLogStepStatus([FirewallV2ActivityLogs.Receive_Firewall_v2_Request_Nebula,
        //     FirewallV2ActivityLogs.Create_Jira_Ticket_IPV6_Jira, FirewallV2ActivityLogs.Create_Cherwell_Ticket_IPV6_Cherwell,
        //     FirewallV2ActivityLogs.Create_Subrequest_IPV6_Nebula, FirewallV2ActivityLogs.Poll_Process_For_IPV6_Jira_Ticket_Nebula,
        //     FirewallV2ActivityLogs.Path_Impact_Identification_IPV4_Tufin, FirewallV2ActivityLogs.Owner_Identification_IPV4_Tufin,
        //     FirewallV2ActivityLogs.Create_Secure_Change_Ticket_IPV4_Tufin, FirewallV2ActivityLogs.Create_Subrequest_IPV4_Nebula,
        //     FirewallV2ActivityLogs.Risk_Analysis_Update_IPV4_Tufin, FirewallV2ActivityLogs.Designer_Result_Update_IPV4_Tufin,
        //     FirewallV2ActivityLogs.Cancel_Tufin_Ticket_IPV4_Tufin
        //     ], "completed")
        //     await screenshotHelper.captureScreenshot(page, testCaseId + '_Step11_Activity_Logs')
        // })
    })
})