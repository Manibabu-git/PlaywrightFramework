import fs from 'fs';
import { test, expect } from '../fixture/pomFixture'
import { parseStringPromise, Builder } from 'xml2js';
import { uploadResultToQmetry } from '../utilities/apihelpers/apiRequestCreationHelper';

const qmetryNameMapping: Record<string, string> = {
  'APSRE-TC-10151': 'Verify user can download DFM from My Request page',
  'APSRE-TC-10152': 'Verify user can download DFM from My Approval page',
  'APSRE-TC-10153': 'Verify user can re-submit newly created V2 request from View Details page including ipv4/v6',
  'APSRE-TC-10154': 'Verify user can re-submit newly created V2 request from My Approval page including ipv4/v6',
  'APSRE-TC-10111': 'Verify the e2e flow for firewall V2, when user selects Cancel All from My Request page',
  'APSRE-TC-10108': 'Verify creation of v2 request against all the orgs together.',
  'APSRE-TC-10414': 'Verify Windows os  2016 VM creation',
  'APSRE-TC-10397': 'Verify Linux VM creation for  RHEL 8.6',
  'APSRE-TC-10412': 'Verify Ubuntu 24.04 VM creation(Add disk)'
};


const getCustomTestCaseName = (classname: string, methodName: string): string | null => {
  const match = methodName.match(/APSRE-TC-\d+/);
  if (!match) return null;
  const testCaseId = match[0];
  return qmetryNameMapping[testCaseId] || testCaseId;
};


// //Extract QMetry test case name using file and method name
// const getCustomTestCaseName = (classname: string, methodName: string): string | null => {
//   const fileName = classname.split(/[/\\]/).pop() || classname;
//   const fileMapping = mapping[fileName];
//   if (!fileMapping) return null;

//   // Try exact match
//   if (fileMapping[methodName]) return fileMapping[methodName];

//   // Optional: fuzzy match
//   const matchedKey = Object.keys(fileMapping).find(key => methodName.includes(key));
//   return matchedKey ? fileMapping[matchedKey] : null;
// };

// Extract folder name like "NaaS" or "IaaS" from testsuite name
const extractFolderNameFromTestSuite = (testsuiteName: string): string => {
  if (!testsuiteName || typeof testsuiteName !== 'string') {
    console.warn('Invalid testsuite name:', testsuiteName);
    return 'Unknown';
  }

  const normalized = testsuiteName.replace(/\\/g, '/');
  const parts = normalized.split('/').filter(Boolean);

  if (parts.length === 0) {
    console.warn('Could not extract folder name from:', testsuiteName);
    return 'Unknown';
  }

  const folderName = parts[0];
  console.log(`Extracted folder name: ${folderName} from "${testsuiteName}"`);
  return folderName;
};



// Main function to modify XML and upload to QMetry
const modifyTestResultsAndImport = async (filePath: string) => {
  try {
    const xmlData = fs.readFileSync(filePath, 'utf8');
    const folderNames = new Set<string>();
    const parsedXml = await parseStringPromise(xmlData);

    if (!parsedXml.testsuites || !Array.isArray(parsedXml.testsuites.testsuite)) {
      console.error('Invalid XML structure: "testsuites.testsuite" is missing or not an array.');
      return;
    }

    parsedXml.testsuites.testsuite = parsedXml.testsuites.testsuite.map((testsuite: any) => {
      const folderName = extractFolderNameFromTestSuite(testsuite.$.name);
      if (folderName) folderNames.add(folderName);

      testsuite.testcase = testsuite.testcase.filter((testcase: any) => {
        const newTestCaseName = getCustomTestCaseName(testcase.$.classname, testcase.$.name);
        console.log("Test Case Name: ", newTestCaseName)
        if (newTestCaseName) {
          testcase.$.name = newTestCaseName;

          const stepDescriptions: string[] = [];
          if (testcase.teststep) {
            testcase.teststep.forEach((step: any) => {
              if (step.$.name) stepDescriptions.push(step.$.name);
            });
          }

          if (stepDescriptions.length > 0) {
            testcase.$.name = `${newTestCaseName} > ${stepDescriptions.join(' > ')}`;
          }

          return true;
        }
        return false;
      });

      return testsuite;
    }).filter((testsuite: any) => testsuite.testcase.length > 0);

    const builder = new Builder();
    const updatedXml = builder.buildObject(parsedXml);
    fs.writeFileSync(filePath, updatedXml, 'utf8');
    console.log('Test results updated successfully.');

    for (const folderName of folderNames) {
      console.log(`Uploading results to QMetry folder: UAT/Regression/${folderName}`);
      await uploadResultToQmetry(folderName);
    }
  } catch (error) {
    console.error('Error modifying the XML:', error);
  }
};


modifyTestResultsAndImport('results.xml');
