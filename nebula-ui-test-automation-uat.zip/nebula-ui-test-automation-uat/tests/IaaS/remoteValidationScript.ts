import { test, expect } from '../../fixture/pomFixture'
import { ComputeType, UserTypes } from 'utilities/enums'
import * as allure from "allure-js-commons"
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper'
import { runRemoteCommand } from 'utilities/remotehelpers/sshUtils';
import { readJsonFile } from "utilities/uihelpers/jsonHelper";



let vmData = readJsonFile('./TestData/remoteLoginDetails.json');

test.describe("VM Validation Tests", () => {
    test("Verify VM Creation - APSRE-TC-01", { tag: '@IaaS' }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {

        const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
        await allure.description("This test verify creation of Ubuntu VM");
        await allure.epic("IaaS");
        await allure.feature("VM Creation");
        await allure.story("Verify Ubuntu VM Creation");
        await allure.tags("IaaS", "Ubuntu");
        await allure.issue("bnfgv6", testCaseId);
        await allure.owner("Rishi Khanna");

        await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)

        await test.step('Verify VM creation and Tools Installation', async () => {

            const sshConfig = {
                host: vmData.hostIp,
                port: 22,
                username: vmData.username,
                password: vmData.password,
            };

            //Validation commands
            const lsblk = 'lsblk';
            const qualys = 'service qualys-cloud-agent status';
            const centrify = 'cinfo';
            const crowdstrike = 'rpm -qa | grep falcon';
            const tanium = 'ps aux | grep';
            const tools = 'systemctl status vmtoolsd';

            //Directory to save the response
            const outputPath = "TestResponse//VM_Validation_Responses//" + testCaseId + "_"

            //exec commands
            await runRemoteCommand(sshConfig, lsblk, outputPath + "lsblk.txt");
            await runRemoteCommand(sshConfig, qualys, outputPath + "qualys.txt");
            await runRemoteCommand(sshConfig, centrify, outputPath + "centrify.txt");
            await runRemoteCommand(sshConfig, crowdstrike, outputPath + "crowdstrike.txt");
            await runRemoteCommand(sshConfig, tanium, outputPath + "tanium.txt");
            await runRemoteCommand(sshConfig, tools, outputPath + "tools.txt");
            console.log(`Command output saved to ${outputPath}`);

        })
    })
})