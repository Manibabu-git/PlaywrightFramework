import { test, expect } from '../../../fixture/pomFixture'
import * as allure from "allure-js-commons"
import { readJsonFile } from "utilities/uihelpers/jsonHelper";
import { generateVmTestData } from 'testConfig/windowsTestConfig';
import { MenuItems, UserTypes } from 'utilities/enums';


const testURL: string = process.env.TEST_URL!;
const vmTestData = generateVmTestData();

test.beforeEach(async ({ page }) => {
    await page.goto(testURL);
});


test("Verify user should be able to delete the windows VM - APSRE-TC-10451", { tag: ['@Vm_Cleanup'] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {
    const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
    await allure.description(`Clean Windows VM`);
    await allure.epic("IaaS");
    await allure.feature("VM Deletion");
    await allure.story("Delete VM Instance");
    await allure.tags("IaaS", "Windows");
    await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/lxZkYC8jL7t7/1?projectId=105706`, testCaseId);
    await allure.owner("Rishi Khanna");

    await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
    await test.step('Navigate To My Resources', async () => {
        await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Resources)
        await screenshotHelper.captureScreenshot(page, testCaseId + '_Step01_NavigateToMyResources');
    })
    let requestId = readJsonFile('./TestResponse/requestIds.json');
    await test.step('Delete resource', async () => {
        await pageManager.onMyResourcesPage().filterResource(requestId[testCaseId])
        await pageManager.onMyResourcesPage().selectResourceCheckBox(requestId[testCaseId])
        await pageManager.onMyResourcesPage().deleteResource(requestId[testCaseId])
        await screenshotHelper.captureScreenshot(page, testCaseId + '_Step02_DeleteResource')
    })
})

test.describe("VM Validation Tests", () => {
    for (const data of vmTestData) {
        test("VM Cleanup" + ` - ${data.qmetryTestCaseId}`, { tag: ['@Vm_Cleanup'] }, async ({ page, pageManager, screenshotHelper }) => {
            const testCaseId = `${data.qmetryTestCaseId}`
            let vm = readJsonFile("TestResponse\\vmCreationRecord.json")
            if (!vm[testCaseId]) {
                await allure.description(`Validation Test Skipped because VM creation failed for ${data.testName}`);
                await allure.label("skipReason", "VM creation failed");
                test.skip()
                return;
            }
            await allure.description(`Clean Windows VM`);
            await allure.epic("IaaS");
            await allure.feature("VM Deletion");
            await allure.story("Delete VM Instance");
            await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
            await allure.owner("Rishi Khanna");

            await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
            await test.step('Navigate To My Resources', async () => {
                await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Resources)
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step01_NavigateToMyResources');
            })
            let requestId = readJsonFile('./TestResponse/requestIds.json');
            await test.step('Delete resource', async () => {
                await pageManager.onMyResourcesPage().filterResource(requestId[testCaseId])
                await pageManager.onMyResourcesPage().selectResourceCheckBox(requestId[testCaseId])
                await pageManager.onMyResourcesPage().deleteResource(requestId[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step02_DeleteResource')
            })
        })
    }
})
