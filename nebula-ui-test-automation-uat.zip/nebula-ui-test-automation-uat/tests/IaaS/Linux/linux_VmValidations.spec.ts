import { test, expect } from '../../../fixture/pomFixture'
import {
    ComputeType, MenuItems, IaasTabs, UserTypes, ComputeCatalog,
    DiskFileSystem, Cluster, IpRuleType, VmCreationActivityLogs
} from 'utilities/enums'
import * as allure from "allure-js-commons"
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper'
import { readJsonFile } from "utilities/uihelpers/jsonHelper";
import { generateVmTestData } from 'testConfig/linuxTestConfig';
import { parseLogToJson } from 'utilities/remotehelpers/parseLogIntoJson'
import * as fs from 'fs';
import { compareJsonAndWriteReport } from 'utilities/remotehelpers/jsonValidator'
import { GenericHelper } from 'utilities/uihelpers/genericHelper';
import { attachAllReportsToAllure } from 'utilities/uihelpers/allureHelper'


let intakeFormData = readJsonFile('./TestData/vmIntakeFormData.json');
let toolsRecord: Record<string, boolean>
const testURL: string = process.env.TEST_URL!;
const vmTestData = generateVmTestData();
let vmCreationRecord: boolean

test.beforeEach(async ({ page }) => {
    await page.goto(testURL)
});


/*
     * Follwoing tests are validation tests which will be executed separately once VM creation tests are executed
    */
test.describe("VM Validation Tests", () => {
    for (const data of vmTestData) {

        test(`Validate ${data.testName} - ${data.qmetryTestCaseId} on My Request Page`, { tag: [`@${data.qmetryTestCaseId}_validation`] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {
            let vm = readJsonFile("TestResponse\\vmCreationRecord.json")
            let ipAddress;
            const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
            let expectedTools = readJsonFile("TestResponse\\installedToolsRecord.json")
            let requestId = readJsonFile('./TestResponse/requestIds.json');
            if (!vm[testCaseId]) {
                await allure.description(`Validation Test Skipped because VM creation failed for ${data.testName}`);
                await allure.label("skipReason", "VM creation failed");
                test.skip()
                return;
            }

            await allure.description(`Validate created ${data.osVersion} VM`);
            await allure.epic("IaaS");
            await allure.feature("VM Creation");
            await allure.story(`${data.testName} - ${data.qmetryTestCaseId}` + " on My Resources Page");
            await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
            await allure.owner("Rishi Khanna");
            await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
            let domainName: string
            let ipModes, ipv4, ipv6, description, sshKey
            let projectName, appName, env, dc, diskCount, diskSize
            let vmSize, hostname, osVersion, rubrik, diskName, diskFs, toolsRecord, vmSizing

            await test.step('Navigate To My Request Page', async () => {
                await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Requests)
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToMyRequest');
            })
            await test.step('Open My Request', async () => {
                await pageManager.onMyRequestsHomePage().openRequestToViewDetails(requestId[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step02_ViewRequest');
            })
            await test.step('Verify Request Status', async () => {
                const status = await pageManager.onMyRequestViewDetailsPage().retrieveRequestStatus()
                expect(["COMPLETED", "COMPLETED WITH ERROR"]).toContain(status);
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step02_ViewRequest');
            })

            await test.step("Fetch all VM specific details", async () => {
                await pageManager.onMyRequestViewDetailsPage().openLinuxSection()
                domainName = await pageManager.onMyRequestViewDetailsPage().retrieveDomain() ?? ''
                projectName = await pageManager.onMyRequestViewDetailsPage().retrieveProject()
                appName = await pageManager.onMyRequestViewDetailsPage().retrieveApplication()
                env = await pageManager.onMyRequestViewDetailsPage().retrieveEnvironment()
                dc = await pageManager.onMyRequestViewDetailsPage().retrieveDatacenter()
                vmSize = await pageManager.onMyRequestViewDetailsPage().retrieveVmSize()
                vmSizing = await pageManager.onVirtualMachineCommonPage().retrieveVmSizing()
                hostname = await pageManager.onMyRequestViewDetailsPage().retrieveHostname()
                osVersion = await pageManager.onMyRequestViewDetailsPage().retrieveOsVersion()
                rubrik = await pageManager.onMyRequestViewDetailsPage().retrieveRubrikDetails()
                description = await pageManager.onMyRequestViewDetailsPage().retrieveDescription()
                sshKey = await pageManager.onMyRequestViewDetailsPage().retrieveSshKey()
                diskCount = await pageManager.onMyRequestViewDetailsPage().retrieveAdditionalDiskCount()
                diskSize = await pageManager.onMyRequestViewDetailsPage().retrieveAdditionalDiskSize()
                diskName = await pageManager.onMyRequestViewDetailsPage().retrieveAdditionalDiskName()
                diskFs = await pageManager.onMyRequestViewDetailsPage().retrieveAdditionalDiskFileSystem()
            })
            await test.step("Fetch all Network specific details", async () => {
                await pageManager.onMyRequestViewDetailsPage().openNetworkSection()
                ipModes = await pageManager.onMyRequestViewDetailsPage().retrieveIpModes()
                ipv4 = await pageManager.onMyRequestViewDetailsPage().retrieveIpv4()
                ipv6 = await pageManager.onMyRequestViewDetailsPage().retrieveIpv6()
            })

            await test.step("Verify Activity Logs", async () => {
                await pageManager.onMyRequestViewDetailsPage().validateActivityLogStatus(domainName, [VmCreationActivityLogs.Receive_VM_Request_Nebula,
                VmCreationActivityLogs.Approve_Request_Nebula, VmCreationActivityLogs.Quota_Validation_Nebula, VmCreationActivityLogs.Validate_VLan_Infoblox,
                VmCreationActivityLogs.Reserve_IP_Infoblox, VmCreationActivityLogs.Trace_and_Ping_Validation_Infoblox,
                VmCreationActivityLogs.Create_VM_VSphere, VmCreationActivityLogs.Check_VM_Status_VSphere,
                VmCreationActivityLogs.VM_Resource_Created_Nebula, VmCreationActivityLogs.Configure_VM_AWX, VmCreationActivityLogs.Check_VM_Configure_Status_AWX,
                VmCreationActivityLogs.Notify_Compliance_Platform_Legacy_Compliance
                ], "completed")
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step04_Activity_Logs')
            })
            await test.step('Verify Installed Tools', async () => {
                await pageManager.onMyRequestViewDetailsPage().openToolsSection()
                toolsRecord = await pageManager.onMyRequestViewDetailsPage().verifyInstalledTools(expectedTools[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step03_VerifyInstalledTools');
            })
            const actualValues = {
                Domain: domainName!,
                Project: projectName,
                Application: appName,
                Environment: env,
                Datacenter: dc,
                Description: description,
                OSVersion: osVersion,
                RubrikSLA: rubrik,
                Hostname: hostname,
                VMSize: vmSize,
                VMSizeDetails: vmSizing,
                IpModes: ipModes,
                IPv4: ipv4,
                IPv6: ipv6,
                AdditionalDisk: {
                    ShouldAdd: data.additionalDisk[0],
                    FileSystem: diskFs,

                },
                Tools: toolsRecord

            };
            saveVariableIntoJsonFile(`TestResponse\\MyRequestsPageFormData\\${data.qmetryTestCaseId}`, requestId[testCaseId], actualValues)

            const expectedJson = JSON.parse(fs.readFileSync(`TestResponse\\VmIntakeFormData\\${data.qmetryTestCaseId}`, 'utf8'))
            const actualJson = JSON.parse(fs.readFileSync(`TestResponse\\MyRequestsPageFormData\\${data.qmetryTestCaseId}`, 'utf8'))
            const expected = expectedJson[Object.keys(expectedJson)[0]];
            const actual = actualJson[Object.keys(actualJson)[0]];
            compareJsonAndWriteReport(expected, actual, `VM_Validation_Results\\${data.qmetryTestCaseId}\\intakeform-myrequest.txt`);
            await attachAllReportsToAllure(`VM_Validation_Results\\${data.qmetryTestCaseId}`);

        })
    }



    /*
         * Follwoing tests are validation tests which will be executed separately once VM creation tests are executed
        */

    for (const data of vmTestData) {

        test(`Validate ${data.testName} - ${data.qmetryTestCaseId} on My Resources Page`, { tag: [`@${data.qmetryTestCaseId}_validation`] }, async ({ pageManager, genericHelper, screenshotHelper, page }) => {
            let vm = readJsonFile("TestResponse\\vmCreationRecord.json")
            let ipAddress;
            const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
            let expectedTools = readJsonFile("TestResponse\\installedToolsRecord.json")
            let requestId = readJsonFile('./TestResponse/requestIds.json');
            if (!vm[testCaseId]) {
                await allure.description(`Validation Test Skipped because VM creation failed for ${data.testName}`);
                await allure.label("skipReason", "VM creation failed");
                test.skip()
                return;
            }

            await allure.description(`Validate created ${data.osVersion} VM`);
            await allure.epic("IaaS");
            await allure.feature("VM Creation");
            await allure.story(`${data.testName} - ${data.qmetryTestCaseId}` + " on My Resources Page");
            await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
            await allure.owner("Rishi Khanna");
            await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)

            await test.step('Navigate To My Resources', async () => {
                await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Resources)
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step05_NavigateToMyResources');
            })

            await test.step('Select resource', async () => {
                await pageManager.onMyResourcesPage().filterResource(requestId[testCaseId])
                await pageManager.onMyResourcesPage().selectResourceId(requestId[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step06_SelectResource')
            })
            ipAddress = await pageManager.onMyResourcesDetailPage().retrieveIpAddress(IpRuleType.ipv4)
            saveVariableIntoJsonFile('TestResponse\\ipAddress.json', testCaseId, ipAddress)
            await test.step('Validate Created Resources', async () => {
                // await screenshotHelper.captureScreenshot(page, testCaseId + '_Step07_ValidateResource')
                const projectName = await pageManager.onMyResourcesDetailPage().retrieveProject()
                const domainName = await pageManager.onMyResourcesDetailPage().retrieveDomain()
                const envName = await pageManager.onMyResourcesDetailPage().retrieveEnvironment()
                const appName = await pageManager.onMyResourcesDetailPage().retrieveApplication()
                const resourceName = await pageManager.onMyResourcesDetailPage().retrieveResourceName()
                const catalogItem = await pageManager.onMyResourcesDetailPage().retrieveCatalogItem()
                expect(projectName).toBe(data.project)

                const status = await pageManager.onMyResourcesDetailPage().retrieveResourceStatus()
                expect(status).toBe("RUNNING")
                await pageManager.onMyResourcesDetailPage().openNetworkDetails()
                const dataCenter = await pageManager.onMyResourcesDetailPage().retrieveDataCenter()
                const rubrikSla = await pageManager.onMyResourcesDetailPage().retrieveRubrikDetails()
                const layoutName = await pageManager.onMyResourcesDetailPage().retrieveLayoutName()
                const customCores = await pageManager.onMyResourcesDetailPage().retrieveCustomCore()
                const customMemory = await pageManager.onMyResourcesDetailPage().retrieveCustomMemory()
                const additionalDiskCount = await pageManager.onMyResourcesDetailPage().retrieveAdditionalDiskCount()
                const additionalDiskSize = await pageManager.onMyResourcesDetailPage().retrieveAdditionalDiskSize()
                const additionalDiskName = await pageManager.onMyResourcesDetailPage().retrieveAdditionalDiskName()
                const additionalDiskFileSystem = await pageManager.onMyResourcesDetailPage().retrieveAdditionalDiskFileSystem()
                await pageManager.onMyResourcesDetailPage().verifyNetworkDetails(domainName!, `${data.rubrikSla}`, `${data.osVersion}`)
                await pageManager.onMyResourcesDetailPage().openToolsDetails()
                const toolRecord = await pageManager.onMyResourcesDetailPage().retrieveToolsRecord(expectedTools[testCaseId])

                //    await pageManager.onMyResourcesDetailPage().verifyConfigurationDetails(`${data.vmSize}`, "4", "8", "1", "15")

                // const postPrvSteps = await pageManager.onMyResourcesDetailPage().retrievePostProvisionSteps()
                // const lines = postPrvSteps!.split(',').map(line => line.trim()).filter(Boolean);

                // for (const line of lines) {
                //     if (line.startsWith('DIRRT')) {
                //         expect(line).toContain('FAILED');
                //     } else {
                //         expect(line).toContain('SUCCESS');
                //     }
                // }
                const actualValues = {
                    Domain: domainName,
                    Project: projectName,
                    Application: appName,
                    Environment: envName,
                    Datacenter: dataCenter,
                    OSVersion: layoutName,
                    RubrikSLA: rubrikSla,
                    Hostname: resourceName,
                    VMSize: additionalDiskSize,
                    AdditionalDisk: {
                        ShouldAdd: data.additionalDisk[0],
                        FileSystem: additionalDiskFileSystem,
                        Catalog: catalogItem
                    },
                    Tools: toolRecord

                };
                saveVariableIntoJsonFile(`TestResponse\\MyResourcesPageFormData\\${data.qmetryTestCaseId}`, requestId[testCaseId], actualValues)
            })
            const expectedJson = JSON.parse(fs.readFileSync(`TestResponse\\VmIntakeFormData\\${data.qmetryTestCaseId}`, 'utf8'))
            const actualJson = JSON.parse(fs.readFileSync(`TestResponse\\MyResourcesPageFormData\\${data.qmetryTestCaseId}`, 'utf8'))
            const expected = expectedJson[Object.keys(expectedJson)[0]];
            const actual = actualJson[Object.keys(actualJson)[0]];
            compareJsonAndWriteReport(expected, actual, `VM_Validation_Results\\${data.qmetryTestCaseId}\\intakeform-myresources.txt`);
            await pageManager.onMyResourcesDetailPage().verifyToolsSection(expectedTools[testCaseId])
        })
    }




    for (const data of vmTestData) {
        test(`${data.testName} - ${data.qmetryTestCaseId}` + " on Remote Machine", { tag: [`@${data.qmetryTestCaseId}_validation`] }, async ({ page, pageManager }) => {
            let ip = readJsonFile('./TestResponse/ipAddress.json');
            let creds = readJsonFile('./TestData/vmCreds.json');
            let requestId = readJsonFile('./TestResponse/requestIds.json');
            const testCaseId = `${data.qmetryTestCaseId}`
            let vm = readJsonFile("TestResponse\\vmCreationRecord.json")
            if (!vm[testCaseId]) {
                await allure.description(`Validation Test Skipped because VM creation failed for ${data.testName}`);
                await allure.label("skipReason", "VM creation failed");
                test.skip()
                return;
            }


            await allure.description(`Validate created ${data.osVersion}  VM`);
            await allure.epic("IaaS");
            await allure.feature("VM Creation");
            await allure.story(`${data.testName} - ${data.qmetryTestCaseId}` + " on remote VM");
            await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
            await allure.owner("Rishi Khanna");
            await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
            await test.step('Verify on remote machine ', async () => {

                const path = require('path');
                const { exec } = require('child_process');
                const ipAddress = ip[testCaseId]
                const username = creds["username"]
                const password = creds["password"]
                const osType = 'linux';
                const outputFile = `TestResponse\\RemoteVmData\\${testCaseId}.log`;

                // Resolve the relative path to the Python script
                const scriptPath = path.resolve('./utilities/vmValidator/vm-validator.py');

                const command = `python "${scriptPath}" --host ${ipAddress} --user ${username} --password ${password} --os ${osType} --output ${outputFile}`;

                exec(command, (error: Error | null, stdout: string, stderr: string) => {
                    if (error) {
                        console.error(`Error: ${error.message}`);
                        return;
                    }
                    if (stderr) {
                        console.error(`Stderr: ${stderr}`);
                        return;
                    }
                    console.log(`Validation Output:\n${stdout}`);
                });
                await pageManager.onHelperBasePage().waitForNumberOfSeconds(5)

                const logContent = fs.readFileSync(`TestResponse\\VM_Validation_Responses\\${data.qmetryTestCaseId}.log`, "utf8");
                const actualValues = parseLogToJson(logContent);

                saveVariableIntoJsonFile(`TestResponse\\VM_Validation_Responses\\${data.qmetryTestCaseId}`, requestId[testCaseId], actualValues);
            })
            const expectedJson = JSON.parse(fs.readFileSync(`TestResponse\\VmIntakeFormData\\${data.qmetryTestCaseId}`, 'utf8'))
            const actualJson = JSON.parse(fs.readFileSync(`TestResponse\\VM_Validation_Responses\\${data.qmetryTestCaseId}`, 'utf8'))
            const expected = expectedJson[Object.keys(expectedJson)[0]];
            const actual = actualJson[Object.keys(actualJson)[0]];
            compareJsonAndWriteReport(expected, actual, `VM_Validation_Results\\${data.qmetryTestCaseId}\\intakeform-vmData.txt`);
        })

    }
})



// test.afterAll(async ({ context }) => {
//     await context.close();
// });

