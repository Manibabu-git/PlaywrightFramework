import argparse
from datetime import datetime
from typing import List

import paramiko
import winrm


def log(message: str, output_file: str) -> None:
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    full_message = f"[{timestamp}] {message}"
    with open(output_file, 'a', encoding='utf-8') as f:
        f.write(full_message + '\n')
    print(full_message)

def run_linux_command(client: paramiko.SSHClient, command: str) -> str:
    try:
        stdin, stdout, stderr = client.exec_command(command, timeout=10)
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        if error:
            return f"Error: {error}"
        return output if output else "Not Found"
    except Exception as e:
        return f"Error: {str(e)}"



def run_windows_command(ip: str, username: str, password: str, command: str) -> str:
    try:
        session = winrm.Session(ip, auth=(username, password))
        result = session.run_cmd(command)
        output = result.std_out.decode().strip()
        return output if output else "Not Found"
    except Exception as e:
        return f"Error: {str(e)}"
from typing import List
from datetime import datetime
import os

def log(message: str, output_file: str) -> None:
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    full_message = f"[{timestamp}] {message}"
    try:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(full_message + '\n')
    except Exception as e:
        print(f"[LOGGING ERROR] {e}")
    print(full_message)


def validate_linux(ip: str, username: str, password: str) -> List[str]:
    results = ["=== Linux VM Validation ==="]

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(ip, username=username, password=password, timeout=10)

        results.append(f"OS: {run_linux_command(client, 'cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d \"\\\"\"')}")
        results.append(f"CPU Cores: {run_linux_command(client, 'nproc')}")
        results.append(f"Total Memory: {run_linux_command(client, 'free -h | awk \"/Mem:/ {{print \\$2}}\"')}")
        results.append(f"IPv4 Address: {run_linux_command(client, 'hostname -I | awk \"{print \\$1}\"')}")
        results.append(f"IPv6 Address: {run_linux_command(client, 'ip -6 addr show | grep \"inet6\" | awk \"{print \\$2}\"')}")
       
        results.append(f"SSH Keys: {run_linux_command(client, 'ls ~/.ssh/id_* 2>/dev/null')}")
        results.append(f"Authorized Keys: {run_linux_command(client, 'cat ~/.ssh/authorized_keys 2>/dev/null')}")
        results.append(f"DNS Name: {run_linux_command(client, 'hostname -f')}")

        results.append("\n--- Tools Validation ---")

        results.append("Tool: CrowdStrike")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i falcon-sensor || dpkg -l | grep -i falcon-sensor')}")
        results.append(f" Service Status: {run_linux_command(client, 'systemctl status falcon-sensor | grep \"Active:\"')}")

        results.append("Tool: Centrify")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i centrify || dpkg -l | grep -i centrify')}")
        results.append(f" Service Status: {run_linux_command(client, 'adinfo')}")

        results.append("Tool: Qualys")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i qualys || dpkg -l | grep -i qualys')}")
        results.append(f" Service Status: {run_linux_command(client, 'systemctl status qualys-cloud-agent | grep \"Active:\"')}")

        results.append("Tool: Tanium")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i taniumclient || dpkg -l | grep -i taniumclient')}")
        results.append(f" Service Status: {run_linux_command(client, 'systemctl status taniumclient | grep \"Active:\"')}")

        results.append("Tool: ScienceLogic")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i sciencelogic || dpkg -l | grep -i sciencelogic')}")
        results.append(f" Service Status: {run_linux_command(client, 'systemctl list-units --type=service | grep -i sciencelogic')}")

        results.append("Tool: Splunk")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i splunk || dpkg -l | grep -i splunk')}")
        results.append(f" Service Status: {run_linux_command(client, 'systemctl status SplunkForwarder | grep \"Active:\"')}")

        results.append("Tool: VM Tools")
        results.append(f" Package Status: {run_linux_command(client, 'rpm -qa | grep -i open-vm-tools || dpkg -l | grep -i open-vm-tools')}")
        results.append(f" Service Status: {run_linux_command(client, 'systemctl status vmtoolsd | grep \"Active:\"')}")
        
        results.append(f"Additional Disks: {run_linux_command(client, 'lsblk -o NAME,SIZE,TYPE,MOUNTPOINT')}")
    except Exception as e:
        results.append(f"[ERROR] SSH connection failed: {str(e)}")
    finally:
        client.close()

    return results

def validate_windows(ip: str, username: str, password: str) -> List[str]:
    results = ["=== Windows VM Validation ==="]
    results.append(f"OS: {run_windows_command(ip, username, password, 'systeminfo | findstr /B /C:\"OS Name\"')}")
    results.append(f"CPU Cores: {run_windows_command(ip, username, password, 'wmic cpu get NumberOfCores')}")
    results.append(f"Total Memory: {run_windows_command(ip, username, password, 'systeminfo | findstr /C:\"Total Physical Memory\"')}")
    results.append(f"IPv4 Address: {run_windows_command(ip, username, password, 'ipconfig | findstr /R /C:\"IPv4 Address\"')}")
    results.append(f"IPv6 Address: {run_windows_command(ip, username, password, 'ipconfig | findstr /R /C:\"IPv6 Address\"')}")
    results.append(f"Additional Disks: {run_windows_command(ip, username, password, 'wmic logicaldisk get name, size, freespace')}")
    results.append(f"DNS Name: {run_windows_command(ip, username, password, 'hostname')}")
    results.append(f"SSH Keys: {run_windows_command(ip, username, password, 'dir %USERPROFILE%\\.ssh\\id_* 2>NUL')}")
    results.append(f"Authorized Keys: {run_windows_command(ip, username, password, 'type %USERPROFILE%\\.ssh\\authorized_keys 2>NUL')}")
    results.append("\n--- Tools Validation ---")
    results.append("Tool: CrowdStrike")
    results.append(f" Package Status: {run_windows_command(ip, username, password, 'wmic product get name | findstr /I \"Falcon\"')}")
    results.append(f" Service Status: {run_windows_command(ip, username, password, 'sc query \"Falcon Sensor\"')}")
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="Remote VM Validation Script")
    parser.add_argument('--host', required=True, help='Target VM IP address')
    parser.add_argument('--user', required=True, help='Username')
    parser.add_argument('--password', required=True, help='Password')
    parser.add_argument('--os', required=True, choices=['linux', 'windows'], help='Operating System')
    parser.add_argument('--output', required=True, help='Output log file name')

    args = parser.parse_args()

    output = validate_linux(args.host, args.user, args.password) if args.os == 'linux' else validate_windows(args.host, args.user, args.password)

    for line in output:
        log(line, args.output)


if __name__ == "__main__":
    main()
