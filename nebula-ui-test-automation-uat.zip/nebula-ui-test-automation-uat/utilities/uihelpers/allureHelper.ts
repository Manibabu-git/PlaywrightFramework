import fs from 'fs';
import path from 'path';
import { allure } from 'allure-playwright';

/**
 * Attaches all files from a given directory to the Allure report.
 * @param directoryPath - Path to the directory containing report files.
 */
export async function attachAllReportsToAllure(directoryPath: string) {
    if (!fs.existsSync(directoryPath)) {
        console.warn(`Directory not found: ${directoryPath}`);
        return;
    }

    const files = fs.readdirSync(directoryPath);
    for (const file of files) {
        const filePath = path.join(directoryPath, file);
        const content = fs.readFileSync(filePath, 'utf8');
        const mimeType = getMimeType(file); // Optional: detect file type
        await allure.attachment(file, content, mimeType);
    }
}

/**
 * Simple MIME type resolver based on file extension.
 */
function getMimeType(fileName: string): string {
    const ext = path.extname(fileName).toLowerCase();
    switch (ext) {
        case '.json': return 'application/json';
        case '.html': return 'text/html';
        case '.txt': return 'text/plain';
        case '.png': return 'image/png';
        case '.jpg':
        case '.jpeg': return 'image/jpeg';
        default: return 'text/plain';
    }
}
