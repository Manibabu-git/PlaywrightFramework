import fs from 'fs/promises';
import { Page } from 'playwright';
import { Expect } from 'playwright/test';

export class GenericHelper {

    generateRandomString(length: number) {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            result += characters[randomIndex];
        }
        return result;
    }

    async waitForNumberOfSeconds(page: Page, seconds: number) {
        await page.waitForTimeout(seconds * 1000)
    }

    async extractTestCaseId(testTitle: string): Promise<string> {
        const match = testTitle.match(/APSRE-TC-\d+/);
        return match ? match[0] : 'UNKNOWN';
    }

    // Helper function to wait for file creation
    async waitForFile(filePath: string, timeout = 20000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            try {
                await fs.access(filePath);
                return;
            } catch {
                await new Promise((resolve) => setTimeout(resolve, 500));
            }
        }
        throw new Error(`File ${filePath} not found within timeout`);
    }

    async getLinkElementByDynamicText(page: Page, value: string) {
        const locator = `//a[contains(text(),'${value}')]`;
        const element = page.locator(locator);
        return element;
    }

    async downloadFile(page: Page) {
        // Trigger the download
        const [download] = await Promise.all([
            page.waitForEvent('download'), // Waits for the download to start
            page.click('button#firewall-download-dfm-btn'),
        ]);

        // Wait for the download to complete and get the path
        const path = await download.path();

        // Optionally, save it to a specific location
        const fileName = download.suggestedFilename();
        await download.saveAs(`downloads/${fileName}`);
        return fileName;
    }
    async returnHostname(domain: string, hostname: string) {
        let name
        if (domain.includes("CHARTERLAB")) {
            name = hostname + "." + domain.toLowerCase() + ".com"
        }
        else {
            name = hostname + ".stage.charter.com"
        }
        return name
    }

}