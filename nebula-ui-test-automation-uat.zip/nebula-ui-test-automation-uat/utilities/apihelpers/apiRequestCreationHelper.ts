import { readJsonFile, writeJsonFile } from '../uihelpers/jsonHelper'
import { Constant } from '../../globalConfig/globalConstants';
import { ApiHelper } from './apiHttpMethodsHelper';
import * as fs from 'fs'
import axios from "axios";
import FormData from "form-data";
import { generateRequestBody } from './dataHelper';
import path from 'path';

let isFirstBatch = true

export async function importResultsToQmetry(directory: string): Promise<string> {
    const authData = readJsonFile('./TestData/auth.json');
    const headers = {
        apiKey: authData.apiKey,
        Authorization: authData.Authorization,
        'Content-Type': 'application/json',
    };
    console.log('Headers:', JSON.stringify(headers, null, 2));

    const baseUrl = Constant.qmetryBaseUri;
    const apiHelper = new ApiHelper(baseUrl, headers);

    // Generate the request body with the current isFirstBatch state
    const requestBody = generateRequestBody(directory, isFirstBatch);

    const response = await apiHelper.post(baseUrl + '/rest/qtm4j/automation/latest/importresult', requestBody);

    const responseBody = await response.json();
    console.log(`Import Result Response for ${directory}:`, responseBody);

    writeJsonFile('./TestResponse/importResultResponse.json', responseBody);

    const url = responseBody.url;

    if (!url) {
        throw new Error('Url not found in the response of the import result API');
    }

    // Set isFirstBatch to false after the first successful API call
    isFirstBatch = false;

    return url;
}


export async function uploadResultToQmetry(directory: string) {
    const url = await importResultsToQmetry(directory);
    const authData = readJsonFile('./TestData/auth.json');
    const filePath = "./results.xml";

    const formData = new FormData();
    formData.append("file", fs.createReadStream(filePath));

    const headers = {
        ...formData.getHeaders(),
        "Content-Type": "multipart/form-data",
        apiKey: authData.apiKey,
        Authorization: authData.Authorization,
        Cookie: "FRRYERUN=02ae381138-3ab0-41lR6xYH1iURLXOK1lFAkG1wnpv4qyNcDMI_CvyE04Wh6GWNFijJ3W7g5joAbPLmMmBQE; JSESSIONID=BA2399FE4F86776659AAC059B736F168; atlassian.xsrf.token=B0F9-4A78-MDNM-4HSN_c43f703c275d584aa7774e6046e75b203342acda_lin",
    };

    axios
        .post(
            url,
            formData,
            { headers }
        )
        .then((response) => {
            console.log("Response:", response.status, response.data);
        })
        .catch((error) => {
            console.error("Error uploading file:", error.response?.data || error.message);
        });

}

export async function fetchTestCaseId(testCaseKey: string): Promise<string | null> {
    const authData = readJsonFile('./TestData/auth.json');
    const baseUrl = Constant.qmetryBaseUri;
    try {
        const response = await axios.post(
            'https://jira.charter.com/rest/qtm4j/qapi/latest/testcases/search?startAt=0&maxResults=100',
            {
                filter: {
                    labels: ['UAT_Regression'],
                    projectId: 105706
                }
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    apiKey: authData.openApiKey,
                    Authorization: authData.Authorization,
                }
            }
        );

        const testCases = response.data.data;
        const matchedTestCase = testCases.find((tc: any) => tc.key === testCaseKey);

        if (matchedTestCase) {
            return matchedTestCase.id;
        } else {
            console.error(`Test case with key ${testCaseKey} not found.`);
            return null;
        }
    } catch (error) {
        console.error('Error fetching test case ID:', error);
        return null;
    }
}

export async function uploadTestAttachment(testCaseKey: string) {
    const authData = readJsonFile('./TestData/auth.json');
    const testCaseId = await fetchTestCaseId(testCaseKey);
    if (!testCaseId) return;

    const videoFilePath = path.join(__dirname, '../../videos', `${testCaseKey}.webm`);
    console.log('Video Path during upload: ' + videoFilePath)
    if (!fs.existsSync(videoFilePath)) {
        console.error(`Video file not found: ${videoFilePath}`);
        return;
    }

    const formData = new FormData();
    formData.append('file', fs.createReadStream(videoFilePath));

    try {
        const response = await axios.post(
            `https://jira.charter.com/rest/qtm4j/qapi/latest/attachments/openapi/upload?attachmentLocation=TESTCASE&id=${testCaseId}&versionNo=1`,
            formData,
            {
                headers: {
                    ...formData.getHeaders(),
                    "Content-Type": "multipart/form-data",
                    apiKey: authData.openApiKey,
                    Authorization: authData.Authorization,
                    Cookie: "FRRYERUN=02ae381138-3ab0-41FlMuI9ls011pjaJMJHSCUwF_KdCNfuXF0cPLIM81YqgEywVVeqAC7y03c6jvRCxqjBo; JSESSIONID=12E312D3DA5C5749A14D3C3306225F59; atlassian.xsrf.token=B0F9-4A78-MDNM-4HSN_2efb44eb8036e684ee76b7c355ea0575fc7e6d85_lin",
                }
            }
        );

        console.log('Attachment uploaded successfully:', response.data);
    } catch (error) {
        console.error('Error uploading attachment:', error);
    }
}


