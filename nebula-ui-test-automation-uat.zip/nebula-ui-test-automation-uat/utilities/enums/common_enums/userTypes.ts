export enum UserTypes {
    Requestor,
    Approver
}