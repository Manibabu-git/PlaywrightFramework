export enum MenuItems {
    IaaS = "iaas",
    PaaS = "paas",
    Tools = "tools",
    My_Approvals = "My Approvals",
    My_Requests = "My Requests",
    My_Resources = "My Resources",
}
