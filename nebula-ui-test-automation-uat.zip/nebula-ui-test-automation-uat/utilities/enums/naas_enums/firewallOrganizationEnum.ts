export enum FirewallOrganizations {
    CustomerNet_Red = "CUSTOMERNET RED",
    CorpNet_Blue = "CORPNET BLUE",
    Unkwown_v6 = "UNKNOWN IPV6",
    Unkwown_v4 = "UNKNOWN IPV4",
    Aws = "AWS",
    Neo = "NEO"
}