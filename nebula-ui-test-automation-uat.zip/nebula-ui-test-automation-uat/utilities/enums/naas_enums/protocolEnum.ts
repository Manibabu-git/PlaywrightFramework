export enum Protocol {
    TCP = "TCP",
    UDP = "UDP",
    ICMP = "ICMP",
}