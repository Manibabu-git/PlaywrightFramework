// validateVM.ts

import { Client } from 'ssh2';

interface VMValidationParams {
  host: string;
  username: string;
  password: string;
}

export const validateVM = ({ host, username, password }: VMValidationParams) => {
  const conn = new Client();

  conn
    .on('ready', () => {
      console.log('SSH Connection ready');
      detectOSFamily(conn);
    })
    .on('error', (err) => {
      console.error('SSH connection error:', err);
    })
    .connect({
      host,
      port: 22,
      username,
      password,
      readyTimeout: 30000,
    });
};

const detectOSFamily = (conn: Client) => {
  const osDetectCmd = 'source /etc/os-release && echo $ID';

  conn.exec(osDetectCmd, (err, stream) => {
    if (err) throw err;

    let osOutput = '';
    stream
      .on('close', () => {
        const osId = osOutput.trim().toLowerCase();
        let osFamily: 'redhat' | 'debian' | 'unknown' = 'unknown';

        if (['rhel', 'centos', 'rocky', 'almalinux', 'fedora'].includes(osId)) {
          osFamily = 'redhat';
        } else if (['ubuntu', 'debian'].includes(osId)) {
          osFamily = 'debian';
        }

        console.log(`Detected OS family: ${osFamily} (${osId})`);
        runValidations(conn, osFamily);
      })
      .on('data', (data: Buffer) => {
        osOutput += data.toString();
      })
      .stderr.on('data', (data: Buffer) => {
        console.error(`Error detecting OS: ${data.toString()}`);
      });
  });
};

const runValidations = (conn: Client, osFamily: 'redhat' | 'debian' | 'unknown') => {
  const commonCommands = [
    { name: 'IP Address', cmd: 'hostname -I || ip a' },
    { name: 'Hostname', cmd: 'hostname' },
    { name: 'Disks', cmd: 'lsblk' },
    { name: 'SSH Keys', cmd: 'ls -l ~/.ssh/authorized_keys' },
    { name: 'OS Version', cmd: 'cat /etc/os-release || cat /etc/redhat-release || cat /etc/lsb-release' },
    { name: 'Centrify Status', cmd: 'systemctl status centrifydc' },
    { name: 'Tanium Status', cmd: 'systemctl status taniumclient' },
    { name: 'CrowdStrike Status', cmd: 'systemctl status falcon-sensor' },
  ];

  const osSpecificCommands = {
    redhat: [
      { name: 'Centrify Install', cmd: 'rpm -qa | grep centrify' },
      { name: 'Tanium Install', cmd: 'rpm -qa | grep tanium' },
      { name: 'CrowdStrike Install', cmd: 'rpm -qa | grep falcon-sensor' },
    ],
    debian: [
      { name: 'Centrify Install', cmd: 'dpkg -l | grep centrify' },
      { name: 'Tanium Install', cmd: 'dpkg -l | grep tanium' },
      { name: 'CrowdStrike Install', cmd: 'dpkg -l | grep falcon-sensor' },
    ],
    unknown: [],
  };

  const finalCommands = [...commonCommands, ...osSpecificCommands[osFamily]];

  runCommandsSequentially(conn, finalCommands);
};

const runCommandsSequentially = (conn: Client, commands: { name: string, cmd: string }[], index = 0) => {
  if (index >= commands.length) {
    console.log('\nAll validations complete.');
    conn.end();
    return;
  }

  const { name, cmd } = commands[index];
  console.log(`\nValidating: ${name}`);

  conn.exec(cmd, (err, stream) => {
    if (err) throw err;

    let output = '';
    stream
      .on('close', () => {
        console.log(`Output for ${name}:\n${output}`);
        runCommandsSequentially(conn, commands, index + 1);
      })
      .on('data', (data: Buffer) => {
        output += data.toString();
      })
      .stderr.on('data', (data: Buffer) => {
        console.error(`Error in ${name}: ${data.toString()}`);
      });
  });
};