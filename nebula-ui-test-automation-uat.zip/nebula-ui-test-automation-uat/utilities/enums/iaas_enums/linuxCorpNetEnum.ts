export enum LinuxCorpNet {
    Rhel_8 = "Rhel 8",
    Rhel_9 = "Rhel 9",
    Rocky_8 = "Rocky 8",
    Rocky_9 = "Rocky 9"
}