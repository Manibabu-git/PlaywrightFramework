export enum WindowsOs {
    Windows_2016 = "Windows-2016",
    Windows_2019 = "Windows-2019",
    Windows_2022 = "Windows-2022",
}