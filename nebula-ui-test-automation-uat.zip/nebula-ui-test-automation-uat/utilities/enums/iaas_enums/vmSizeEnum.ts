export enum VmSize {
    Small = 'Small( CPU: 4 Cores, Memory:',
    Medium = 'Medium( CPU: 8 Cores, Memory',
    Large = 'Large( CPU: 8 Cores, Memory',
    Custom = 'Custom'
}