export enum SecurityTools {
    CrowdStrike = 'CROWDSTRIKE',
    Centrify = 'Centrify',
    Qualys = 'Qualys'
}