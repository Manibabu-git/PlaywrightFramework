export enum IaasTabs {
    Network = "Network",
    Compute = "Compute",
    Storage = "Storage",
    Security = "Security",
}
