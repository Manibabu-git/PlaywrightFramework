export enum ComputeType {
    Virtual_Machine = "Virtual_Machine",
    Baremetal = "Baremetal",
    AWS_Instance = "AWS_Instance",
}
