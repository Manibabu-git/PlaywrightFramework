export enum ObservabilityTools {
    ScienceLogic = 'ScienceLogic',
    Splunk = 'Splunk',
    VmTools = 'VM Tools'
}