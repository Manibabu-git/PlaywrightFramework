export enum ComplianceTools {
    Tanium = 'TANIUM'
}