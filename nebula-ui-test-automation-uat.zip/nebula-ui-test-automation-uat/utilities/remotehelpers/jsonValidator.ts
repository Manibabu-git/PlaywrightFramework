import fs from 'fs';
import path from 'path';

type JsonValue = string | number | boolean | null | JsonObject | JsonValue[];
interface JsonObject {
    [key: string]: JsonValue;
}

function flattenObject(obj: JsonObject, prefix = ''): Record<string, any> {
    const result: Record<string, any> = {};
    for (const key in obj) {
        const value = obj[key];
        const newKey = prefix ? `${prefix}.${key}` : key;

        if (Array.isArray(value)) {
            result[newKey] = value;
        } else if (value && typeof value === 'object') {
            Object.assign(result, flattenObject(value as JsonObject, newKey));
        } else {
            result[newKey] = value;
        }
    }
    return result;
}

function normalize(val: any): any {
    if (Array.isArray(val)) {
        return val.map(v => String(v).toLowerCase().trim()).sort();
    }
    if (typeof val === 'string') {
        return val.toLowerCase().trim();
    }
    return val;
}

export function compareJsonAndWriteReport(expected: JsonObject, actual: JsonObject, outputFilePath: string): void {
    // Ensure folder exists
    const folderPath = path.dirname(outputFilePath);
    if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath, { recursive: true });
    }

    const flatExpected = flattenObject(expected);
    const flatActual = flattenObject(actual);

    const lines: string[] = [];
    const header = `${'Key'.padEnd(40)} | ${'Expected'.padEnd(30)} | ${'Actual'.padEnd(30)} | Status`;
    lines.push(header);
    lines.push('-'.repeat(header.length));

    for (const key in flatExpected) {
        const expectedVal = normalize(flatExpected[key]);
        const actualValRaw = key in flatActual ? flatActual[key] : 'N/A';
        const actualVal = normalize(actualValRaw);

        const status = actualValRaw === 'N/A'
            ? 'N/A'
            : JSON.stringify(expectedVal) === JSON.stringify(actualVal)
                ? 'PASS'
                : 'FAIL';

        lines.push(
            `${key.padEnd(40)} | ${String(flatExpected[key]).padEnd(30)} | ${String(actualValRaw).padEnd(30)} | ${status}`
        );
    }

    fs.writeFileSync(outputFilePath, lines.join('\n'), 'utf8');
    console.log(`Comparison report written to ${outputFilePath}`);
}
