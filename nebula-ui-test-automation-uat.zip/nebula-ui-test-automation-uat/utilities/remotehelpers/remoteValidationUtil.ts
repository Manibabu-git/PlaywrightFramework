import { test, expect } from '@playwright/test';
import { execFile } from 'child_process';
import fs from 'fs';

interface VmDetails {
    [key: string]: string | number | boolean | null;
}

function runExe(exePath: string, requestId: string): Promise<string> {
    return new Promise((resolve, reject) => {
        // Pass requestId to exe if needed
        execFile(exePath, [requestId], (err, stdout) => {
            if (err) return reject(err);
            resolve(stdout.trim());
        });
    });
}

function compareVmData(jsonData: VmDetails, reqUI: VmDetails, resUI: VmDetails, exeData: VmDetails) {
    const keys = new Set([
        ...Object.keys(jsonData),
        ...Object.keys(reqUI),
        ...Object.keys(resUI),
        ...Object.keys(exeData)
    ]);
    const results: any[] = [];

    for (const key of keys) {
        const jsonVal = jsonData[key];
        const reqVal = reqUI[key];
        const resVal = resUI[key];
        const exeVal = exeData[key];

        const match = jsonVal === reqVal && reqVal === resVal && resVal === exeVal;

        results.push({
            property: key,
            json: jsonVal ?? "N/A",
            requestUI: reqVal ?? "N/A",
            resourceUI: resVal ?? "N/A",
            exe: exeVal ?? "N/A",
            status: match ? "PASS" : "FAIL"
        });
    }

    return results;
}

test('Iterate through all VM requests and validate', async ({ page }) => {
    // 1. Load all request IDs from JSON
    const requestList = JSON.parse(fs.readFileSync('requests.json', 'utf8')).requests;

    for (const requestObj of requestList) {
        const requestId = requestObj.id;
        console.log(`\nValidating Request ID: ${requestId}`);

        // 2. Navigate to the VM details page for this request
        await page.goto(`https://your-portal/vm-details/${requestId}`);

        // 3. Scrape Request Details
        const requestUI: VmDetails = {
            CPU: await page.textContent('#request-cpu'),
            MemoryGB: await page.textContent('#request-memory'),
            OS: await page.textContent('#request-os'),
            DiskSizeGB: await page.textContent('#request-disk')
        };

        // 4. Scrape Resource Details
        const resourceUI: VmDetails = {
            CPU: await page.textContent('#resource-cpu'),
            MemoryGB: await page.textContent('#resource-memory'),
            OS: await page.textContent('#resource-os'),
            DiskSizeGB: await page.textContent('#resource-disk')
        };

        // 5. Load original JSON data for this request (stored when request was sent)
        const jsonData: VmDetails = JSON.parse(fs.readFileSync(`input-data/${requestId}.json`, 'utf8'));

        // 6. Run exe and parse output
        const exeOutput = await runExe('C:\\path\\to\\vmExtract.exe', requestId);
        const exeData: VmDetails = JSON.parse(exeOutput);

        // 7. Compare all four
        const results = compareVmData(jsonData, requestUI, resourceUI, exeData);
        console.table(results);

        // 8. Fail test if any mismatch
        results.forEach(row => {
            expect(row.status, `Mismatch in ${row.property} for Request ID ${requestId}`).toBe('PASS');
        });
    }
});



