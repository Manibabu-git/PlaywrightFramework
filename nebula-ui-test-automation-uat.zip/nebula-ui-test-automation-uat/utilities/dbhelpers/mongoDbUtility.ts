import { MongoClient } from 'mongodb';

export async function getActualDataFromMongo(collectionName: string, query: any) {
    const uri = process.env.DB_CONNECTION_STRING!
    const dbName = process.env.DB_NAME!
    const client = new MongoClient(uri);
    await client.connect();
    const db = client.db(dbName);
    const collection = db.collection(collectionName);
    const result = await collection.findOne(query);
    await client.close();
    return result;
}
