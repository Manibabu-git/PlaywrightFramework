import { GenericHelper } from '../utilities/uihelpers/genericHelper'
import { ComplianceTools, DiskFileSystem, InventoryTools, IpModes, IpRuleType, LinuxCmpGroups, LinuxOs, ObservabilityTools, RubrikSla, SecurityTools, UbuntuOs, VmSize, WinCmpGroups, WindowsOs } from '../utilities/enums'


export function generateVmTestData() {
    const genericHelper = new GenericHelper();

    return [

        {
            testName: "Verify Windows os  2016 VM creation",
            qmetryTestCaseId: "APSRE-TC-10414",
            jiraId: "VNVERTKwJlfO",
            osVersion: WindowsOs.Windows_2016,
            hostname: 'win-uat-' + genericHelper.generateRandomString(2),
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4,
            vmSize: VmSize.Small,
            additionalDisk: [true, DiskFileSystem.Ext4],
            cmpGroup: WinCmpGroups.AP_CMP_ADMINS
        },
        {
            testName: "Verify Windows os  2019  VM creation",
            qmetryTestCaseId: "APSRE-TC-10415",
            jiraId: "N0av7ULbvaCD",
            osVersion: WindowsOs.Windows_2019,
            hostname: 'win-uat-' + genericHelper.generateRandomString(2),
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4,
            vmSize: VmSize.Medium,
            additionalDisk: [false, DiskFileSystem.Ext4],
            cmpGroup: WinCmpGroups.AP_CMP_ADMINS
        },
        {
            testName: "Verify Windows os  2022 VM creation",
            qmetryTestCaseId: "NEBULA-TC-12678",
            jiraId: "eGOkKTWJmMsq",
            osVersion: WindowsOs.Windows_2022,
            hostname: 'win-uat-' + genericHelper.generateRandomString(2),
            ipModes: IpModes.Static_Auto,
            ipRuleType: IpRuleType.ipv4,
            vmSize: VmSize.Medium,
            additionalDisk: [true, DiskFileSystem.Ext4],
            cmpGroup: LinuxCmpGroups.AP_Nebula_APS_ReliabilityEng_Catalog_Admin
        }
    ]
}