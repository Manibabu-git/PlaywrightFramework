import { GenericHelper } from 'utilities/uihelpers/genericHelper'
import { ComplianceTools, ComputeCatalog, DiskFileSystem, InventoryTools, IpModes, IpRuleType, LinuxOs, ObservabilityTools, PaceIpv4, PaceIpv6, RubrikSla, SecurityTools, UbuntuOs, VmSize } from '../utilities/enums'


export function generateVmTestData() {
    const genericHelper = new GenericHelper();

    return [

        {
            testName: "Verify Linux VM creation for  RHEL 8.6",
            qmetryTestCaseId: "APSRE-TC-10397",
            jiraId: "7EjWXHmMwgSn",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Rhel_8_6,
            hostname: 'rhel86-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO24,
            multiVm: [true, '2', '1'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Custom,
            VMSizeDetails: {},
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.Qualys],
                "compliance": ComplianceTools.Tanium,
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools]
            }

        },
        {
            testName: "Verify Linux VM creation for  RHEL 8.10",
            qmetryTestCaseId: "APSRE-TC-10395",
            jiraId: "LqbP7hJkrxIL",
            catalog: ComputeCatalog.Linux,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Rhel_8_10,
            hostname: 'rhel810-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            vmSize: VmSize.Large,
            ipModes: IpModes.Static_Auto,
            ipV4: "NA",
            ipV6: "NA",
            ipRuleType: IpRuleType.ipv4v6,
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },
        {
            testName: "Verify Linux VM creation for  RHEL 8.8",
            qmetryTestCaseId: "APSRE-TC-10398",
            jiraId: "JpLZ7c436Li2",
            catalog: ComputeCatalog.Linux,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            osVersion: LinuxOs.Rhel_8_8,
            hostname: 'rhel88-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO6,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Small,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv6,
            ipV4: "NA",
            ipV6: PaceIpv6.CTEC_V6_3,
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },

        {
            testName: "Verify Linux VM creation for  RHEL 9.0",
            qmetryTestCaseId: "APSRE-TC-10399",
            jiraId: "1RWQeCd6VwUZ",
            catalog: ComputeCatalog.Linux,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            osVersion: LinuxOs.Rhel_9_0,
            hostname: 'rhel90-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [true, '2', '01'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Medium,
            additionalDisk: [false, DiskFileSystem.Ext4],
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: PaceIpv4.CDP_V4_3,
            ipV6: PaceIpv6.CDP_V6_2,
            "tools": {
                "security": [SecurityTools.Centrify],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium
            }

        },
        {
            testName: "Verify Linux VM creation for  RHEL 9.2",
            qmetryTestCaseId: "APSRE-TC-10400",
            jiraId: "QLrWQUyb8JfW",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CDP",
            osVersion: LinuxOs.Rhel_9_2,
            hostname: 'rhel92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO24,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Large,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4,
            ipV4: PaceIpv4.CDP_V4_4,
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }
        },

        {
            testName: "Verify Linux VM creation for  RHEL 9.4",
            qmetryTestCaseId: "APSRE-TC-10401",
            jiraId: "PQnR7u3ZPyuX",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            osVersion: LinuxOs.Rhel_9_4,
            hostname: 'rhel94-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO6,
            multiVm: [true, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Custom,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv6,
            ipV4: "NA",
            ipV6: PaceIpv6.CTEC_V6_4,
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.Qualys],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium
            }
        },

        {
            testName: "Verify Linux VM for Rocky 8.8(IPv6 only)",
            qmetryTestCaseId: "APSRE-TC-10405",
            jiraId: "Ry2GPSpPzWIz",
            catalog: ComputeCatalog.Linux,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            osVersion: LinuxOs.Rocky_8_8,
            hostname: 'rocky88-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO6,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Large,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: PaceIpv4.CTEC_V4_3,
            ipV6: PaceIpv6.CTEC_V6_2,
            "tools": {
                "security": [SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },


        {
            testName: "Verify Linux VM for Rocky 9.4",
            qmetryTestCaseId: "APSRE-TC-10408",
            jiraId: "OnNe7ClQkGud",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            osVersion: LinuxOs.Rocky_9_4,
            hostname: 'or92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO6,
            multiVm: [true, '1', '01'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Medium,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4,
            ipV4: PaceIpv4.CTEC_V4_4,
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.Qualys],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },

        {
            testName: "Verify Linux VM for Rocky 9.2",
            qmetryTestCaseId: "APSRE-TC-10407",
            jiraId: "GKp37SORjXhj",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CDP",
            osVersion: LinuxOs.Rocky_9_2,
            hostname: 'or92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO24,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Small,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: PaceIpv4.CDP_V4_2,
            ipV6: PaceIpv6.CDP_V6_4,
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },

        {
            testName: "Verify Linux VM for Rocky 9.0",
            qmetryTestCaseId: "APSRE-TC-10406",
            jiraId: "WqDdWhg4rOck",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Rocky_9_0,
            hostname: 'or92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [true, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Custom,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.Qualys],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium
            }

        },
        {
            testName: "Verify Linux VM for Rocky 8.6",
            qmetryTestCaseId: "APSRE-TC-10404",
            jiraId: "eGOkKTyMgPCq",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CDP",
            osVersion: LinuxOs.Rocky_8_6,
            hostname: 'or92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO24,
            multiVm: [true, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Medium,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv6,
            ipV4: "NA",
            ipV6: PaceIpv6.CDP_V6_3,
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.Qualys],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium
            }

        },

        {
            testName: "Verify Linux VM for Rocky 8.10",
            qmetryTestCaseId: "APSRE-TC-10402",
            jiraId: "Kp2Q7czgm1TM",
            catalog: ComputeCatalog.Linux,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Rocky_8_10,
            hostname: 'or92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Small,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv6,
            ipV4: "NA",
            ipV6: PaceIpv6.CTEC_V6_3,
            "tools": {
                "security": [SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },
        {
            testName: "Verify Linux VM creation for Alma 8.8",
            qmetryTestCaseId: "APSRE-TC-10390",
            jiraId: "nbZkEclWrPH6",
            catalog: ComputeCatalog.Linux,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Alma_8_8,
            hostname: 'alma88-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Small,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Auto,
            ipRuleType: IpRuleType.ipv4,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },
        {
            testName: "Verify Linux VM creation for Alma 9.0",
            qmetryTestCaseId: "APSRE-TC-10391",
            jiraId: "6EJRYHmxXnHr",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CDP",
            osVersion: LinuxOs.Alma_9_0,
            hostname: 'alma90-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO24,
            multiVm: [true, '1', '01'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Medium,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: PaceIpv4.CDP_V4_1,
            ipV6: PaceIpv6.CDP_V6_1,
            "tools": {
                "security": [SecurityTools.Qualys],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium
            }

        },
        {
            testName: "Verify Linux VM creation for Alma 9.4",
            qmetryTestCaseId: "NEBULA-TC-18484",
            jiraId: "3vOKWI6NzKHZ",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Alma_9_4,
            hostname: 'alma94-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [true, '1', '01'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Custom,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Auto,
            ipRuleType: IpRuleType.ipv6,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Qualys],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium
            }

        },
        {
            testName: "Verify Linux VM creation for Alma 9.2 with  custom size",
            qmetryTestCaseId: "APSRE-TC-10392",
            jiraId: "q4QkVioZl6cK",
            catalog: ComputeCatalog.Linux,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            osVersion: LinuxOs.Alma_9_2,
            hostname: 'alma92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO6,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Large,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: PaceIpv4.CTEC_V4_1,
            ipV6: PaceIpv6.CTEC_V6_1,
            "tools": {
                "security": [SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },
        {
            testName: "Verify Linux VM creation for Oracle 9.2",
            qmetryTestCaseId: "APSRE-TC-10393",
            jiraId: "beR8xfmOR1t8",
            catalog: ComputeCatalog.Linux,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Oracle_9_2,
            hostname: 'orc92-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO24,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Small,
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }
        },
        {
            testName: "Verify Linux VM creation for Oracle 9.4",
            qmetryTestCaseId: "APSRE-TC-10394",
            jiraId: "lxZkYC8jwyt7",
            catalog: ComputeCatalog.Linux_Admin,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: LinuxOs.Oracle_9_4,
            hostname: 'orc94-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.RPO6,
            multiVm: [true, '2', '01'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Medium,
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.CrowdStrike],
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools],
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },

    ];
}