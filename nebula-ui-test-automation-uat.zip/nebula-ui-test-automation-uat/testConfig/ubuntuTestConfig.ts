import { ComplianceTools, ComputeCatalog, DiskFileSystem, InventoryTools, LinuxCmpGroups, ObservabilityTools, SecurityTools, UbuntuOs, VmSize, WinCmpGroups } from '../utilities/enums'
import { GenericHelper } from 'utilities/uihelpers/genericHelper'

export function generateVmTestData() {
    const genericHelper = new GenericHelper();

    return [

        {
            testName: "Verify Ubuntu 20.04 VM creation",
            qmetryTestCaseId: "APSRE-TC-10410",
            jiraId: "XOL2Gfz7rEUY",
            catalog: ComputeCatalog.Ubuntu,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: UbuntuOs.Ubuntu_20,
            hostname: 'ubu20-uat-' + genericHelper.generateRandomString(2),
            vmSize: VmSize.Small,
            additionalDisk: [false],
            cmpGroup: LinuxCmpGroups.AP_Nebula_APS_ReliabilityEng_Catalog_Admin,
            "tools": {
                "security": [SecurityTools.CrowdStrike, SecurityTools.Qualys],
                "observability": ObservabilityTools.ScienceLogic,
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },
        {
            testName: "Verify Ubuntu 22.04 VM creation(cus)",
            qmetryTestCaseId: "APSRE-TC-10411",
            jiraId: "EmZy7ul83nfk",
            catalog: ComputeCatalog.Ubuntu_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CDP",
            osVersion: UbuntuOs.Ubuntu_22,
            hostname: 'ubu22-uat-' + genericHelper.generateRandomString(2),
            vmSize: VmSize.Custom,
            additionalDisk: [false],
            cmpGroup: LinuxCmpGroups.AP_Nebula_APS_ReliabilityEng_Catalog_Admin,
            "tools": {
                "security": [SecurityTools.Qualys],
                "observability": ObservabilityTools.ScienceLogic,
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        },
        {
            testName: "Verify Ubuntu 24.04 VM creation(Add disk)",
            qmetryTestCaseId: "APSRE-TC-10412",
            jiraId: "dVGZPIzlj4IN",
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            catalog: ComputeCatalog.Ubuntu_Admin,
            osVersion: UbuntuOs.Ubuntu_24,
            hostname: 'ubu24-uat-' + genericHelper.generateRandomString(2),
            vmSize: VmSize.Medium,
            additionalDisk: [true, DiskFileSystem.Xfs],
            cmpGroup: WinCmpGroups.AP_CMP_ADMINS,
            "tools": {
                "security": [SecurityTools.CrowdStrike, SecurityTools.Qualys],
                "observability": ObservabilityTools.ScienceLogic,
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        }
    ];
}
