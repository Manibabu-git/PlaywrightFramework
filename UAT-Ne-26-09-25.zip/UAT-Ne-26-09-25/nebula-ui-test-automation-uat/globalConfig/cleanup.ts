import fs from 'fs';
import path from 'path';

const directoriesToClean = ['allure-results', 'screenshots', 'downloads', 'videos'];
const filesToKeep = ['executor.json', 'categories.json', 'environment.properties'];
const jsonFilesToClear = ['hostnames.json', 'installedToolsRecord.json', 'ipAddress.json', 'requestIds.json', 'vmCreationRecord.json'];

export const cleanupDirectories = () => {
    // Clean specified directories
    directoriesToClean.forEach((dir) => {
        fs.readdir(dir, (err, files) => {
            if (err) {
                console.error(`Error reading directory ${dir}:`, err);
                return;
            }

            files.forEach((file) => {
                if (!filesToKeep.includes(file)) {
                    fs.unlink(path.join(dir, file), (err) => {
                        if (err) {
                            console.error(`Error deleting file ${file}:`, err);
                        } else {
                            console.log(`Deleted file ${file}`);
                        }
                    });
                }
            });
        });
    });

    // Clear contents of specific JSON files
    jsonFilesToClear.forEach((fileName) => {
        const filePath = path.resolve(__dirname, fileName);
        try {
            fs.writeFileSync(filePath, JSON.stringify({}, null, 2), 'utf-8');
            console.log(`Cleared contents of ${fileName}`);
        } catch (err) {
            console.error(`Error clearing file ${fileName}:`, err);
        }
    });
};
