import { ComplianceTools, ComputeCatalog, DiskFileSystem, InventoryTools, IpModes, IpRuleType, LinuxCmpGroups, ObservabilityTools, PaceIpv4, PaceIpv6, RubrikSla, SecurityTools, UbuntuOs, VmSize, WinCmpGroups } from '../utilities/enums'
import { GenericHelper } from 'utilities/uihelpers/genericHelper'

export function generateVmTestData() {
    const genericHelper = new GenericHelper();

    return [

        {
            testName: "Verify Ubuntu 20.04 VM creation",
            qmetryTestCaseId: "APSRE-TC-10410",
            jiraId: "XOL2Gfz7rEUY",
            catalog: ComputeCatalog.Ubuntu,
            domain: "APVS-RED",
            project: "Vmware Demo Project",
            application: "VMWare Test App",
            environment: "VmWare Test Env",
            datacenter: "STAMP-VMWARE",
            osVersion: UbuntuOs.Ubuntu_20,
            hostname: 'ubu20-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [false, '', ''], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Large,
            VMSizeDetails: {},
            additionalDisk: [true, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Auto,
            ipRuleType: IpRuleType.ipv4v6,
            ipV4: "NA",
            ipV6: "NA",
            "tools": {
                "security": [SecurityTools.Centrify, SecurityTools.Qualys],
                "compliance": ComplianceTools.Tanium,
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools]
                }
        },
        {
            testName: "Verify Ubuntu 22.04 VM creation(cus)",
            qmetryTestCaseId: "APSRE-TC-10411",
            jiraId: "EmZy7ul83nfk",
            catalog: ComputeCatalog.Ubuntu_Admin,
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CDP",
            osVersion: UbuntuOs.Ubuntu_22,
            hostname: 'ubu22-uat-' + genericHelper.generateRandomString(2),
            rubrikSla: RubrikSla.Unprotected,
            multiVm: [true, '2', '1'], //params = {isMultiVm,totalVmCount, startingSequence}
            vmSize: VmSize.Custom,
            VMSizeDetails: {},
            additionalDisk: [false, DiskFileSystem.Ext4], //params = {shouldHaveAdditionalDisk, diskType}
            ipModes: IpModes.Static_Manual,
            ipRuleType: IpRuleType.ipv4,
            ipV4: PaceIpv4.CDP_V4_1,
            ipV6: PaceIpv6.CDP_V6_1,
            "tools": {
                "security": [SecurityTools.CrowdStrike, SecurityTools.Qualys],
                "compliance": ComplianceTools.Tanium,
                "observability": [ObservabilityTools.Splunk, ObservabilityTools.VmTools]
                }
        },
        {
            testName: "Verify Ubuntu 24.04 VM creation(Add disk)",
            qmetryTestCaseId: "APSRE-TC-10412",
            jiraId: "dVGZPIzlj4IN",
            domain: "CharterLab",
            project: "PACE-UAT",
            application: "PACE-UAT-APP",
            environment: "PACE-UAT-ENV",
            datacenter: "CTEC",
            catalog: ComputeCatalog.Ubuntu_Admin,
            osVersion: UbuntuOs.Ubuntu_24,
            hostname: 'ubu24-uat-' + genericHelper.generateRandomString(2),
            vmSize: VmSize.Medium,
            additionalDisk: [true, DiskFileSystem.Xfs],
            cmpGroup: WinCmpGroups.AP_CMP_ADMINS,
            "tools": {
                "security": [SecurityTools.CrowdStrike, SecurityTools.Qualys],
                "observability": ObservabilityTools.ScienceLogic,
                "compliance": ComplianceTools.Tanium,
                "inventory": InventoryTools.Granite
            }

        }
    ];
}
