import { expect, Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeType, RequestStatus, FirewallOrganizations, FirewallTickets, FirewallTicketStatus, ComputeCatalog } from "utilities/enums/"
import { GenericHelper } from "utilities/uihelpers/genericHelper";
import * as fs from 'fs'

export class MyRequestsViewDetailsPage extends HelperBase {

    //Common Objects
    readonly requestStatus: Locator
    readonly approvalStatus: Locator
    readonly activityLogsSection: Locator
    readonly activityLogsStepHeader: Locator
    readonly activityLogsStepStatus: Locator
    readonly nextActivityLogs: Locator
    readonly prevActivityLogs: Locator

    //NaaS Specific Objects
    readonly subRequestSection: Locator
    readonly impactedOrganizationList: Locator
    readonly consolidatedRules: Locator
    readonly cancelAll: Locator
    readonly proceed: Locator
    readonly resubmit: Locator
    readonly downloadDfm: Locator
    readonly newFirewallRequestId: Locator


    //IaaS Specific Objects
    readonly ubuntuDetails: Locator
    readonly linuxDetails: Locator
    readonly ubuntuAdminDetails: Locator
    readonly linuxAdminDetails: Locator
    readonly windowsDetails: Locator
    readonly windowsAdminDetails: Locator
    readonly networkDetails: Locator
    readonly toolsDetails: Locator
    readonly domain: Locator
    readonly project: Locator
    readonly application: Locator
    readonly environment: Locator
    readonly vmSize: Locator
    readonly vmCount: Locator
    readonly datacenter: Locator
    readonly hostname: Locator
    readonly osVersion: Locator
    readonly appId: Locator
    readonly appRefId: Locator
    readonly description: Locator
    readonly sshKey: Locator
    readonly rubrik: Locator
    readonly cpu: Locator
    readonly memory: Locator
    readonly storage: Locator
    readonly additionalDiskCount: Locator
    readonly additionalDiskSize: Locator
    readonly additionalDiskName: Locator
    readonly additionalDiskFileSystem: Locator
    readonly network: Locator
    readonly customDomain: Locator
    readonly ipModes: Locator
    readonly ipv4: Locator
    readonly ipv6: Locator

    constructor(page: Page) {
        super(page)
        this.requestStatus = this.page.locator("//h6[contains(text(),'Request Status')]/following-sibling::h6//div/span")
        this.approvalStatus = this.page.locator("//h6[contains(text(),'Approval Status')]/following-sibling::h6//div/span")
        this.subRequestSection = this.page.getByRole('button', { name: 'Sub Requests' })
        this.impactedOrganizationList = this.page.locator("//strong[contains(text(),'Impacted Device Organization')]/..")
        this.activityLogsSection = this.page.getByRole('button', { name: 'Request Status - Activity Log' })
        this.consolidatedRules = this.page.getByRole('button', { name: 'Consolidated Rules' })
        this.activityLogsStepHeader = this.page.locator("//h6[contains(text(),'Request Status - Activity Log')]/../../../../following-sibling::div//div//h6[contains(@class,'subtitle2 ')]")
        this.activityLogsStepStatus = this.page.locator("//h6[contains(text(),'Start')]/../../../../..//span[contains(text(),'completed') or contains(text(),'skipped') or contains(text(),'failed')]")
        this.nextActivityLogs = this.page.getByTestId('KeyboardArrowRightIcon')
        this.prevActivityLogs = this.page.getByTestId('KeyboardArrowLeftIcon')
        this.cancelAll = this.page.locator('#cancel-request-btn')
        this.proceed = this.page.getByRole('button', { name: 'Proceed' });
        this.resubmit = this.page.getByRole('button', { name: 'Re-Submit' })
        this.downloadDfm = this.page.getByRole('button', { name: 'Download DFM' })
        this.newFirewallRequestId = this.page.locator("//strong[contains(text(),'Re-Submitted Request ID:')]/following-sibling::div/span")
        this.ubuntuDetails = this.page.getByRole('button', { name: 'Ubuntu V3 Details' })
        this.linuxDetails = this.page.getByRole('button', { name: 'Linux 8 & 9 V3 Details' })
        this.ubuntuAdminDetails = this.page.getByRole('button', { name: 'Ubuntu V3 Admin Details' })
        this.linuxAdminDetails = this.page.getByRole('button', { name: 'Linux 8 & 9 V3 Admin Details' })
        this.windowsDetails = this.page.getByRole('button', { name: 'Windows V3 Details' })
        this.windowsAdminDetails = this.page.getByRole('button', { name: 'Windows Admin Details' })
        this.networkDetails = this.page.getByRole('button', { name: 'Network Details' })
        this.toolsDetails = this.page.getByRole('button', { name: 'Tools Details' })
        this.domain = this.page.locator("(//h6[contains(text(),'Domain')]/following-sibling::h6)[last()-1]")
        this.project = this.page.locator("//h6[contains(text(),'Project')]/following-sibling::h6")
        this.application = this.page.locator("//h6[contains(text(),'Application')]/following-sibling::h6")
        this.environment = this.page.locator("//h6[contains(text(),'Environment')]/following-sibling::h6")
        this.vmSize = this.page.locator("//h6[contains(text(),'VM Size')]/following-sibling::h6")
        this.vmCount = this.page.locator("//h6[contains(text(),'VM Count')]/following-sibling::h6")
        this.hostname = this.page.locator("//h6[contains(text(),'Hostname')]/following-sibling::h6")
        this.osVersion = this.page.locator("//h6[contains(text(),'OS Version')]/following-sibling::h6")
        this.appId = this.page.locator("//h6[contains(text(),'App Id')]/following-sibling::h6")
        this.appRefId = this.page.locator("//h6[contains(text(),'App Ref Id')]/following-sibling::h6")
        this.description = this.page.locator("//h6[contains(text(),'Description')]/following-sibling::h6")
        this.datacenter = this.page.locator("//h6[contains(text(),'Datacenter')]/following-sibling::h6")
        this.sshKey = this.page.locator("//h6[contains(text(),'SSH Key')]/following-sibling::h6")
        this.cpu = this.page.locator("//h6[contains(text(),'CPU')]/following-sibling::h6")
        this.rubrik = this.page.locator("//h6[contains(text(),'Rubrik')]/following-sibling::h6")
        this.memory = this.page.locator("//h6[contains(text(),'Memory')]/following-sibling::h6")
        this.storage = this.page.locator("//h6[contains(text(),'Storage')]/following-sibling::h6")
        this.additionalDiskName = this.page.locator("//div[@data-field='diskName']/div[@class='MuiDataGrid-cellContent']")
        this.additionalDiskCount = this.page.locator("//div[@data-field='disk']/div[@class='MuiDataGrid-cellContent']")
        this.additionalDiskSize = this.page.locator("//div[@data-field='diskSize']/div[@class='MuiDataGrid-cellContent']")
        this.additionalDiskFileSystem = this.page.locator("//div[@data-field='diskFileSystem']/div[@class='MuiDataGrid-cellContent']")
        this.network = this.page.locator("//h6[contains(text(),'Network')]/following-sibling::h6")
        this.customDomain = this.page.locator("//h6[contains(text(),'Custom')]/following-sibling::h6")
        this.ipModes = this.page.locator("//h6[contains(text(),'IP Modes')]/following-sibling::h6")
        this.ipv4 = this.page.locator("//h6[contains(text(),'IPv4')]/following-sibling::h6")
        this.ipv6 = this.page.locator("//h6[contains(text(),'IPv6')]/following-sibling::h6")
    }


    /* 
      Retrieve status of the request
    */
    async retrieveRequestStatus(): Promise<string> {
        this.page.reload()
        await this.waitForNumberOfSeconds(2)
        const status = await this.requestStatus.textContent()
        if (typeof (status) !== 'string') {
            throw new Error("Invalid value returned for status check")
        }
        else {
            return status
        }
    }

    /* 
      Wait for your required status to be displayed. Refer RequestStatus enums for all acceptable values
    */
    async waitForRequiredRequestStatus(requiredStatus: RequestStatus) {
        let currentStatus = await this.requestStatus.textContent()
        let counter = 0
        while (requiredStatus !== currentStatus && counter < 25) {
            await this.waitForNumberOfSeconds(18)
            this.page.reload()
            counter++
            currentStatus = await this.requestStatus.textContent()
        }
        expect(currentStatus).toEqual(requiredStatus)
    }

    /* 
        Retrieve all activity logs along with their statuses in key-value format
     */
    async fetchVisibleActivityLogs() {
        await this.activityLogsSection.click()
        await this.waitForNumberOfSeconds(2)
        const headers = await this.activityLogsStepHeader.allTextContents();
        const statuses = await this.activityLogsStepStatus.allTextContents();
        const activityLogs: { [key: string]: string } = {};

        let statusIndex = 0;
        headers.forEach(header => {
            if (header.toLowerCase() !== 'start' && header.toLowerCase() !== 'end') {
                activityLogs[header] = statuses[statusIndex];
                statusIndex++;
            }
        });

        console.log("Visible Activity Logs: ", activityLogs);
        return activityLogs;
    }


    async fetchAllActivityLogs() {
        const allLogs = await this.fetchVisibleActivityLogs();
        console.log("All Activity Logs Status: ", allLogs);
        return allLogs;
    }


    /* 
        Validate any particular activity log.
        You can provide single activity log and it's expected status or you can provide multiple activity logs having same status
    */
    async validateActivityLogStepStatus(steps: string[], expectedStatus: string) {
        const logs = await this.fetchAllActivityLogs();
        steps.forEach(step => {
            try {
                const status = logs[step];
                expect(status).toBe(expectedStatus);
            } catch (error) {
                console.error(`Step "${step}" failed. Expected status: "${expectedStatus}", but got: "${logs[step]}"`);
                throw error;
            }
        });
    }
    async validateActivityLogStatus(domain: string, steps: string[], expectedStatus: string) {
        const logs = await this.fetchAllActivityLogs();
        steps.forEach(step => {
            try {
                if (domain.includes("CharterLab") &&
                    !step.includes("Infoblox")) {
                    const status = logs[step];
                    expect(status).toBe(expectedStatus);
                }
            } catch (error) {
                console.error(`Step "${step}" failed. Expected status: "${expectedStatus}", but got: "${logs[step]}"`);
                throw error;
            }
        });
    }


    /* 
        Method to verify all impacted organization for firewall v2 requests
    */
    async verifyImpactedOrganization(expectedOrgNames: string[]) {
        await this.subRequestSection.click()
        const actualOrgNames = await this.impactedOrganizationList.evaluateAll(
            list => list.map(el => el.textContent?.trim().toLowerCase())
        )

        console.log('Actual Organization Names:', actualOrgNames);

        // Verify if expected organization names are part of actual organization names
        const allMatch = expectedOrgNames.every(expectedOrgName =>
            actualOrgNames.some(actualOrgName =>
                actualOrgName && actualOrgName.includes(expectedOrgName.toLowerCase())
            )
        );


        if (allMatch) {
            console.log('All expected organization names are present.');
        } else {
            console.log('All expected organization names are not  present.');
        }
    }

    /* 
        Method to verify approval status for provided firewall organization
     */
    async verifySubRequestApprovalStatus(firewwallOrganization: FirewallOrganizations, requestStatus: RequestStatus) {
        let currentStatus
        const subRequestLocator = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')])[last()]`;
        const subRequestSection = this.page.locator(subRequestLocator);
        await subRequestSection.click()
        this.waitForNumberOfSeconds(2)
        // Retrieve Sub-Request Status
        const subRequestStatusLocator = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//p[contains(text(),'Approval Status')]/following-sibling::div/span)[last()]`
        const subRequestStatus = this.page.locator(subRequestStatusLocator);
        currentStatus = await subRequestStatus.textContent()
        // Verifying the status
        expect(currentStatus).toBe(requestStatus)
        await subRequestSection.click()
    }

    /* 
        Verify sub-request status for individual firewall organization
     */
    async verifySubRequestStatus(firewwallOrganization: FirewallOrganizations, requestStatus: RequestStatus) {
        let currentStatus
        const subRequestLocator = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')])[last()]`;
        const subRequestSection = this.page.locator(subRequestLocator);
        await subRequestSection.click()


        // Retrieve sub-request status
        const subRequestStatusLocator = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//p[contains(text(),'Sub Request Status')]/following-sibling::span//span)[last()]`
        const subRequestStatus = this.page.locator(subRequestStatusLocator)
        currentStatus = await subRequestStatus.textContent()
        // Verifying the status
        let counter = 0
        while (requestStatus !== currentStatus && counter < 15) {
            await this.waitForNumberOfSeconds(5)
            this.page.reload()
            counter++
            currentStatus = await this.requestStatus.textContent()
            expect(currentStatus).toEqual(requestStatus)
        }

        await subRequestSection.click()
    }

    async retrieveTicketId(firewwallOrganization: FirewallOrganizations) {
        const subRequestTicketsId = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'Tickets')]/following-sibling::div//div/p)[last()-1]`
        let id
        const ticketId = this.page.locator(subRequestTicketsId)
        id = ticketId.textContent()
        //   switch (firewwallOrganization) {
        //             case FirewallOrganizations.Neo:

        //             break
        //             case FirewallOrganizations.CustomerNet_Red:

        //             break
        //             case FirewallOrganizations.CorpNet_Blue:

        //             break

        //             case FirewallOrganizations.Unkwown_v4:

        //             break

        //             case FirewallOrganizations.Unkwown_v6:

        //             break

        // }
        return id
    }

    /* 
        Verify created ticket against provided firewall organization
     */
    async verifyOrganizationTicketDetails(firewwallOrganization: FirewallOrganizations) {
        let actualTicketList
        let currentTicketStatus
        const subRequestLocator = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')])[last()]`;
        const subRequestSection = this.page.locator(subRequestLocator);
        await subRequestSection.click()
        this.waitForNumberOfSeconds(3)

        // Retrieve sub-request status
        const subRequestTicketsLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'Tickets')]/following-sibling::div//div/img`
        const subRequestTickets = this.page.locator(subRequestTicketsLocator)

        const subRequestTicketsStatus = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'Tickets')]/following-sibling::div//div/div/span/..`

        switch (firewwallOrganization) {
            case FirewallOrganizations.Neo:
                actualTicketList = await subRequestTickets.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim())
                );
                expect(actualTicketList).toEqual([FirewallTickets.Jira])
                const cboLocator = "(//h6[contains(text(),'red_cbo')]/../../../../following-sibling::div//h6[contains(text(),'Tickets')]/following-sibling::div//div/div/span)[1]"
                const cboTicket = this.page.locator(cboLocator)
                expect(cboTicket).toBeVisible()
                const neoTicketStatus = this.page.locator(subRequestTicketsStatus)
                currentTicketStatus = await neoTicketStatus.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()));
                expect(currentTicketStatus).toEqual([FirewallTicketStatus.CREATED])


                break

            case FirewallOrganizations.CustomerNet_Red:

                actualTicketList = await subRequestTickets.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()))
                expect(actualTicketList).toEqual([FirewallTickets.Jira, FirewallTickets.Tufin])
                const redTicketStatus = this.page.locator(subRequestTicketsStatus)
                currentTicketStatus = await redTicketStatus.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()));
                expect(currentTicketStatus).toEqual([FirewallTicketStatus.New, FirewallTicketStatus.CREATED])
                break

            case FirewallOrganizations.CorpNet_Blue:

                actualTicketList = await subRequestTickets.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()))
                expect(actualTicketList).toEqual([FirewallTickets.Tufin, FirewallTickets.Cherwell])
                const blueTicketStatus = this.page.locator(subRequestTicketsStatus)
                currentTicketStatus = await blueTicketStatus.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()));
                expect(currentTicketStatus).toEqual([FirewallTicketStatus.CREATED, FirewallTicketStatus.CREATED])

                break

            case FirewallOrganizations.Unkwown_v4:

                actualTicketList = await subRequestTickets.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()))
                expect(actualTicketList).toEqual([FirewallTickets.Jira, FirewallTickets.Jira, FirewallTickets.Tufin])
                const unknownTicketStatus = this.page.locator(subRequestTicketsStatus)
                currentTicketStatus = await unknownTicketStatus.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()));
                expect(currentTicketStatus).toEqual([FirewallTicketStatus.New, FirewallTicketStatus.New, FirewallTicketStatus.CREATED])

                break

            case FirewallOrganizations.Unkwown_v6:

                actualTicketList = await subRequestTickets.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()))
                expect(actualTicketList).toEqual([FirewallTickets.Jira, FirewallTickets.Cherwell])
                const v6TicketStatus = this.page.locator(subRequestTicketsStatus)
                currentTicketStatus = await v6TicketStatus.evaluateAll(
                    list => list.map(el => el.getAttribute('title')?.trim()));
                expect(currentTicketStatus).toEqual([FirewallTicketStatus.New, FirewallTicketStatus.CREATED])

                break

            case FirewallOrganizations.Aws:
                break
        }
    }

    /* 
      Verify created ticket against provided firewall organization once corresponding sub-request is approved
   */
    async verifyTicketsPostApproval(firewwallOrganization: FirewallOrganizations, requiredStatus: RequestStatus) {
        await this.waitForNumberOfSeconds(90)
        this.page.reload()
        let actualTicketList
        await this.subRequestSection.click()
        const subRequestLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')]`;
        const subRequestSection = this.page.locator(subRequestLocator);

        // Retrieve sub-request status
        const subRequestTicketsLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'Tickets')]/following-sibling::div//div/img`
        const subRequestTickets = this.page.locator(subRequestTicketsLocator)
        await subRequestSection.click()
        // this.verifySubRequestStatus(firewwallOrganization, requiredStatus)

        actualTicketList = await subRequestTickets.evaluateAll(
            list => list.map(el => el.getAttribute('title')?.trim()))
        //expect(actualTicketList).toEqual([FirewallTickets.Jira, FirewallTickets.Tufin, FirewallTickets.Remedy])
        expect(actualTicketList).toEqual([FirewallTickets.Jira, FirewallTickets.Tufin])

    }

    async openSubRequestSection() {
        await this.subRequestSection.click()
    }

    /* 
        Cancel All tickets
     */
    async cancelAllTickets() {
        await this.cancelAll.click()
        await this.proceed.click()
    }

    async reloadAndWait() {
        await this.page.reload()
        await this.waitForNumberOfSeconds(15)
        await this.page.reload()
    }

    /* 
       Verify created ticket status against provided firewall organization
    */
    async verifySubRequestTicketStatus(firewwallOrganization: FirewallOrganizations, requiredStatus: FirewallTicketStatus) {
        let actualTicketList
        this.openSubRequestSection()
        const subRequestLocator = `(//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')])[last()]`;
        const subRequestSection = this.page.locator(subRequestLocator);
        await subRequestSection.click()

        // Retrieve sub-request status
        const subRequestTicketsLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'Tickets')]/following-sibling::div//div/span/..`
        const subRequestTicketsStatus = this.page.locator(subRequestTicketsLocator)
        await this.waitForNumberOfSeconds(2)

        actualTicketList = await subRequestTicketsStatus.evaluateAll(
            list => list.map(el => el.getAttribute('title')?.trim()))
        console.log("List of statuses against " + firewwallOrganization + " org: " + actualTicketList)
        expect(actualTicketList).toContain(requiredStatus)
        this.openSubRequestSection()
    }

    async openConsolidatedRulesSection() {
        await this.consolidatedRules.click()
    }

    async resubmitFirewallRequest() {
        await this.resubmit.click()
        await this.proceed.click()
    }


    async retrieveNewFirewallRequestId() {
        return await this.newFirewallRequestId.textContent()
    }

    async downloadDfmFromMyRequest() {
        const [download] = await Promise.all([
            this.page.waitForEvent('download'),
            this.downloadDfm.click()
        ]);

        // Save the download to a local path
        const fileName = download.suggestedFilename();
        const downloadPath = `downloads/${fileName}`;
        await download.saveAs(downloadPath);

        // Check file size using fs.statSync
        const stats = fs.statSync(downloadPath);
        expect(stats.size).toBeGreaterThan(0);
    }

    async openToolsSection() {
        await this.toolsDetails.click()
    }


    async openVmDetailsSection(compute: string) {
        switch (compute) {
            case ComputeCatalog.Linux:
                await this.linuxDetails.click()
                break
            case ComputeCatalog.Linux_Admin:
                await this.linuxAdminDetails.click()
                break
            case ComputeCatalog.Ubuntu:
                await this.ubuntuDetails.click()
                break
            case ComputeCatalog.Ubuntu_Admin:
                await this.ubuntuAdminDetails.click()
                break
            case ComputeCatalog.Windows:
                await this.windowsDetails.click()
                break
            case ComputeCatalog.Windows_Admin:
                await this.windowsAdminDetails.click()
                break
        }
    }

    async openNetworkSection() {
        await this.networkDetails.click()
    }

    async verifyInstalledTools(toolsRecord: Record<string, boolean>) {
        const categorizedTools: Record<string, string[]> = {
            Security: [],
            Compliance: [],
            Observability: [],
            Inventory: []
        };

        const toolChecks: Record<string, Locator> = {
            Qualys: this.page.locator('g#Qualys_2017'),
            CrowdStrike: this.page.locator('g#Group_171646'),
            Centrify: this.page.locator('g#g3075'),
            ScienceLogic: this.page.locator('g#sciencelogic-seeklogo'),
            Splunk: this.page.locator('#Splunk_logo_1_'),
            Tanium: this.page.locator('g#Layer_1'),
            VmTools: this.page.locator('text#VM_Tools'),
            Granite: this.page.locator('g#Group_172616'),
        };

        const toolCategories: Record<string, string> = {
            Tanium: "Compliance",
            Qualys: "Security",
            CrowdStrike: "Security",
            Granite: "Inventory",
            Centrify: "Security",
            Splunk: "Observability",
            ScienceLogic: "Observability"
        };

        for (const [toolName, locator] of Object.entries(toolChecks)) {
            if (toolsRecord[toolName]) {
                const isVisible = await locator.isVisible().catch(() => false);
                if (isVisible) {
                    const category = toolCategories[toolName];
                    if (category) {
                        categorizedTools[category].push(toolName);
                    }
                }
            }
        }

        // Remove empty categories
        for (const category of Object.keys(categorizedTools)) {
            if (categorizedTools[category].length === 0) {
                delete categorizedTools[category];
            }
        }

        return categorizedTools;
    }


    async clickOnReflow(firewwallOrganization: FirewallOrganizations) {
        const subRequestLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//h6[contains(text(),'NEB-FW-SUB-REQ')]`;
        const subRequestSection = this.page.locator(subRequestLocator);
        await subRequestSection.click()
        const reflowLocator = `//h6[contains(text(),'${firewwallOrganization}')]/../../../../following-sibling::div//button[contains(text(),'Reflow')]`
        const reflow = this.page.locator(reflowLocator)
        await reflow.waitFor()
        await reflow.click()
        await this.proceed.click()
        await this.waitForNumberOfSeconds(5)
    }
    async retrieveDomain() {
        return await this.domain.textContent()
    }

    async retrieveProject() {
        return await this.project.textContent()
    }

    async retrieveDatacenter() {
        return await this.datacenter.textContent()
    }

    async retrieveEnvironment() {
        return await this.environment.textContent()
    }

    async retrieveVmCount() {
        return await this.vmCount.textContent()
    }

    async retrieveApplication() {
        return await this.application.textContent()
    }
    async retrieveCore() {
        return await this.cpu.textContent()
    }

    async retrieveMemory() {
        return await this.memory.textContent()
    }

    async retrieveStorage() {
        return await this.storage.textContent()
    }

    async retrieveAdditionalDiskCount() {
        if (await this.additionalDiskCount.isVisible()) {
            return await this.additionalDiskCount.textContent()
        }
        else {
            return "NA"
        }
    }

    async retrieveAdditionalDiskSize() {
        if (await this.additionalDiskSize.isVisible()) {
            return await this.additionalDiskSize.textContent()
        }
        else {
            return "NA"
        }
    }

    async retrieveAdditionalDiskName() {
        if (await this.additionalDiskName.isVisible()) {
            return await this.additionalDiskName.textContent()
        }
        else {
            return "NA"
        }
    }

    async retrieveAdditionalDiskFileSystem() {
        if (await this.additionalDiskFileSystem.isVisible()) {
            return await this.additionalDiskFileSystem.textContent()
        }
        else {
            return "NA"
        }
    }

    async retrieveRubrikDetails() {
        return await this.rubrik.textContent()
    }

    async retrieveDescription() {
        return await this.description.textContent()
    }

    async retrieveSshKey() {
        return await this.sshKey.textContent()
    }

    async retrieveHostname() {
        var host = await this.hostname.textContent()
        //host?.substring(0, host.indexOf('.'))
        return host
    }


    async retrieveOsVersion() {
        return await this.osVersion.textContent()
    }

    async retrieveVmSize() {
        return await this.vmSize.textContent()
    }

    async retrieveIpModes() {
        let value = await this.ipModes.textContent()
        if (value === "static_auto") {
            value = "Static-Auto"
        }
        else {
            value = "Static-Manual"
        }
        return value
    }

    async retrieveIpv4() {
        return await this.ipv4.textContent()
    }

    async retrieveIpv6() {
        return await this.ipv6.textContent()
    }
}