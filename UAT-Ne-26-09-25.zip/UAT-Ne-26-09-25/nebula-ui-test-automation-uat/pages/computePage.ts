import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeCatalog } from "utilities/enums/"


export class ComputePage extends HelperBase {

    readonly linux: Locator
    readonly ubuntu: Locator
    readonly windows: Locator
    readonly linuxAdmin: Locator
    readonly ubuntuAdmin: Locator
    readonly windowsAdmin: Locator
    readonly linuxCorpNet: Locator
    readonly windowsCorpNet: Locator

    constructor(page: Page) {
        super(page)
        this.linux = this.page.locator("(//h6[@title='Linux 8 & 9 V3'])[last()]")
        this.ubuntu = this.page.locator("(//h6[@title='Ubuntu V3'])[last()]")
        this.windows = this.page.locator("(//h6[@title='Windows V3'])[last()]")
        this.linuxAdmin = this.page.locator("(//h6[@title='Linux 8 & 9 V3 Admin'])[last()]")
        this.ubuntuAdmin = this.page.locator("(//h6[@title='Ubuntu V3 Admin'])[last()]")
        this.windowsAdmin = this.page.locator("(//h6[@title='Windows V3 Admin'])[last()]")
        this.linuxCorpNet = this.page.locator("(//h6[@title='Linux CorpNet'])[last()]")
        this.windowsCorpNet = this.page.locator("(//h6[@title='Windows CorpNet'])[last()]")
    }

    async selectComputeType(computeCatalogType: ComputeCatalog) {
        await this.waitForNumberOfSeconds(5)
        switch (computeCatalogType) {
            case ComputeCatalog.Linux: {
                await this.linux.click()
                break;
            }
            case ComputeCatalog.Ubuntu: {
                await this.ubuntu.click()
                break;
            }
            case ComputeCatalog.Linux_Admin: {
                await this.linuxAdmin.click()
                break;
            }
            case ComputeCatalog.Ubuntu_Admin: {
                await this.ubuntuAdmin.click()
                break;
            }
            case ComputeCatalog.Linux_Corpnet: {
                await this.linuxCorpNet.click()
                break;
            }
            case ComputeCatalog.Windows: {
                await this.windows.click()
                break;
            }
            case ComputeCatalog.Windows_Admin: {
                await this.windowsAdmin.click()
                break;
            }
            case ComputeCatalog.Windows_Corpnet: {
                await this.windowsCorpNet.click()
                break;
            }
            default: {
                await this.linux.click()
                break;
            }
        }

    }
}