import { Locator, Page, expect } from "@playwright/test";
import { HelperBase } from "./helperBase";


export class ResourcesPage extends HelperBase {

    readonly menuButton: Locator
    readonly filterButton: Locator
    readonly filterValue: Locator
    readonly resourceCountLabel: Locator
    readonly requestIdColumn: Locator
    readonly delete: Locator
    readonly stop: Locator
    readonly restart: Locator
    readonly copy: Locator
    readonly refresh: Locator
    readonly deleteConfirmation: Locator

    constructor(page: Page) {
        super(page)
        this.requestIdColumn = this.page.locator("//div[contains(text(),'Request Id')]")
        this.menuButton = this.page.locator("(//button[@aria-label='Menu'])[4]")
        this.filterButton = this.page.getByText('Filter', { exact: true })
        this.filterValue = this.page.getByPlaceholder('Filter value')
        this.resourceCountLabel = this.page.locator('.css-127oa7m > div > div > div').first()
        this.delete = this.page.getByTestId("DeleteOutlineOutlinedIcon")
        this.stop = this.page.locator('#btnMyResourceStopAction')
        this.restart = this.page.locator('#btnMyResourceRestartAction')
        this.copy = this.page.locator('#btnMyResourceCopy VmAction')
        this.refresh = this.page.locator('#btnMyResourceRefreshAction')
        this.deleteConfirmation = this.page.locator('#confirm-Delete-btn')
    }

    async filterResource(requestId: string) {
        await this.requestIdColumn.click()
        await this.waitForNumberOfSeconds(2)
        await this.menuButton.click()
        await this.filterButton.click()
        await this.waitForNumberOfSeconds(1)
        await this.filterValue.fill(requestId)
        await this.waitForNumberOfSeconds(2)
        await this.resourceCountLabel.click()
    }

    async selectResourceId(requestId: string) {
        const resourceIdLocator = this.page.locator(`(//a[contains(@id,'${requestId}')]/../preceding-sibling::div/a)[last()]`)
        resourceIdLocator.click()
    }

    async selectResourceCheckBox(requestId: string) {
        await this.waitForNumberOfSeconds(5)
        const resourceLocator = this.page.locator(`(//a[contains(@id,'${requestId}')]/../preceding-sibling::div//span/input)[last()]`)
        resourceLocator.click()
    }

    async deleteResource(requestId: string) {
        await expect(this.delete).toBeVisible()
        await this.delete.click()
        await expect(this.deleteConfirmation).toBeVisible()
        await this.deleteConfirmation.click()
    }
}