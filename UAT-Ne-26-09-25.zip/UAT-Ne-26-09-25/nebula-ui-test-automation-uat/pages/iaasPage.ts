import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { IaasTabs } from "utilities/enums/iaas_enums/iaasTabEnum"

export class IaasPage extends HelperBase {

    readonly computeTab: Locator
    readonly networkTab: Locator
    readonly securityTab: Locator
    readonly storageTab: Locator

    constructor(page: Page) {
        super(page)
        this.computeTab = this.page.getByRole('tab', { name: 'Compute' })
        this.networkTab = this.page.getByRole('tab', { name: 'Network' })
        this.securityTab = this.page.getByRole('tab', { name: 'Security' })
        this.storageTab = this.page.getByRole('tab', { name: 'Storage' })
    }

    async selectCompute(tab: IaasTabs) {
        await this.waitForNumberOfSeconds(2)
        if (tab === IaasTabs.Compute) {
            await this.computeTab.click()
        }
        if (tab === IaasTabs.Security) {
            await this.securityTab.click()
        }

    }

}
