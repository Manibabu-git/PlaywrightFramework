import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { ComputeCatalog } from "utilities/enums/"


export class VirtualMachineCorpnetPage extends HelperBase {

    

    constructor(page: Page) {
        super(page)
       
    }

}
