import { Locator, Page } from "@playwright/test";
import { HelperBase } from "./helperBase";
import { SecurityCatalog } from "../utilities/enums/naas_enums/securityCatalogEnum";



export class SecurityPage extends HelperBase {

    readonly addfirewallV2Rules: Locator
    readonly onboardCommonFirewallPolicy: Locator
    readonly pathAnalysis: Locator
    readonly deviceConfigLookup: Locator
    readonly dynamicAccessPolicy: Locator

    constructor(page: Page) {
        super(page)
        this.addfirewallV2Rules = this.page.locator("(//h6[@title='Add Firewall Rules V2'])[last()]")
        this.onboardCommonFirewallPolicy = this.page.locator("(//h6[@title='Onboard Common Firewall Application'])[last()]")
        this.dynamicAccessPolicy = this.page.locator("(//h6[@title='Dynamic Access Policies'])[last()]")
        this.pathAnalysis = this.page.locator("(//h6[@title='Path Analysis'])[last()]")
        this.deviceConfigLookup = this.page.locator("(//h6[@title='Device Config Lookup'])[last()]")
    }

    async selectSecurityCatalog(securityCatalog: SecurityCatalog) {
        await this.waitForNumberOfSeconds(5)
        switch (securityCatalog) {
            case SecurityCatalog.Add_Firewall_Rules_V2:
                await this.addfirewallV2Rules.click()
                break
            case SecurityCatalog.Device_Config_Lookup:
                await this.deviceConfigLookup.click()
                break
            case SecurityCatalog.Onboard_Common_Firewall_Application:
                await this.onboardCommonFirewallPolicy.click()
                break
            case SecurityCatalog.Dynamic_Access_Policies:
                await this.dynamicAccessPolicy.click()
                break
            case SecurityCatalog.Path_Analysis:
                await this.pathAnalysis.click()
            default:
                console.log("Unknown or Incorrect selection..")

        }


    }
}