import { test, expect } from '../../../fixture/pomFixture'
import {
    VmCreationActivityLogs, MenuItems, IaasTabs, UserTypes, ComputeCatalog,
    DiskFileSystem, Cluster, IpRuleType, WinCmpGroups
} from 'utilities/enums'
import * as allure from "allure-js-commons"
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper'
import { readJsonFile } from "utilities/uihelpers/jsonHelper";
import { generateVmTestData } from 'testConfig/windowsTestConfig';


let intakeFormData = readJsonFile('./TestData/vmIntakeFormData.json');
let toolsRecord: Record<string, boolean>
const testURL: string = process.env.TEST_URL!;
const vmTestData = generateVmTestData();
let vmCreationRecord: boolean

test.beforeEach(async ({ page }) => {
    await page.goto(testURL);
});


/*
 * Follwoing tests are validation tests which will be executed separately once VM creation tests are executed
*/
test.describe("VM Validation Tests", () => {
    for (const data of vmTestData) {
        test(`${data.testName} - ${data.qmetryTestCaseId}`, { tag: ['@Vm_Validation'] }, async ({ page, pageManager, screenshotHelper }) => {
            let ipAddress;
            let vm = readJsonFile("TestResponse\\vmCreationRecord.json")
            const testCaseId = data.qmetryTestCaseId
            if (!vm[testCaseId]) {
                await allure.description(`Validation Test Skipped because VM creation failed for ${data.testName}`);
                await allure.label("skipReason", "VM creation failed");
                return;
            }

            let requestId = readJsonFile('./TestResponse/requestIds.json');
            await allure.description(`Validate created ${data.osVersion} VM`);
            await allure.epic("IaaS");
            await allure.feature("VM Creation");
            await allure.story(`${data.testName} - ${data.qmetryTestCaseId}` + " on My Resources Page");
            await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
            await allure.owner("Rishi Khanna");

            await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
            await test.step('Navigate To My Request Page', async () => {
                await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Requests)
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToMyRequest');
            })
            await test.step('Open My Request', async () => {
                await pageManager.onMyRequestsHomePage().openRequestToViewDetails(requestId[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step02_ViewRequest');
            })
            await test.step('Verify Installed Tools', async () => {
                await pageManager.onMyRequestViewDetailsPage().openToolsSection()
                //await pageManager.onMyRequestViewDetailsPage().verifyInstalledTools(expectedTools[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step03_VerifyInstalledTools');
            })
            await test.step("Verify Activity Logs", async () => {
                await pageManager.onMyRequestViewDetailsPage().validateActivityLogStepStatus([VmCreationActivityLogs.Receive_VM_Request_Nebula,
                VmCreationActivityLogs.Approve_Request_Nebula, VmCreationActivityLogs.Quota_Validation_Nebula, VmCreationActivityLogs.Validate_VLan_Infoblox,
                VmCreationActivityLogs.Reserve_IP_Infoblox, VmCreationActivityLogs.Trace_and_Ping_Validation_Infoblox,
                VmCreationActivityLogs.Vcenter_Validation_Vcenter, VmCreationActivityLogs.Create_VM_VSphere, VmCreationActivityLogs.Check_VM_Status_VSphere,
                VmCreationActivityLogs.VM_Resource_Created_Nebula, VmCreationActivityLogs.Configure_VM_AWX, VmCreationActivityLogs.Check_VM_Configure_Status_AWX,
                VmCreationActivityLogs.Publish_Resource_Inventory_Data_Granite
                ], "completed")
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step04_Activity_Logs')
            })
            await test.step('Navigate To My Resources', async () => {
                await pageManager.navigateTo().navigateToMenuList(MenuItems.My_Resources)
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step05_NavigateToMyResources');
            })

            await test.step('Select resource', async () => {
                await pageManager.onMyResourcesPage().filterResource(requestId[testCaseId])
                await pageManager.onMyResourcesPage().selectResourceId(requestId[testCaseId])
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step06_SelectResource')
            })
            ipAddress = await pageManager.onMyResourcesDetailPage().retrieveIpAddress(IpRuleType.ipv4)
            saveVariableIntoJsonFile('TestResponse\\ipAddress.json', testCaseId, ipAddress)
            await test.step('Validate Created Resources', async () => {
                await screenshotHelper.captureScreenshot(page, testCaseId + '_Step07_ValidateResource')
                const projectName = await pageManager.onMyResourcesDetailPage().retrieveProject()
                expect(projectName).toBe(process.env.PROJECT!)

                const status = await pageManager.onMyResourcesDetailPage().retrieveResourceStatus()
                expect(status).toBe("RUNNING")

            })

        })
    }

    for (const data of vmTestData) {
        test.skip(`${data.testName} - ${data.qmetryTestCaseId}` + " on Remote Machine", { tag: ['@Vm_Validation'] }, async ({ page, pageManager }) => {
            const testCaseId = data.qmetryTestCaseId
            let vm = readJsonFile("TestResponse\\vmCreationRecord.json")
            if (!vm[testCaseId]) {
                await allure.description(`Validation Test Skipped because VM creation failed for ${data.testName}`);
                await allure.label("skipReason", "VM creation failed");
                test.skip()
                return;
            }

            let ip = readJsonFile('./TestResponse/ipAddress.json');
            let creds = readJsonFile('./TestData/vmCreds.json');
            await allure.description(`Validate created  ${data.osVersion}  VM`);
            await allure.epic("IaaS");
            await allure.feature("VM Creation");
            await allure.story(`${data.testName} - ${data.qmetryTestCaseId}` + " on remote VM");
            await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
            await allure.owner("Rishi Khanna");

            await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
            await test.step('Verify on remote machine ', async () => {

                const path = require('path');
                const { exec } = require('child_process');
                const ipAddress = ip[testCaseId]
                const username = creds["username"]
                const password = creds["password"]
                const osType = 'windows';
                const outputFile = `TestResponse\\VM_Validation_Responses\\${testCaseId}_${Date.now()}.log`;

                // Resolve the relative path to the Python script
                const scriptPath = path.resolve('./utilities/vmValidator/vm-validator.py');
                const command = `python "${scriptPath}" --host ${ipAddress} --user ${username} --password ${password} --os ${osType} --output ${outputFile}`;
                exec(command, (error: Error | null, stdout: string, stderr: string) => {
                    if (error) {
                        console.error(`Error: ${error.message}`);
                        expect(true).toBe(false);
                        return;
                    }
                    if (stderr) {
                        console.error(`Stderr: ${stderr}`);
                        return;
                    }
                    console.log(`Validation Output:\n${stdout}`);
                });
            })

        })
    }
})
