import { test, expect } from '../../../fixture/pomFixture'
import {
    MenuItems, IaasTabs, UserTypes, ComputeCatalog, RubrikSla,
    DiskFileSystem, IpModes, Cluster, IpRuleType, VmCreationActivityLogs
} from 'utilities/enums'
import * as allure from "allure-js-commons"
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper'
import { readJsonFile } from "utilities/uihelpers/jsonHelper";
import { generateVmTestData } from 'testConfig/ubuntuTestConfig'
import { getActualDataFromMongo } from 'utilities/dbhelpers/mongoDbUtility'

let intakeFormData = readJsonFile('./TestData/vmIntakeFormData.json');
let toolsRecord: Record<string, boolean>
let vmCreationRecord: boolean
const testURL: string = process.env.TEST_URL!;
const vmTestData = generateVmTestData();

test.beforeEach(async ({ page }) => {
    await page.goto(testURL);
});

test.describe("VM Creation Tests", () => {
    for (const data of vmTestData) {
        test(`${data.testName} - ${data.qmetryTestCaseId}` + " through Nebula", { tag: ['@Regression', '@IaaS', '@P2', '@Ubuntu'] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {
            const testCaseId = await genericHelper.extractTestCaseId(test.info().title);
            try {
                await allure.description(`Verify ${data.testName}`);
                await allure.epic("IaaS");
                await allure.feature("VM Creation");
                await allure.story(`Create Ubuntu VM - ${data.qmetryTestCaseId}`);
                await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
                await allure.owner("Rishi Khanna");
                await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
                await test.step('Navigate To IaaS > Security > Ubuntu Home Page', async () => {
                    await pageManager.navigateTo().navigateToMenuList(MenuItems.IaaS)
                    await pageManager.onIaasHomePage().selectCompute(IaasTabs.Compute)
                    await pageManager.onComputeHomePage().selectComputeType(ComputeCatalog.Ubuntu)
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step1_NavigateToUbuntu');
                })

                await test.step('Add Domain, Project, Application, Environmnet and OS Version', async () => {
                    await pageManager.onVirtualMachineCommonPage().selectDomain(process.env.DOMAIN!)
                    await pageManager.onVirtualMachineCommonPage().selectProjectId(process.env.PROJECT!)
                    await pageManager.onVirtualMachineCommonPage().selectApplication(process.env.APPLICATION!)
                    await pageManager.onVirtualMachineCommonPage().selectEnvironment(process.env.ENVIRONMENT!)
                    await pageManager.onVirtualMachineCommonPage().selectDatacenter(process.env.DATACENTER!)
                    await pageManager.onVirtualMachineCommonPage().selectOsVersion(`${data.osVersion}`)
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step2_AddProjectAndOs');
                })

                await test.step('Enter ssh keys, rubrik details, application instance, description and password', async () => {
                    await pageManager.onVirtualMachineCommonPage().enterSshKey(intakeFormData.ssh_key)
                    await pageManager.onVirtualMachineCommonPage().selectRubrikSla(RubrikSla.RPO24)
                    await pageManager.onVirtualMachineCommonPage().addDescription(intakeFormData.description)
                    await pageManager.onVirtualMachineCommonPage().addInitialPassword()
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step3_AddProjectDetails');
                })

                await test.step('Add Hostname and Vm Size Details', async () => {
                    await pageManager.onVirtualMachineCommonPage().enterHostname(`${data.hostname}`)
                    await pageManager.onVirtualMachineCommonPage().selectVmSize(`${data.vmSize}`, '4', '8')
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step4_AddHostAndVmDetails');
                })

                const [shouldAddDisk, diskFileSystem] = data.additionalDisk;

                await test.step('Add Additional Disk and Tags', async () => {
                    if (shouldAddDisk) {
                        await pageManager.onVirtualMachineCommonPage().addAdditionalDisk(shouldAddDisk, ComputeCatalog.Ubuntu, '1', diskFileSystem as DiskFileSystem);
                    }
                    // await pageManager.onVirtualMachineCommonPage().addTags()
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step5_AddTags');
                })

                await test.step('Add Network Details', async () => {
                    await pageManager.onVirtualMachineCommonPage().goNext()
                    await pageManager.onVirtualMachineCommonPage().selectNetworkDetails()
                    await pageManager.onVirtualMachineCommonPage().selectIpModes(IpModes.Static_Auto)
                    // await pageManager.onVirtualMachineCommonPage().selectClusterDetails(Cluster.SGPCIL02)
                    // await pageManager.onVirtualMachineCommonPage().selectGroups(data.cmpGroup)
                    await pageManager.onVirtualMachineCommonPage().selectIpType(IpRuleType.ipv4)
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step6_AddNetworkDetails');
                })
                const { security, observability, compliance, inventory } = data.tools;
                await test.step('Add Tools', async () => {
                    await pageManager.onVirtualMachineCommonPage().goNext()
                    await pageManager.onVirtualMachineCommonPage().selectTools(
                        security,
                        observability ? [observability] : undefined,
                        compliance ? [compliance] : undefined,
                        inventory ? [inventory] : undefined
                    );
                    toolsRecord = await pageManager.onVirtualMachineCommonPage().getSelectedToolsRecord()
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step7_AddTools');
                })

                await test.step('Submit and verify Vm Request', async () => {
                    await pageManager.onVirtualMachineCommonPage().submitVmRequest()
                    const successMessage = await pageManager.onRequestConfirmationPage().getSuccessMessage()
                    expect(successMessage).toBe('Request Submitted Successfully')
                    await screenshotHelper.captureScreenshot(page, testCaseId + '_Step9_VerifySubmission');
                })
                const requestId = await pageManager.onRequestConfirmationPage().retrieveRequestId()
                saveVariableIntoJsonFile('TestResponse\\requestIds.json', testCaseId, requestId)
                saveVariableIntoJsonFile('TestResponse\\installedToolsRecord.json', testCaseId, toolsRecord)
                vmCreationRecord = true
                saveVariableIntoJsonFile('TestResponse\\vmCreationRecord.json', testCaseId, vmCreationRecord)
            }
            catch (error) {
                vmCreationRecord = false
                saveVariableIntoJsonFile('TestResponse\\vmCreationRecord.json', testCaseId, vmCreationRecord)
                throw error;
            }
        })
    }
})
