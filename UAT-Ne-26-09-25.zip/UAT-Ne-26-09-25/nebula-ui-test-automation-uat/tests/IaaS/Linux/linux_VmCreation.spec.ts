import { test, expect } from '../../../fixture/pomFixture'
import {
    ComputeType, MenuItems, IaasTabs, UserTypes, ComputeCatalog,
    DiskFileSystem, Cluster, IpRuleType, VmCreationActivityLogs,
    IpModes
} from 'utilities/enums'
import * as allure from "allure-js-commons"
import { saveVariableIntoJsonFile } from 'utilities/uihelpers/jsonHelper'
import { readJsonFile } from "utilities/uihelpers/jsonHelper";
import { generateVmTestData } from 'testConfig/linuxTestConfig';
import { getActualDataFromMongo } from 'utilities/dbhelpers/mongoDbUtility'

let intakeFormData = readJsonFile('./TestData/vmIntakeFormData.json');
let toolsRecord: Record<string, boolean>
const testURL: string = process.env.TEST_URL!;
const vmTestData = generateVmTestData();
let vmCreationRecord: boolean

test.beforeEach(async ({ page }) => {
    await page.goto(testURL)
});



test.describe("VM Creation Tests", () => {

    for (const data of vmTestData) {
        test(`${data.testName} - ${data.qmetryTestCaseId}` + " through Nebula", { tag: ['@Regression', '@IaaS', '@P1', '@Linux_Vm_Creation', `@${data.qmetryTestCaseId}_Vm_Creation`, `@${data.domain}_Linux_Vm_Creation`] }, async ({ page, pageManager, genericHelper, screenshotHelper }) => {
            const testCaseId = `${data.qmetryTestCaseId}`

            let expectedValues = {
                Catalog: data.catalog,
                Domain: data.domain,
                Project: data.project,
                Application: data.application,
                Environment: data.environment,
                Datacenter: data.datacenter,
                OSVersion: data.osVersion,
                SSHKey: intakeFormData.ssh_key,
                RubrikSLA: data.rubrikSla,
                Description: intakeFormData.description,
                Hostname: data.hostname,
                MultiVm: {
                    isMulti: data.multiVm?.[0] ?? false,
                    vmCount: data.multiVm?.[1] ?? '1',
                    startingSequence: data.multiVm?.[2] ?? 1
                },
                VMSize: data.vmSize.substring(0, data.vmSize.indexOf('(')),
                VMCount: data.multiVm?.[1] ?? '1',
                VMSizeDetails: {},
                AdditionalDisk: {
                    ShouldAdd: data.additionalDisk[0],
                    FileSystem: data.additionalDisk[1],
                    Catalog: data.catalog
                },
                IpModes: data.ipModes,
                IpRuleType: data.ipRuleType,
                Ipv4: data.ipV4,
                Ipv6: data.ipV6,
                Tools: {
                    Security: data.tools.security,
                    Observability: data.tools.observability,
                    Compliance: data.tools.compliance ? [data.tools.compliance] : undefined,
                    Inventory: data.tools.inventory ? [data.tools.inventory] : undefined
                }
            };

            try {
                await allure.description(`Verify Linux VM creation for  ${data.osVersion}`);
                await allure.epic("IaaS");
                await allure.feature("VM Creation");
                await allure.story(`Create Linux VM - ${data.qmetryTestCaseId}`);
                await allure.issue(`https://jira.charter.com/secure/QTMAction.jspa#/TestCaseDetail/${data.jiraId}/1?projectId=105706`, testCaseId);
                await allure.owner("Rishi Khanna");
                await pageManager.onLoginPage().loginToNebula(UserTypes.Requestor)
                await test.step('Navigate To IaaS > Security > Linux Home Page', async () => {
                    await pageManager.navigateTo().navigateToMenuList(MenuItems.IaaS)
                    await pageManager.onIaasHomePage().selectCompute(IaasTabs.Compute)
                    await pageManager.onComputeHomePage().selectComputeType(expectedValues.Catalog!)

                })

                await test.step('Add Domain, Project, Application, Environmnet and OS Version', async () => {
                    await pageManager.onVirtualMachineCommonPage().selectDomain(expectedValues.Domain!)
                    await pageManager.onVirtualMachineCommonPage().selectProjectId(expectedValues.Project!)
                    await pageManager.onVirtualMachineCommonPage().selectApplication(expectedValues.Application!)
                    await pageManager.onVirtualMachineCommonPage().selectEnvironment(expectedValues.Environment!)
                    await pageManager.onVirtualMachineCommonPage().selectDatacenter(expectedValues.Datacenter!)
                    await pageManager.onVirtualMachineCommonPage().selectOsVersion(expectedValues.OSVersion)

                })
                await test.step('Enter ssh keys, rubrik details, application instance, description and password', async () => {
                    await pageManager.onVirtualMachineCommonPage().enterSshKey(expectedValues.SSHKey)
                    await pageManager.onVirtualMachineCommonPage().selectRubrikSla(expectedValues.Domain!, expectedValues.RubrikSLA)
                    await pageManager.onVirtualMachineCommonPage().addDescription(expectedValues.Description)
                    await pageManager.onVirtualMachineCommonPage().addInitialPassword()

                })
                await test.step('Add VM Count, Hostname and Vm Size Details', async () => {
                    await pageManager.onVirtualMachineCommonPage().updateVmCount(expectedValues.MultiVm.isMulti as boolean,
                        expectedValues.MultiVm.vmCount as string, expectedValues.MultiVm.startingSequence as string)
                    await pageManager.onVirtualMachineCommonPage().enterHostname(expectedValues.Hostname)
                    await pageManager.onVirtualMachineCommonPage().selectVmSize(data.vmSize, '4', '8')
                    expectedValues.VMSizeDetails = await pageManager.onVirtualMachineCommonPage().retrieveVmSizing()

                })

                const [shouldAddDisk, diskFileSystem] = data.additionalDisk;
                await test.step('Add Additional Disk and Tags', async () => {
                    if (shouldAddDisk) {
                        await pageManager.onVirtualMachineCommonPage().addAdditionalDisk(expectedValues.AdditionalDisk.ShouldAdd, expectedValues.AdditionalDisk.Catalog!,
                            '1', expectedValues.AdditionalDisk.FileSystem as DiskFileSystem
                        );
                    }
                    //await pageManager.onVirtualMachineCommonPage().addTags()

                })
                await test.step('Add Network Details', async () => {
                    await pageManager.onVirtualMachineCommonPage().goNext()
                    await pageManager.onVirtualMachineCommonPage().selectNetworkDetails(expectedValues.Datacenter)
                    await pageManager.onVirtualMachineCommonPage().selectIpModes(expectedValues.Domain!, expectedValues.IpModes)
                    await pageManager.onVirtualMachineCommonPage().selectClusterDetails(expectedValues.Catalog!, expectedValues.Datacenter)
                    await pageManager.onVirtualMachineCommonPage().selectIpType(expectedValues.IpRuleType)
                    await pageManager.onVirtualMachineCommonPage().selectIpFromList(
                        expectedValues.Domain!,
                        expectedValues.IpRuleType,
                        expectedValues.IpModes,
                        expectedValues.Ipv4 as string[],
                        expectedValues.Ipv6 as string[]
                    );


                })
                await test.step('Add Tools', async () => {
                    await pageManager.onVirtualMachineCommonPage().goNext()
                    await pageManager.onVirtualMachineCommonPage().selectTools(
                        expectedValues.Tools.Security,
                        expectedValues.Tools.Observability,
                        expectedValues.Tools.Compliance,
                        expectedValues.Tools.Inventory
                    );
                    toolsRecord = await pageManager.onVirtualMachineCommonPage().getSelectedToolsRecord()

                })

                await test.step('Submit and verify Vm Request', async () => {
                    await pageManager.onVirtualMachineCommonPage().submitVmRequest()
                    const successMessage = await pageManager.onRequestConfirmationPage().getSuccessMessage()
                    expect(successMessage).toBe('Request Submitted Successfully')

                })
                const requestId = await pageManager.onRequestConfirmationPage().retrieveRequestId()
                saveVariableIntoJsonFile('TestResponse\\requestIds.json', testCaseId, requestId)
                saveVariableIntoJsonFile('TestResponse\\hostnames.json', testCaseId, `${data.hostname}`)
                saveVariableIntoJsonFile('TestResponse\\installedToolsRecord.json', testCaseId, toolsRecord)
                expectedValues.Hostname = await genericHelper.returnHostname(expectedValues.Domain!, expectedValues.Hostname)
                saveVariableIntoJsonFile(`TestResponse\\VmIntakeFormData\\${data.qmetryTestCaseId}`, requestId, expectedValues)
                await pageManager.onMyRequestsHomePage().trackMyRequest()
                vmCreationRecord = true
                saveVariableIntoJsonFile('TestResponse\\vmCreationRecord.json', testCaseId, vmCreationRecord)
            }
            catch (error) {
                vmCreationRecord = false
                saveVariableIntoJsonFile('TestResponse\\vmCreationRecord.json', testCaseId, vmCreationRecord)
                throw error;
            }

        })
    }
})




