export enum Cluster {
   Stage = "cdptpabb04-gpcil01-hyp01-d3c6s2.stage.charter.com",
   SGPCIL02 = "CDPTPABB04-SGPCIL02-NEBULA",
   SHPCIL01 = "CDPTPABB04-SHPCIL01"
}