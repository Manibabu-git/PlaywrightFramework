export enum WinCmpGroups {
    AP_CMP_ADMINS = "Ap-Cmp-Admins"
}