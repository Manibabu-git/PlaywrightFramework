export enum RubrikSla {
    Unprotected = 'Unprotected',
    RPO24 = 'RPO24-RSC',
    RPO6 = 'RPO6-RSC',
}