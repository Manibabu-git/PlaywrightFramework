export enum UbuntuOs {
    Ubuntu_20 = "Ubuntu-20.04",
    Ubuntu_22 = "Ubuntu-22.04",
    Ubuntu_24 = "Ubuntu-24.04"
}