export enum InventoryTools {
    Granite = 'Granite'
}