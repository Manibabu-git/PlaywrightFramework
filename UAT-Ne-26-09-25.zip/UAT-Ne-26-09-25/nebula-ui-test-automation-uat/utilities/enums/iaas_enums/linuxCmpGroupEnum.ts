export enum LinuxCmpGroups {
    AP_CMP_APOImpSupp_ReliabilityEng = "AP-CMP-APOImpSupp-ReliabilityEng",
    AP_Nebula_APS_ReliabilityEng_Catalog_Admin = "AP-Nebula-APS-ReliabilityEng-Catalog-Admin"
}