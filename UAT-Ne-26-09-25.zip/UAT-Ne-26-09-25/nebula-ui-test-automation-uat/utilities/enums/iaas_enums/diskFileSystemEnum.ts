export enum DiskFileSystem {
    Xfs = 'Xfs',
    Ext4 = 'Ext4'
}