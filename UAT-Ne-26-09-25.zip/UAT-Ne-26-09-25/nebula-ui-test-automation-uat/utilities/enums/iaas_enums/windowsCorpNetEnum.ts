export enum WindowsCorpNet {
    Windows_2019 = "Windows 2019",
    Windows_2022 = "Windows 2022"
}