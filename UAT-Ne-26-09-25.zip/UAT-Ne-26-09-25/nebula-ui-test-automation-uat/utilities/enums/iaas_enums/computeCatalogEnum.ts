export enum ComputeCatalog {
    Linux = "Linux 8 & 9 V3",
    Linux_Admin = "Linux 8 & 9 V3 Admin",
    Ubuntu = "Ubuntu v3",
    Windows = "Windows V3",
    Ubuntu_Admin = "Ubuntu V3 Admin",
    Windows_Admin = "Windows V3 Admin",
    Linux_Corpnet = "Linux_Corpnet",
    Windows_Corpnet = "Windows_Corpnet",
}
