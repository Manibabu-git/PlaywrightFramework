export enum IpModes {
    Static_Manual = 'Static-Manual',
    Static_Auto = 'Static-Auto'
}