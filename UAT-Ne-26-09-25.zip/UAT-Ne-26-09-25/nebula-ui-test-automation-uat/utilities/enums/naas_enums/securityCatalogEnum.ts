
export enum SecurityCatalog {

    Add_Firewall_Rules_V2 = "Add Firewall Rules V2",
    Device_Config_Lookup = "Device Config Lookup",
    Path_Analysis = "Path Analysis",
    Onboard_Common_Firewall_Application = "Onboard Common Firewall Application",
    Dynamic_Access_Policies = "Dynamic Access Policies"
    
}