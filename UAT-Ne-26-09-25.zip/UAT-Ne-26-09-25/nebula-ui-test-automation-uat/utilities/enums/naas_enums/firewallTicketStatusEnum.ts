export enum FirewallTicketStatus {
    New = "New",
    In_Progress = "In Progress",
    CREATED = "CREATED",
    Cancelled = "Cancelled",
    Ticket_Cancelled = "Ticket Cancelled",
    FAILED = "FAILED"
}