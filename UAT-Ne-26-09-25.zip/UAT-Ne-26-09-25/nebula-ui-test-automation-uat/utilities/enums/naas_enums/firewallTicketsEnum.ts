export enum FirewallTickets {
    Jira = "Jira",
    Tufin = "Tufin",
    Remedy = "Remedy",
    Cherwell = "Cherwell"
}