export enum IpRuleType {
    ipv4 = "ipv4",
    ipv6 = "ipv6",
    ipv4v6= "ipv4v6"
}