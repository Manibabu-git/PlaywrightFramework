import { Page } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import * as allure from 'allure-js-commons';

export class ScreenshotHelper {
  async captureScreenshot(page: Page, stepName: string) {
    const screenshotFolder = path.resolve('./screenshots');
    // const screenshotFolder = path.resolve(__dirname, './screenshots');
    if (!fs.existsSync(screenshotFolder)) {
      fs.mkdirSync(screenshotFolder, { recursive: true });
    }

    const screenshotPath = path.join(screenshotFolder, `${stepName}.png`);
    await page.screenshot({ path: screenshotPath });

    // Attach the screenshot to Allure report
    allure.attachment(`Screenshot for ${stepName}`, fs.readFileSync(screenshotPath), 'image/png');

  }
}
