import * as fs from 'fs';
import * as path from 'path';

// File path to the JSON file in the root-level "config" folder
//const jsonFilePath = path.join(process.cwd(), 'TestResponse', 'runtimeVariables.json');


/**
 * Save a key-value pair (including objects) to a JSON file.
 * @param jsonFilePath - Path to the JSON file.
 * @param key - The key to store the value under (e.g., test case ID).
 * @param value - The value to store (can be string, object, boolean, etc.).
 */
export const saveVariableIntoJsonFile = (
    jsonFilePath: string,
    key: string,
    value: any // allow any type including objects
): void => {
    let data: Record<string, any> = {};

    const dirPath = path.dirname(jsonFilePath);
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }

    if (!fs.existsSync(jsonFilePath)) {
        fs.writeFileSync(jsonFilePath, JSON.stringify({}, null, 2), 'utf8');
    }

    try {
        const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
        data = fileContent.trim() ? JSON.parse(fileContent) : {};
    } catch (error) {
        console.error('Error reading or parsing JSON file:', error);
        data = {};
    }

    data[key] = value;

    fs.writeFileSync(jsonFilePath, JSON.stringify(data, null, 2), 'utf8');
};

/**
 * Retrieve a value by its key from the JSON file.
 * @param key - The key to fetch the variable.
 * @returns The value associated with the key, or undefined if not found.
 */
export const getVariableFromJsonFile = (jsonFilePath: string, key: string): any => {
    if (!fs.existsSync(jsonFilePath)) {
        return undefined;
    }

    try {
        const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
        const data = fileContent.trim() ? JSON.parse(fileContent) : {};
        return data[key];
    } catch (error) {
        console.error('Error reading or parsing JSON file:', error);
        return undefined;
    }
};

/**
 * Retrieve entire json file as response.
 * @param filePath - The path of the json file.
 * @returns The value associated with the json file path.
 */
export function readJsonFile(filePath: string): any {
    const absolutePath = path.resolve(filePath);
    return JSON.parse(fs.readFileSync(absolutePath, 'utf-8'));
}

/**
 * Save a outcome to the JSON file.
 * @param filePath - The location where to save this response.
 * @param value - The value to store.
 */
export function writeJsonFile(filePath: string, value: any): void {
    const absolutePath = path.resolve(filePath);
    fs.writeFileSync(absolutePath, JSON.stringify(value, null, 2), 'utf-8');
}