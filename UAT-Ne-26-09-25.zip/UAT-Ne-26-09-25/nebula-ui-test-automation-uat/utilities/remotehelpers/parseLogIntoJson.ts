type ToolCategory = "Security" | "Compliance" | "Observability";

interface ActualValues {
    Hostname: string;
    VMSize: string;
    AdditionalDisk: {
        ShouldAdd: boolean;
        FileSystem: string;
        Catalog: string;
    };
    Tools: Record<ToolCategory, string[]>;
}

export function parseLogToJson(log: string): ActualValues {
    const osVersion = log.match(/OS: Red Hat Enterprise Linux ([\d.]+)/)?.[1];
    const memoryRaw = log.match(/Total Memory: ([\d.]+)Gi/)?.[1];
    const memory = memoryRaw ? Math.ceil(parseFloat(memoryRaw)).toString() : "Unknown";
    const hostname = log.match(/DNS Name: (.+)/)?.[1]?.trim() || "Unknown";

    // Additional Disks
    const diskMatches = [...log.matchAll(/(\w+)\s+\d+G\s+\w+\s+(\/[^\s]*)?/g)];
    const additionalDisks = diskMatches
        .filter(([_, name, mount]) => mount)
        .map(([_, name, mount]) => ({ name, mount }));

    // Tools
    const toolRegex = /Tool: (\w+)[\s\S]*?Package Status: (.+)[\s\S]*?Service Status: (.+)/g;
    const toolMatches = [...log.matchAll(toolRegex)];

    const toolStatus: Record<string, boolean> = {};
    toolMatches.forEach(([_, tool, pkgStatus, svcStatus]) => {
        const isInstalled = !pkgStatus.includes("Error");
        const isRunning = svcStatus.includes("active (running)");
        toolStatus[tool] = isInstalled && isRunning;
    });

    // Categorize tools
    const toolCategories: Record<ToolCategory, string[]> = {
        Security: ["Centrify", "CrowdStrike", "Qualys"].filter(t => toolStatus[t]),
        Compliance: ["Tanium"].filter(t => toolStatus[t]),
        Observability: ["Splunk"].filter(t => toolStatus[t])
    };

    const actualValues: ActualValues = {
        Hostname: hostname,
        VMSize: memory,
        AdditionalDisk: {
            ShouldAdd: additionalDisks.length > 0,
            FileSystem: "",
            Catalog: "Linux 8 & 9 V3"
        },
        Tools: toolCategories
    };

    return actualValues;
}
