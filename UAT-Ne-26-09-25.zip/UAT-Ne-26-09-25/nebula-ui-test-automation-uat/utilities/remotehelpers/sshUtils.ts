import { Client } from 'ssh2';
import * as fs from 'fs';

interface SSHConfig {
  host: string;
  port: number;
  username: string;
  password?: string;
  privateKey?: string;
}

export function runRemoteCommand(
  config: SSHConfig,
  command: string,
  outputFilePath: string
): Promise<void> {
  return new Promise((resolve, reject) => {
    const conn = new Client();

    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          return reject(err);
        }

        const outputStream = fs.createWriteStream(outputFilePath);
        stream.on('close', () => {
          conn.end();
          resolve();
        }).on('data', (data: Buffer) => {
          outputStream.write(data);
        }).stderr.on('data', (data: Buffer) => {
          outputStream.write(data); // include stderr too
        });
      });
    }).on('error', (err) => {
      reject(err);
    }).connect(config);
  });
}