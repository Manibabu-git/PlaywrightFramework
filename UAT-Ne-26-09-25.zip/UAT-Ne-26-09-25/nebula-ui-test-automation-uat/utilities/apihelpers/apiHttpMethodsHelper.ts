import { APIRequestContext, request } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

export class ApiHelper {

  private context: Promise<APIRequestContext>;

  constructor(baseUrl: string, headers: Record<string, string>) {
    this.context = request.newContext({
      baseURL: baseUrl,
      extraHTTPHeaders: headers,
    });
  }

  async get(endpoint: string) {
    const ctx = await this.context;
    return await ctx.get(endpoint);
  }

  async post(endpoint: string, body: any) {
    const ctx = await this.context;
    console.log(endpoint)
    return await ctx.post(endpoint, { data: body });
  }

  async put(endpoint: string, body: any) {
    const ctx = await this.context;
    return await ctx.put(endpoint, { data: body });
  }

  async delete(endpoint: string) {
    const ctx = await this.context;
    return await ctx.delete(endpoint);
  }
}