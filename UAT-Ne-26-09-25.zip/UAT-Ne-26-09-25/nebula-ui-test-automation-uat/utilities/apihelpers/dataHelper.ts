import { format } from 'date-fns';
import * as fs from 'fs';
import path from 'path';



function getDynamicDataForResultImportToQmetry(directory: string): Record<string, any> {
    const currentDate = new Date();
    const plannedStartDate = format(currentDate, 'dd/MMM/yyyy HH:mm');
    const plannedEndDate = format(new Date(currentDate.getTime() + 7 * 24 * 60 * 60 * 1000), 'dd/MMM/yyyy HH:mm');

    function formatTime(date: Date): string {
        return format(date, 'HH:mm:ss');
    }

    const actualTime = formatTime(currentDate); // Current time
    const estimatedTime = formatTime(new Date(currentDate.getTime() + 30 * 60 * 1000)); // 30 minutes from actual time

    return {
        assignee: "JIRAUSER707095",
        reporter: "JIRAUSER707095",
        folderPath: `UAT/Regression/${directory}`,
        plannedStartDate,
        plannedEndDate,
        estimatedTime,
        actualTime,
        executionPlannedDate: plannedStartDate
    };
}




function readJsonFile(filePath: string): any {
    const data = fs.readFileSync(path.resolve(filePath), 'utf8');
    return JSON.parse(data);
}

export function generateRequestBody(directory: string, isFirstBatch: boolean): any {
    const staticData = readJsonFile('./TestData/importResultStaticData.json');
    const dynamicData = getDynamicDataForResultImportToQmetry(directory);

    // Use a single test cycle folder
    if (isFirstBatch) {
        staticData.fields.testCycle = {
            ...staticData.fields.testCycle,
            folderPath: 'UAT/Regression', // Single folder for test cycle
            plannedStartDate: dynamicData.plannedStartDate,
            plannedEndDate: dynamicData.plannedEndDate,
            assignee: dynamicData.assignee,
            reporter: dynamicData.reporter,
        };
    } else {
        // Skip creating a new test cycle for subsequent batches
        delete staticData.fields.testCycle;
    }

    // Dynamically set folderPath for test cases
    staticData.fields.testCase = {
        ...staticData.fields.testCase,
        folderPath: dynamicData.folderPath, // Use dynamic folder path for test cases
        assignee: dynamicData.assignee,
        reporter: dynamicData.reporter,
        estimatedTime: dynamicData.estimatedTime,
    };

    // Dynamically set fields for test case execution
    staticData.fields.testCaseExecution = {
        ...staticData.fields.testCaseExecution,
        assignee: dynamicData.assignee,
        actualTime: dynamicData.actualTime,
        executionPlannedDate: dynamicData.executionPlannedDate,
    };

    return staticData;
}
